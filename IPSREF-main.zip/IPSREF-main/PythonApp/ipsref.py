from tkinter import *
from tkinter import messagebox
import customtkinter
from PIL import Image
import os
from datetime import datetime, time
import mysql.connector
import serial
import threading

##### Ligação à base de dados #####
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="ipsref"
)

sql = db.cursor(dictionary=True)

# Tema claro
customtkinter.set_appearance_mode("light")

# Caminho absoluto da pasta onde o script está
basePath = os.path.dirname(os.path.abspath(__file__))

##### Variáveis #####
# Imagens
logoPath = os.path.join(basePath, "images", "logo.png")
alertPath = os.path.join(basePath, "images", "alert.png")
defaultImagePath = os.path.join(basePath, "images", "default.png")
lockPath = os.path.join(basePath, "images", "lock.png")

# Cores
bgColor = '#E5F3FB'
black = "#000000"
white = "#FFFFFF"
fontDisabled = "#A0A0A0"

# Botões
bgUseButton = "#2E7D32"
bgUserButtonHover = "#1B5E20"
bgUseButtonDisabled = "#A5D6A7"
bgCancelButton = "#C62828"
bgCancelButtonHover = "#B71C1C"

# Frames
bgNoTicket = "#D57D25"
bgFrame = "#004C8C"
bgFrameDisabled = "#5F85A5"

# Globais
currentTicketId = None

##### Funções Auxiliares #####

#Atualiza o Relógio
def update_clock(clockWidget):
    currentTime = datetime.now().strftime("%H:%M, %d/%m/%Y")
    clockWidget.configure(text=currentTime)
    clockWidget.after(1000, update_clock, clockWidget) 

# Retorna as configurações de um botão tendo em conta se a senha é valida ou não
def getButtonConfig(isButtonValid):
    return {
        "state": "normal" if isButtonValid else "disabled",
        "fg": bgUseButton if isButtonValid else bgUseButtonDisabled,
        "hover": bgUserButtonHover if isButtonValid else bgUseButtonDisabled
    }

#Verifica se a senha é válida para o horário atual
def isTicketValid(ticketData):
    currentDatetime = datetime.now()
    currentTime = currentDatetime.time()

    # Para testes
    # currentTime = time(13,0) # Almoço
    #currentTime = time(20,0) # Jantar
    
    # Horários
    lunchStart = time(12, 0)  # 12:00
    lunchEnd = time(15, 0)    # 15:00
    dinnerStart = time(18, 0) # 19:00
    dinnerEnd = time(21, 0)   # 21:00

    if ticketData['period'] == 'Almoço':
        return lunchStart <= currentTime <= lunchEnd
    elif ticketData['period'] == 'Jantar':
        return dinnerStart <= currentTime <= dinnerEnd
        
    return False

# Cria um processo para poder ler o cartão
def startReading():
    thread = threading.Thread(target=readCard, daemon=True)
    thread.start()

def startReadingButtons(ser):
    thread = threading.Thread(target=readButtons, args=(ser,), daemon=True)
    thread.start()

# Fecha a window atual e volta a ativar a leitura do cartão
def closeWindowStartCardRead(window, ser=None):
    print("Fechou a janela, a voltar a ler...")
    if ser is not None:
        ser.close()
    window.destroy()
    app.deiconify()  # Restaura a janela inicial
    startReading()

# Lê o id passado pela porta USB e passa-o para ser verificado
def readCard():
    global reading
    reading = True
    try:
        ser = serial.Serial('COM4', 115200, timeout=0.1)
        print("À espera do cartão...")

        while reading:
            if ser.in_waiting > 0:
                data = ser.readline().decode(errors='ignore').strip()
                if data.startswith("CARD_"):
                    uid = data.replace("CARD_", "")
                    print("Cartão lido:", uid)
                    ser.close()
                    reading = False
                    app.after(0, lambda: cardNumberInput(uid))
                    break
        ser.close()

    except Exception as e:
        print("readCardError:", e)

def readButtons(ser):
    global readingButtons
    readingButtons = True
    try:
        serialPort = ser
        print("À espera dos botões...")

        while readingButtons:
            if serialPort.in_waiting > 0:
                data = serialPort.readline().decode(errors='ignore').strip()

                print("Botão lido:", data)

                if data.startswith("BUTTON_"):

                    if data == "BUTTON_OK":
                        buttonUseTicket(serialPort)

                    elif data == "BUTTON_CANCEL":
                        buttonCancel(serialPort)
    except Exception as e:
        print("readButtonsError:", e)

def buttonUseTicket(serialPort):
    global currentTicketId
    if currentTicketId is None:
        print("Senha inválida, não pode ser usada.")
        return
    print("Botão OK e Senha usada", currentTicketId)
    useTicket(currentTicketId)
    global readingButtons
    readButtons = False
    serialPort.close()
    global mainWindow
    closeWindowStartCardRead(mainWindow)

def buttonCancel(serialPort):
    print("Botão Cancel e Fechar janela")
    global readingButtons
    readButtons = False
    serialPort.close()
    global mainWindow
    closeWindowStartCardRead(mainWindow)

# Cria a payload a partir das rows da BD
def createPayload(rows, hasTickets=True):
    # Constuir student
    firstRow = rows[0]
    student = {
        "id": firstRow.get("pessoa_id"),
        "imagePath": firstRow.get("pessoa_foto"),
        "name": firstRow.get("pessoa_nome"),
        "surname": firstRow.get("pessoa_apelido"),
        "studentNum": firstRow.get("aluno_n_estudante"),
        "email": firstRow.get("pessoa_email")
    }
    # Se não tiver senhas, devolve apenas a informação do aluno
    if not hasTickets:
        payload = {
            "student": student,
            "availableTickets": 0,
            "tickets": {"Almoço": None, "Jantar": None}
        }
        return payload

    tickets = {"Almoço": None, "Jantar": None}

    # Preenche tickets
    for r in rows:
        period = r.get("senha_tipo")

        # Formatar extras
        raw = r.get("extras")
        if raw is None:
            extras_list = []
        else:
            extras_list = [e.strip() for e in str(raw).split(",") if e.strip()]

        # Informações do Prato
        dishName = r.get("prato_nome")
        dishType = r.get("prato_tipo")

        tickets[period] = {
            "id": r.get("senha_id"),
            "period": period,
            "type": dishType,
            "name": dishName,
            "extras": extras_list
        }

    available = len(rows)

    payload = {
        "student": student,
        "availableTickets": available,
        "tickets": tickets
    }

    print("Tickets: ", payload["tickets"])
    return payload

# Recebe o número do cartão lido e faz queries
def cardNumberInput(cardNumber=''):
    # Só para debug
    # cardNumberInput = customtkinter.CTkInputDialog(text="Insira o número do cartão:", title="Cartão de Estudante")
    # cardNumber = cardNumberInput.get_input()

    # Se receber um número de cartão verifica se existe na BD
    if cardNumber:
        sql.execute("SELECT * FROM view_utilizadores WHERE aluno_n_cartao = '" + cardNumber + "'")

        cardCheck = sql.fetchall()

        # Cria a ligação USB para enviar os resultados para o raspberry pi pico
        ser = serial.Serial('COM4', 115200, timeout=1)

        if not cardCheck:
            # Envia NOT_FOUND pela porta USB
            ser.write(b"NOT_FOUND\n")
            ser.close()

            startReading()
            return

        # Verifica se o aluno tem senhas para o dia atual
        # Query real
        sql.execute("SELECT * FROM view_senhas_dia_aluno WHERE aluno_n_cartao = '" + cardNumber + "' AND DATE(senha_data) = CURDATE() AND estado_atual = 'A'")

        # Query para testes com data fixa
        # sql.execute(
        #     "SELECT * FROM view_senhas_dia_aluno "
        #     "WHERE aluno_n_cartao = '" + cardNumber + "' "
        #     "AND DATE(senha_data) = '2025-12-09' "
        #     "AND estado_atual = 'A'"
        # )

        ticketsResult = sql.fetchall()

        # Se não tiver senhas, devolve apenas a informação do aluno. Se tiver, cria a payload completa
        if not ticketsResult:
            # Envia NO_TICKETS pela porta USB
            ser.write(b"NO_TICKETS\n")
            ser.close()

            sql.execute("SELECT * FROM view_utilizadores WHERE aluno_n_cartao = '" + cardNumber + "'")
            studentResult = sql.fetchall()
            payload = createPayload(studentResult, hasTickets=False)
        else:
            # Envia OK pela porta USB
            ser.write(b"OK\n") 
            ser.close()
            payload = createPayload(ticketsResult)
        
        # Abre a janela principal com a payload
        openMainWindow(payload)

##### Regista o uso de uma senha #####
def useTicket(ticketId):
    print(f"Senha usada: {ticketId}")

    sql.execute("UPDATE senha SET sen_est_atual_id = 2 WHERE sen_id = " + str(ticketId))

    sql.execute("INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES (2, " + str(ticketId) + ", NOW())")

    db.commit()
    
##### Abre a janela principal #####
def openMainWindow(payload):
    global currentTicketId
    
    ser = serial.Serial('COM4', 115200, timeout=1)

    # Chamar thread para ler os botões 
    startReadingButtons(ser)

    student = payload['student']
    availableTickets = payload['availableTickets']
    lunchTicketData = payload['tickets']['Almoço']
    dinnerTicketData = payload['tickets']['Jantar']

    # Define qual senha está ativa
    if availableTickets == 1:
        ticketData = lunchTicketData or dinnerTicketData
        if isTicketValid(ticketData):
            currentTicketId = ticketData['id']
        else:
            currentTicketId = None
    elif availableTickets == 2:
        # Prioriza a senha válida no horário atual
        if lunchTicketData and isTicketValid(lunchTicketData):
            currentTicketId = lunchTicketData['id']
        elif dinnerTicketData and isTicketValid(dinnerTicketData):
            currentTicketId = dinnerTicketData['id']
        else:
            currentTicketId = None
    else:
        currentTicketId = None

    # Minimiza a janela inicial
    app.iconify()

    ##### Configurações da janela #####
    global mainWindow
    mainWindow = customtkinter.CTkToplevel(app)
    mainWindow.title("IPSREF - Senhas Disponíveis")
    mainWindow.geometry("1280x670")
    mainWindow.resizable(False, False)

    # Garante que ao fechar a janela no X abre a janela inicial outra vez
    mainWindow.protocol("WM_DELETE_WINDOW", lambda: closeWindowStartCardRead(mainWindow, ser))

    ##### Relógio #####
    clock = customtkinter.CTkButton(mainWindow, text="", width=75, height=35, hover=DISABLED, font=('Arial', 18))
    clock.place(x=1115, y=10)
    update_clock(clock)

    ##### SideBar #####
    # Imagem
    logo = customtkinter.CTkImage(light_image=Image.open(logoPath), size=(280, 230))
    imageLabel = customtkinter.CTkLabel(mainWindow, image=logo, text="")
    imageLabel.place(x=20, y=-10)

    ##### Linha horizontal e vertical #####
    sideBarHorizontal = customtkinter.CTkFrame(master=mainWindow, width=315, height=5, fg_color="black")
    sideBarHorizontal.place(y=210)
    sideBarVertical = customtkinter.CTkFrame(master=mainWindow, width=5, height=800, fg_color="black")
    sideBarVertical.place(x=310)

    ##### Informação do estudante #####
    studentInfoFrame = customtkinter.CTkFrame(master=mainWindow, width=250, height=410, fg_color=bgFrame)
    studentInfoFrame.place(x=40, y=230)

    # Imagem
    if student['imagePath'] and os.path.exists(student['imagePath']):
        studentImagePath = student['imagePath']
    else:
        studentImagePath = defaultImagePath
    
    studentImage = customtkinter.CTkImage(light_image=Image.open(studentImagePath), size=(100, 100))
    studentImageLabel = customtkinter.CTkLabel(studentInfoFrame, image=studentImage, text="")
    studentImageLabel.place(x=80, y=20)

    # Nome e apelido
    studentNameLabel = customtkinter.CTkLabel(studentInfoFrame, text=f"{student['name']} {student['surname']}", font=('Arial', 18, 'bold'), text_color=white)
    studentNameLabel.place(relx=0.5, y=140, anchor='center')

    # Linha horizontal
    studentHorizontal = customtkinter.CTkFrame(master=studentInfoFrame, width=250, height=5, fg_color="black")
    studentHorizontal.place(y=180)

    # Número de estudante
    studentNumLabel = customtkinter.CTkLabel(studentInfoFrame, text=f"Número de Estudante:\n {student['studentNum']}", font=('Arial', 16), text_color=white)
    studentNumLabel.place(relx=0.5, y=220, anchor='center')

    # Linha horizontal
    studentHorizontal = customtkinter.CTkFrame(master=studentInfoFrame, width=250, height=5, fg_color="black")
    studentHorizontal.place(y=260)

    # Email
    studentEmailLabel = customtkinter.CTkLabel(studentInfoFrame, text=f"Email:\n {student['email']}", font=('Arial', 16), text_color=white)
    studentEmailLabel.place(relx=0.5, y=300, anchor='center')

    # Botão de Cancelar
    cancelButton = customtkinter.CTkButton(studentInfoFrame, text="Cancelar", width=200, height=50, fg_color=bgCancelButton, hover_color=bgCancelButtonHover, font=('Arial', 18), command=lambda: closeWindowStartCardRead(mainWindow, ser))
    cancelButton.place(x=25, y=340)

    ##### Header #####
    headerLabel = customtkinter.CTkLabel(mainWindow, text="Senhas Disponíveis", font=('Arial', 48, 'underline'))
    headerLabel.place(x=550, y=40)
    
    ##### Frames de Senhas #####
    if availableTickets == 0:
        # Frame de alerta
        alertFrame = customtkinter.CTkFrame(master=mainWindow, width=600, height=300, fg_color=bgNoTicket)
        alertFrame.place(x=500, y=180)

        alertImage = customtkinter.CTkImage(light_image=Image.open(alertPath), size=(100, 100))
        alertImageLabel = customtkinter.CTkLabel(alertFrame, image=alertImage, text="")
        alertImageLabel.place(x=250, y=50)

        alertLabel = customtkinter.CTkLabel(alertFrame, text="Nenhuma senha disponível!", font=('Arial', 24, 'bold'), text_color=white)
        alertLabel.place(relx=0.5, rely=0.7, anchor='center')

    elif availableTickets == 1:
        # Um frame
        ticketData = lunchTicketData or dinnerTicketData
        isValid = isTicketValid(ticketData)

        singleTicketFrame = customtkinter.CTkFrame(
            master=mainWindow, 
            width=350, 
            height=500, 
            fg_color=bgFrame if isValid else bgFrameDisabled
        )
        singleTicketFrame.place(x=580, y=120)

        # Ícone de cadeado se inválido
        if not isValid:
            singleTicketFrame.lockImage = customtkinter.CTkImage(light_image=Image.open(lockPath), size=(100, 100))
            singleTicketFrame.lockLabel = customtkinter.CTkLabel(singleTicketFrame, image=singleTicketFrame.lockImage, text="")
            singleTicketFrame.lockLabel.place(x=130, y=200)

        ticketLabel = customtkinter.CTkLabel(singleTicketFrame, text=f"Senha de {ticketData['period']}", font=('Arial', 24, 'bold'), text_color=white if isValid else fontDisabled)
        ticketLabel.place(x=80, y=20)

        ticketHorizontal = customtkinter.CTkFrame(master=singleTicketFrame, width=350, height=5, fg_color="black")
        ticketHorizontal.place(y=60)

        periodLabel = customtkinter.CTkLabel(singleTicketFrame, text=f"Período: {ticketData['period']}", font=('Arial', 18), text_color=white if isValid else fontDisabled)
        periodLabel.place(x=20, y=100)

        typeLabel = customtkinter.CTkLabel(singleTicketFrame, text=f"Tipo: {ticketData['type']}", font=('Arial', 18), text_color=white if isValid else fontDisabled)
        typeLabel.place(x=20, y=140)

        dishLabel = customtkinter.CTkLabel(singleTicketFrame, text=f"Prato: {ticketData['name']}", font=('Arial', 18), text_color=white if isValid else fontDisabled)
        dishLabel.place(x=20, y=180)

        extrasLabel = customtkinter.CTkLabel(
            singleTicketFrame,
            text="Extras:\n" + "\n".join(f"• {e}" for e in ticketData['extras']) if ticketData['extras'] else "Extras:\n\n Nenhum",
            font=('Arial', 18),
            text_color=white if isValid else fontDisabled,
            justify="left"
        )
        extrasLabel.place(x=20, y=220)

        singleButtonConfig = getButtonConfig(isValid)

        useButton = customtkinter.CTkButton(
            singleTicketFrame,
            text="Usar Senha",
            width=200,
            height=50,
            fg_color=singleButtonConfig["fg"],
            hover_color=singleButtonConfig["hover"],
            font=('Arial', 18),
            state=singleButtonConfig["state"],
            cursor="hand2",
            command=lambda: useTicket(ticketData['id'])
        )
        useButton.place(x=80, y=400)

    elif availableTickets == 2:
        # Dois frames (Almoço e Jantar)
        # Frame de Almoço
        isLunchValid = isTicketValid(lunchTicketData)
        lunchTicket = customtkinter.CTkFrame(
            master=mainWindow, 
            width=350, 
            height=500, 
            fg_color=bgFrame if isLunchValid else bgFrameDisabled
        )
        lunchTicket.place(x=400, y=120)

        # Ícone de cadeado se inválido
        if not isLunchValid:
            lunchTicket.lockImage = customtkinter.CTkImage(light_image=Image.open(lockPath), size=(100, 100))
            lunchTicket.lockLabel = customtkinter.CTkLabel(lunchTicket, image=lunchTicket.lockImage, text="")
            lunchTicket.lockLabel.place(x=130, y=200)

        lunchTicketLabel = customtkinter.CTkLabel(lunchTicket, text="Senha de Almoço", font=('Arial', 24, 'bold'), text_color=white if isLunchValid else fontDisabled)
        lunchTicketLabel.place(x=80, y=20)

        lunchHorizontal = customtkinter.CTkFrame(master=lunchTicket, width=350, height=5, fg_color="black")
        lunchHorizontal.place(y=60)

        lunchPeriodLabel = customtkinter.CTkLabel(lunchTicket, text=f"Período: {lunchTicketData['period']}", font=('Arial', 18), text_color=white if isLunchValid else fontDisabled)
        lunchPeriodLabel.place(x=20, y=100)

        lunchTypeLabel = customtkinter.CTkLabel(lunchTicket, text=f"Tipo: {lunchTicketData['type']}", font=('Arial', 18), text_color=white if isLunchValid else fontDisabled)
        lunchTypeLabel.place(x=20, y=140)

        lunchDishLabel = customtkinter.CTkLabel(lunchTicket, text=f"Prato: {lunchTicketData['name']}", font=('Arial', 18), text_color=white if isLunchValid else fontDisabled)
        lunchDishLabel.place(x=20, y=180)

        lunchExtrasLabel = customtkinter.CTkLabel(
            lunchTicket,
            text="Extras:\n\n" + "\n\n".join(f"• {e}" for e in lunchTicketData['extras']) if lunchTicketData['extras'] else "Extras:\n\n - Nenhum",
            font=('Arial', 18),
            justify="left", 
            text_color=white if isLunchValid else fontDisabled
        )
        lunchExtrasLabel.place(x=20, y=220)

        lunchButtonConfig = getButtonConfig(isLunchValid)

        lunchButton = customtkinter.CTkButton(
            lunchTicket,
            text="Usar Senha",
            width=200,
            height=50,
            fg_color=lunchButtonConfig["fg"],
            hover_color=lunchButtonConfig["hover"],
            font=('Arial', 18),
            state=lunchButtonConfig["state"],
            cursor="hand2",
            command=lambda: useTicket(lunchTicketData['id'])
        )
        lunchButton.place(x=80, y=400)

        # Frame de Jantar
        isDinnerValid = isTicketValid(dinnerTicketData)
        dinnerTicket = customtkinter.CTkFrame(
            master=mainWindow, 
            width=350, 
            height=500, 
            fg_color=bgFrame if isDinnerValid else bgFrameDisabled
        )
        dinnerTicket.place(x=830, y=120)

        # Ícone de cadeado se inválido
        if not isDinnerValid:
            dinnerTicket.lockImage = customtkinter.CTkImage(light_image=Image.open(lockPath), size=(100, 100))
            dinnerTicket.lockLabel = customtkinter.CTkLabel(dinnerTicket, image=dinnerTicket.lockImage, text="")
            dinnerTicket.lockLabel.place(x=130, y=200)

        dinnerTicketLabel = customtkinter.CTkLabel(dinnerTicket, text="Senha de Jantar", font=('Arial', 24, 'bold'), text_color=white if isDinnerValid else fontDisabled)
        dinnerTicketLabel.place(x=80, y=20)

        dinnerHorizontal = customtkinter.CTkFrame(master=dinnerTicket, width=350, height=5, fg_color="black")
        dinnerHorizontal.place(y=60)

        dinnerPeriodLabel = customtkinter.CTkLabel(dinnerTicket, text=f"Período: {dinnerTicketData['period']}", font=('Arial', 18), text_color=white if isDinnerValid else fontDisabled)
        dinnerPeriodLabel.place(x=20, y=100)

        dinnerTypeLabel = customtkinter.CTkLabel(dinnerTicket, text=f"Tipo: {dinnerTicketData['type']}", font=('Arial', 18), text_color=white if isDinnerValid else fontDisabled)
        dinnerTypeLabel.place(x=20, y=140)

        dishLabel = customtkinter.CTkLabel(dinnerTicket, text=f"Prato: {dinnerTicketData['name']}", font=('Arial', 18), text_color=white if isDinnerValid else fontDisabled)
        dishLabel.place(x=20, y=180)

        dinnerExtrasLabel = customtkinter.CTkLabel(
            dinnerTicket,
            text="Extras:\n\n" + "\n\n".join(f"• {e}" for e in dinnerTicketData['extras']) if dinnerTicketData['extras'] else "Extras:\n\n - Nenhum",
            font=('Arial', 18),
            justify="left",
            text_color=white if isDinnerValid else fontDisabled
        )
        dinnerExtrasLabel.place(x=20, y=220)

        dinnerButtonConfig = getButtonConfig(isDinnerValid)

        dinnerButton = customtkinter.CTkButton(
            dinnerTicket,
            text="Usar Senha",
            width=200,
            height=50,
            fg_color=dinnerButtonConfig["fg"],
            hover_color=dinnerButtonConfig["hover"],
            font=('Arial', 18),
            state=dinnerButtonConfig["state"],
            cursor="hand2",
            command=lambda: useTicket(dinnerTicketData['id'])
        )
        dinnerButton.place(x=80, y=400)

##### Configurações da janela inicial #####
app = customtkinter.CTk()
app.geometry("700x350")
app.title("IPSREF - Senhas Online")
app.resizable(False, False)

clock = customtkinter.CTkButton(app, text="", width=75, height=35, hover=DISABLED, font=('Arial', 18))
clock.place(x=535, y=10)

update_clock(clock) 

logo = customtkinter.CTkImage(light_image=Image.open(logoPath), size=(350, 200))
image_label = customtkinter.CTkLabel(app, image=logo, text="")
image_label.pack()

welcomeLabel = customtkinter.CTkLabel(app, text="Bem Vindo/a", font=('Arial', 42, 'bold'))
welcomeLabel.pack()

infoLabel = customtkinter.CTkLabel(app, text="Passe o seu cartão de estudante no sensor", font=('Arial', 18))
infoLabel.pack()

# Só para desenvolvimento

studentInfo = {
    "id": 1,
    "imagePath": "path/image.png",
    "name": "João",
    "surname": "Alves",
    "studentNum": "2025141152",
    "email": "2025141152@estudantes.ips.pt"
}

payloadNoTickets = {
    "student": studentInfo,
    "availableTickets": 0,
    "tickets": {
        "Almoço": None,
        "Jantar": None
    }
}

payloadWithTicket = {
    "student": studentInfo,
    "availableTickets": 1,
    "tickets": {
        "Almoço": {"id": 1, "period": "Almoço", "type": "Vegetariana", "name": "Prato 1", "extras": []},
        "Jantar": None
    }
}

payloadWith2Tickets = {
    "student": studentInfo,
    "availableTickets": 2,
    "tickets": {
        "Almoço": {"id": 1, "period": "Almoço", "type": "Carne", "name": "Prato 1", "extras": ["Pão", "Sopa"]},
        "Jantar": {"id": 2, "period": "Jantar", "type": "Peixe", "name": "Prato 2", "extras": []}
    }
}

# noTicketsButton = customtkinter.CTkButton(app, text="Sem senhas", command=lambda: openMainWindow(payloadNoTickets))
# noTicketsButton.place(x=40, y=300)

# ticketButton = customtkinter.CTkButton(app, text="1 senha", command=lambda: openMainWindow(payloadWithTicket))
# ticketButton.place(x=200, y=300)

# ticket2Button = customtkinter.CTkButton(app, text="2 senhas", command=lambda: openMainWindow(payloadWith2Tickets))
# ticket2Button.place(x=360, y=300)

# nCardButton = customtkinter.CTkButton(app, text="Número Cartão", command=cardNumberInput)
# nCardButton.place(x=520, y=300)

startReading()

app.mainloop()