<?php
include 'conexao.php';
require 'php/composer/vendor/feriados.php';
require_once 'php/composer/vendor/autoload.php';

$type = $_GET['type'] ?? '';

// ===============================
// PEDIDOS QUE NÃO PRECISAM LOGIN
// ===============================

// Verificar se número de estudante já existe
if ($type === "checkStudentNumber") {

    $n = $_POST["nEstudante"];

    $sql = "SELECT * FROM aluno WHERE alu_n_estudante = '$n'";
    $result = mysqli_query($conn, $sql);

    echo json_encode([
        "exists" => mysqli_num_rows($result) > 0
    ]);
    exit;
}

// Verificar se email já existe
else if ($type === "checkPersonEmail") {

    $e = $_POST["email"];

    $sql = "SELECT * FROM pessoa WHERE pes_email = '$e'";
    $result = mysqli_query($conn, $sql);

    echo json_encode([
        "exists" => mysqli_num_rows($result) > 0
    ]);
    exit;
}

else if ($type == "sessionSetStepEmail") {
    session_start();
    $_SESSION['step'] = "email";
}


// ===============================
// A PARTIR DAQUI É OBRIGATÓRIO LOGIN
// ===============================


session_start();

if (!isset($_SESSION['aluno_id']) && !isset($_SESSION['adm_pes_id'])) {
    echo json_encode(["error" => "Not Logged In"]);
    exit;
}


$pessoa_id = isset($_SESSION['aluno_id']) ? $_SESSION['aluno_id'] : null;
$admin_id = isset($_SESSION['adm_pes_id']) ? $_SESSION['adm_pes_id'] : null;

  
$queryType = $_GET['type'];
$jsonObject = [];


//Buscar todas as senhas
if ($queryType == "fetchCalenderEvents") {
    $year = $_GET['year'];
    $month = $_GET['month'];
    $eventType = $_GET['eventType'];
    $userId = $_GET['userId'] ?? null;
   
    $pesId = $userId ? $userId : $pessoa_id;
    

    $initquery = "select senha_id as sen_id, senha_data as sen_data, tipo_senha as tps_descricao from view_historico_senhas_aluno where pessoa_id = '$pesId' and month(senha_data) = '$month' and year(senha_data) = '$year' and estado_descricao != 'R' ";

    if ($eventType == "refundable") {
        $initquery = "SELECT s.sen_id, s.sen_data, ts.tps_descricao FROM senha s INNER JOIN tipo_senha ts ON s.sen_tps_id = ts.tps_id INNER JOIN ( SELECT ess.ess_sen_id, est.est_descricao FROM estado_senha ess INNER JOIN estado est ON ess.ess_est_id = est.est_id INNER JOIN ( SELECT ess_sen_id, MAX(ess_id) AS max_ess_id FROM estado_senha GROUP BY ess_sen_id ) latest ON ess.ess_sen_id = latest.ess_sen_id AND ess.ess_id = latest.max_ess_id ) latest_estado ON s.sen_id = latest_estado.ess_sen_id WHERE s.sen_pes_id = '$pesId' AND MONTH(s.sen_data) = '$month' AND YEAR(s.sen_data) = '$year' AND latest_estado.est_descricao = 'A' AND s.sen_data >= NOW() - INTERVAL 48 HOUR ORDER BY s.sen_data";
    }
    else if ($eventType == "expire") {
        $initquery = "SELECT s.sen_id, s.sen_data, ts.tps_descricao FROM senha s INNER JOIN tipo_senha ts ON s.sen_tps_id = ts.tps_id INNER JOIN ( SELECT ess.ess_sen_id, est.est_descricao FROM estado_senha ess INNER JOIN estado est ON ess.ess_est_id = est.est_id INNER JOIN ( SELECT ess_sen_id, MAX(ess_id) AS max_ess_id FROM estado_senha GROUP BY ess_sen_id ) latest ON ess.ess_sen_id = latest.ess_sen_id AND ess.ess_id = latest.max_ess_id ) latest_estado ON s.sen_id = latest_estado.ess_sen_id WHERE s.sen_pes_id = '$pesId' AND MONTH(s.sen_data) = '$month' AND YEAR(s.sen_data) = '$year' AND latest_estado.est_descricao = 'A' AND s.sen_data <= NOW() - INTERVAL 48 HOUR ORDER BY s.sen_data";
    }

    $q = mysqli_query($conn, $initquery);
    $allRows = [];
    if (mysqli_num_rows($q) != 0) {
        while ($f = mysqli_fetch_assoc($q)) {
            $start = preg_replace('/\s.*$/', '', $f['sen_data']);
            $end = preg_replace('/\s.*$/', '', $f['sen_data']);
            $color = "";

            if ($f['tps_descricao'] == "Jantar") {
                $color = "red";
            }

            if ($f['tps_descricao'] == "Jantar") {
                $start .= 'T00:01:00';
                $end .= 'T00:02:00';
            } else {
                $start .= 'T00:00:00';
                $end .= 'T00:01:00';
            }

            $allRows[] = [
                "title" => $f['tps_descricao'],
                "start" => $start,
                "end" => $end,
                "color" => $color,
                "id" => $f['sen_id']
            ];
        }
    }

    $jsonObject = $allRows;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}


//Buscar informaçoes sobre a senha
else if ($queryType == "fetchCalendarEventInfo") {
    $eventId = isset($_GET['eventId']) ? $_GET['eventId'] : null;
    if (!$eventId) {
        header('Content-Type: application/json');
        echo json_encode(["error" => "eventId não fornecido"]);
        exit;
    }

    $q = mysqli_query($conn, "select s.sen_data, ts.tps_descricao from senha s inner join tipo_senha ts on s.sen_tps_id = ts.tps_id where s.sen_id = $eventId");
    if (mysqli_num_rows($q) != 0) {
        $fassoc = mysqli_fetch_assoc(($q));
        $estado = null;
        $prato = null;
        $pratoName = null;
        $extras = null;

        //FIND ESTADO
        $estadoquery = mysqli_query($conn, "select estado.est_descricao as estado_descricao from estado, estado_senha where estado_senha.ess_sen_id = '$eventId' and estado_senha.ess_est_id = estado.est_id order by estado_senha.ess_id desc limit 1");

        if (mysqli_num_rows($estadoquery) != 0) {
            $estadofetch = mysqli_fetch_assoc($estadoquery);
            $estado = $estadofetch['estado_descricao'];
        }

        //FIND PRATO
        $pratoquery = mysqli_query($conn, "select p.pra_tipo as tipo, p.pra_nome from senha s inner join menu_dia_prato mdp on s.sen_mdp_id = mdp.mdp_id inner join prato p on mdp.mdp_pra_id = p.pra_id where s.sen_id = '$eventId'");

        if (mysqli_num_rows($pratoquery) != 0) {
            $pratofetch = mysqli_fetch_assoc($pratoquery);
            $prato = $pratofetch['tipo'];
            $pratoName = $pratofetch['pra_nome'];
        }

        //FIND EXTRAS
        $extraquery = mysqli_query($conn, "select e.ext_id, e.ext_nome from senha_extra se inner join extras e on se.sex_ext_id = e.ext_id where se.sex_sen_id = '$eventId'");

        if (mysqli_num_rows($extraquery) != 0) {
            while ($extrafetch = mysqli_fetch_assoc($extraquery)) {
                $extras[] = ["ext_id" => $extrafetch["ext_id"], "ext_nome" => $extrafetch['ext_nome']];
            }
        }

        $jsonObject['descricao'] = $fassoc['tps_descricao'];
        $jsonObject['data_senha'] = $fassoc['sen_data'];
        $jsonObject['estado'] = $estado;
        $jsonObject['prato'] = $prato;
        $jsonObject['pratoName'] = $pratoName;
        $jsonObject['extras'] = $extras ? json_encode($extras) : null;
    } else {
        $jsonObject = ["error" => "Senhas não encontrados"];
    }
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}


//buscar pratos disponisevis para a dia selecionada
else if ($queryType == "triggerAgendarSenhaModal") {
    $date = $_GET['date'];
    $dateObj = new DateTime($date);
    $dateConverted = $dateObj->format("Y");
    $blockedDays = getBlockedDays($dateConverted);

    if (in_array($date, $blockedDays)) {
        $jsonObject['status'] = "error, blocked day";
        header('Content-Type: application/json');
        echo json_encode($jsonObject);
        exit;
    }

    $q1 = mysqli_query($conn, "select s.sen_id from senha s, tipo_senha ts where s.sen_tps_id = ts.tps_id and s.sen_pes_id = '$pessoa_id' and date(s.sen_data) = '$date'");
    $numq1 = mysqli_num_rows($q1);

    if ($numq1 > 1) {
        $jsonObject['status'] = "already exists";
        header('Content-Type: application/json');
        echo json_encode($jsonObject);
        exit;
    }

    $q2 = query($conn, "select p.pra_id, p.pra_tipo, p.pra_nome, mdp.mdp_id from prato p inner join menu_dia_prato mdp on mdp.mdp_pra_id = p.pra_id inner join menu_dia mnd on mnd.mnd_id = mdp.mdp_mnd_id where mnd.mnd_data = '$date' and p.pra_estado = 1");

    $pratos = [];
    $mdp_ids = [];
    $names = [];
    while ($row = assoc($q2)) {
        $pratos[$row['pra_id']] = $row['pra_tipo'];
        $names[$row['pra_id']] = $row['pra_nome'];
        $mdp_ids[$row['pra_id']] = $row['mdp_id'];
    }

    $jsonObject['status'] = "success";
    $jsonObject['pratos'] = json_encode($pratos);
    $jsonObject['mdp_ids'] = json_encode($mdp_ids);
    $jsonObject['names'] = json_encode($names);
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

// criar senha
else if ($queryType == "createSenha") {
    $date = $_GET['date'];
    $period = $_GET['periodo'];
    $extras = $_GET['extras'];
    $extrasArray = $extras != "empty" ? explode(',', $extras) : "";
    $mdp_id = $_GET['mdp_id'];

    $q1 = mysqli_query($conn, "select s.sen_id from senha s, tipo_senha ts where s.sen_tps_id = ts.tps_id and s.sen_pes_id = '$pessoa_id' and date(s.sen_data) = '$date' and ts.tps_id = '$period'");
    $numq1 = mysqli_num_rows($q1);

    if ($numq1 != 0) {
        $jsonObject['status'] = "already exists";
        header('Content-Type: application/json');
        echo json_encode($jsonObject);
        exit;
    }


    if ($mdp_id == "empty") {
        $mdp_id_value = "NULL";
    } else {
        $mdp_id_value = $mdp_id;
    }

    $q = query($conn, "insert into senha(sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) values ($mdp_id_value, $period, $pessoa_id, '1', '$date')");
    $senid = mysqli_insert_id($conn);

    $eq = query($conn, "insert into estado_senha(ess_est_id, ess_sen_id) values (1, $senid) ");
    if ($extras != "empty") {
        foreach ($extrasArray as $ex) {
            $q = query($conn, "insert into senha_extra(sex_sen_id, sex_ext_id) values ($senid, $ex)");
        }
    }

    $jsonObject['status'] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

//Buscar o historico de senhas
else if ($type == "fetchSenhaHistory") {
    $currentPage = isset($_GET['currentPage']) ? (int)$_GET['currentPage'] : 1;
    $resultsPerPage = isset($_GET['resultsPerPage']) ? (int)$_GET['resultsPerPage'] : 10;
    $ordenationParam = isset($_GET['ordenationParam']) ? $_GET['ordenationParam'] : null;
    $filterEnable = isset($_GET['filterEnable']) ? $_GET['filterEnable'] : null;

    $offset = ($currentPage - 1) * $resultsPerPage;

    $historyQuery = "SELECT * FROM view_historico_senhas_aluno WHERE pessoa_id = $pessoa_id";
    $totalCountQuery = "SELECT COUNT(*) as count FROM view_historico_senhas_aluno WHERE pessoa_id = $pessoa_id";

    if ($filterEnable) {
        $dateFrom = $_GET['dateFrom'] ?? null;
        $dateUntil = $_GET['dateUntil'] ?? null;
        $estado = $_GET['estado'] ?? null;
        $periodo = $_GET['periodo'] ?? null;
        $pratos = $_GET['pratos'] ?? null;
        $specialEstado = $_GET['specialEstado'] ?? null;

        if ($specialEstado) {
            if ($specialEstado == "refundable") {
                $historyQuery .= " AND senha_data >= NOW() - INTERVAL 48 HOUR AND estado_descricao = 'A'";
                $totalCountQuery .= " AND senha_data >= NOW() - INTERVAL 48 HOUR AND estado_descricao = 'A'";
            }
            else if ($specialEstado == "expired") {
                $historyQuery .= " AND senha_data <= NOW() - INTERVAL 48 HOUR AND estado_descricao = 'A'";
                $totalCountQuery .= " AND senha_data <= NOW() - INTERVAL 48 HOUR AND estado_descricao = 'A'";
            }
        }
        else {
            if ($dateFrom) {
                $historyQuery .= " AND DATE(senha_data) >= '$dateFrom'";
                $totalCountQuery .= " AND DATE(senha_data) >= '$dateFrom'";
            }

            if ($dateUntil) {
                $historyQuery .= " AND DATE(senha_data) <= '$dateUntil'";
                $totalCountQuery .= " AND DATE(senha_data) <= '$dateUntil'";
            }

            if ($estado) {
                $historyQuery .= " AND estado_descricao = '$estado'";
                $totalCountQuery .= " AND estado_descricao = '$estado'";
            }
        }

        if ($periodo) {
            $historyQuery .= " AND tipo_senha = '$periodo'";
            $totalCountQuery .= " AND tipo_senha = '$periodo'";
        }

        if ($pratos) {
            $pratosList = explode(',', $pratos);
            $conditions = [];

            foreach ($pratosList as $p) {
                $p = trim($p);
                if ($p === 'empty') {
                    $conditions[] = "prato_id IS NULL";
                } else {
                    $conditions[] = "prato_id = " . intval($p);
                }
            }

            if ($conditions) {
                $historyQuery .= " AND (" . implode(" OR ", $conditions) . ")";
                $totalCountQuery .= " AND (" . implode(" OR ", $conditions) . ")";
            }
        }


    }

    if ($ordenationParam) {
        switch ($ordenationParam) {
            case "date:asc":
                $historyQuery .= " ORDER BY senha_data ASC";
                break;
            case "date:desc":
                $historyQuery .= " ORDER BY senha_data DESC";
                break;
            case "plate:asc":
                $historyQuery .= " ORDER BY prato_nome ASC";
                break;
            case "plate:desc":
                $historyQuery .= " ORDER BY prato_nome DESC";
                break;
        }
    }

    $historyQuery .= " LIMIT $resultsPerPage OFFSET $offset";

    $result = $conn->query($historyQuery);
    $countResult = $conn->query($totalCountQuery);
    $countAssoc = $countResult->fetch_assoc();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $jsonObject['content'][] = $row;
        }
        $jsonObject['status'] = "success";
    } else {
        $jsonObject['status'] = "Senhas Não Encontrados";
    }


    $jsonObject['totalPages'] = ceil($countAssoc['count'] / $resultsPerPage);
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($type == "fetchChatsUser") {
    $currentPage = isset($_GET['currentPage']) ? (int)$_GET['currentPage'] : 1;
    $resultsPerPage = isset($_GET['resultsPerPage']) ? (int)$_GET['resultsPerPage'] : 2;

    $offset = ($currentPage - 1) * $resultsPerPage;
    $userId = $pessoa_id != null ? $pessoa_id : ($admin_id != null ? $admin_id : null);

    $chatQuery = "SELECT cs.*, ( SELECT m.msg_texto FROM mensagem m WHERE m.msg_csp_id = cs.csp_id ORDER BY m.msg_data DESC LIMIT 1 ) AS latest_msg_text, ( SELECT m.msg_data FROM mensagem m WHERE m.msg_csp_id = cs.csp_id ORDER BY m.msg_data DESC LIMIT 1 ) AS latest_msg_date FROM chat_suporte cs WHERE cs.csp_pes_id = $pessoa_id  ";

    
    $totalCountQuery = "SELECT COUNT(*) as count FROM chat_suporte WHERE csp_pes_id = $pessoa_id";

    $chatQuery .= " ORDER BY latest_msg_date  DESC";
    $chatQuery .= " LIMIT $resultsPerPage OFFSET $offset";

    $result = $conn->query($chatQuery);
    $countResult = $conn->query($totalCountQuery);
    $countAssoc = $countResult->fetch_assoc();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $jsonObject['content'][] = $row;
        }
        $jsonObject['status'] = "success";
    } else {
        $jsonObject['status'] = "Chats Não Encontrados";
    }


    $jsonObject['totalPages'] = ceil($countAssoc['count'] / $resultsPerPage);
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($type == "fetchChatsAdmin") {
    $currentPage = isset($_GET['currentPage']) ? (int)$_GET['currentPage'] : 1;
    $resultsPerPage = isset($_GET['resultsPerPage']) ? (int)$_GET['resultsPerPage'] : 10;
    $chatType = $_GET['chatType'] ?? "5";
    $offset = ($currentPage - 1) * $resultsPerPage;
    $userId = $pessoa_id != null ? $pessoa_id : ($admin_id != null ? $admin_id : null);

    $chatQuery = "SELECT cs.*, ( SELECT m.msg_texto FROM mensagem m WHERE m.msg_csp_id = cs.csp_id ORDER BY m.msg_data DESC LIMIT 1 ) AS latest_msg_text, ( SELECT m.msg_data FROM mensagem m WHERE m.msg_csp_id = cs.csp_id ORDER BY m.msg_data DESC LIMIT 1 ) AS latest_msg_date FROM chat_suporte cs WHERE cs.csp_est_atual_id = $chatType  ";

    
    $totalCountQuery = "SELECT COUNT(*) as count FROM chat_suporte WHERE csp_est_atual_id = $chatType ";

    $chatQuery .= " ORDER BY latest_msg_date  DESC";
    $chatQuery .= " LIMIT $resultsPerPage OFFSET $offset";

    $result = $conn->query($chatQuery);
    $countResult = $conn->query($totalCountQuery);
    $countAssoc = $countResult->fetch_assoc();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $jsonObject['content'][] = $row;
        }
        $jsonObject['status'] = "success";
    } else {
        $jsonObject['status'] = "Chats Não Encontrados";
    }


    $jsonObject['totalPages'] = ceil($countAssoc['count'] / $resultsPerPage);
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if($queryType == "enviarMensagem") {
    $chatId = $_POST['chatId'] ?? null;
    $message = $_POST['message'] ?? null;

    if (!$chatId || !$message) {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, msg params null"]);
        return;
    }

    $latestStateQuery = query($conn, "select cse_est_id from chat_suporte_estado where cse_csp_id = $chatId order by cse_id desc limit 1");
    $latestState = "5";
    if (numrows($latestStateQuery) > 0) {
        $f = assoc($latestStateQuery);
        $latestState = $f['cse_est_id'];
        if ($latestState == "7") {
            $jsonObject['status'] = "refreshPage";
            header('Content-Type: application/json');
            echo json_encode($jsonObject);
            exit;
        }
    }

    $userId = $pessoa_id != null ? $pessoa_id : ($admin_id != null ? $admin_id : null);
    $stmt = $conn->prepare("INSERT INTO mensagem (msg_csp_id, msg_pes_id, msg_texto) VALUES ($chatId, $userId, ?)");
    $stmt->bind_param("s", $message);
    $stmt->execute();
    $stmt->close();

    if ($admin_id != null) {
        $q1 = query($conn, "update chat_suporte set csp_est_atual_id = 6 where csp_id = $chatId");
        $q2 = query($conn, "INSERT INTO chat_suporte_estado (cse_est_id, cse_csp_id) SELECT 6, $chatId FROM dual WHERE NOT EXISTS ( SELECT 1 FROM chat_suporte_estado WHERE cse_est_id = 6 AND cse_csp_id = $chatId )");
    }

    $jsonObject['status'] = "success";
    $jsonObject["msg_id"] = $conn->insert_id;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;


}

else if($queryType == "fetchAllMessagesUser") {
    $chatId = $_GET['chatId'] ?? null;

    if (!$chatId) {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, chatId null"]);
        return;
    }
    

    $q = query($conn, "select * from mensagem where msg_csp_id = $chatId order by msg_data asc");
    $content = [];
    if (numrows($q) > 0) {
        while($f = assoc($q)) {
            $content[] = $f;
        }
    }

    $participantsQuery = query($conn, "SELECT DISTINCT p.pes_id, p.pes_nome, p.pes_apelido, p.pes_email, p.pes_foto FROM mensagem m JOIN pessoa p ON p.pes_id = m.msg_pes_id WHERE m.msg_csp_id = $chatId ORDER BY p.pes_nome");
    $participantsContent = [];
    if (numrows($participantsQuery) > 0) {
        while($f = assoc($participantsQuery)) {
            $participantsContent[] = $f;
        }
    }


    $latestStateQuery = query($conn, "select cse_est_id from chat_suporte_estado where cse_csp_id = $chatId order by cse_id desc limit 1");
    $latestState = "5";
    if (numrows($latestStateQuery) > 0) {
        $f = assoc($latestStateQuery);
        $latestState = $f['cse_est_id'];
    }

    $userId = $pessoa_id != null ? $pessoa_id : ($admin_id != null ? $admin_id : null);
    $jsonObject['content'] = $content;
    $jsonObject['participants'] = $participantsContent;
    $jsonObject['userId'] = $userId;
    $jsonObject['currentChatState'] = $latestState;
    $jsonObject['status'] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;


}

else if ($queryType == "updateChatState") {
    $chatId = $_GET['chatId'] ?? null;
    $state = $_GET['state'] ?? null;
    if (!$chatId || !$state) {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, params not provided"]);
        return;
    }

    $q1 = query($conn, "update chat_suporte set csp_est_atual_id = $state where csp_id = $chatId");
    $q2 = query($conn, "INSERT INTO chat_suporte_estado (cse_est_id, cse_csp_id) SELECT $state, $chatId FROM dual WHERE $state <> ( SELECT cse_est_id FROM chat_suporte_estado WHERE cse_csp_id = $chatId ORDER BY cse_id DESC LIMIT 1 )");

    header('Content-Type: application/json');
    echo json_encode(["status" => "success"]);
    return;
}


else if ($queryType == "reembolsaSenha") {
    $senhaId = $_GET['senhaId'] ?? null;

    if (!$senhaId) {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, senhaId null"]);
        return;
    }
    
    //initial query
    $initquery = queryassoc($conn, "select ess.ess_id, est.est_descricao, ess.ess_data from estado_senha ess join estado est on est.est_id = ess.ess_est_id where ess.ess_sen_id = $senhaId order by ess.ess_id desc limit 1");

    //check if senha exists
    if (!$initquery) {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, senha not found"]);
        return;
    }

    //check if senha foi rembolsado
    if ($initquery['est_descricao'] == "R") {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, senha already refunded"]);
        return;
    }

    //check if senha is not equal to agendado
    if ($initquery['est_descricao'] != "A") {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, senha state not equal to agendado"]);
        return;
    }

    //check if senha is older than 48 hours
    $date = $initquery['ess_data'];
    $timestamp = strtotime($date);
    $now = time();

    $diff = $now - $timestamp;

    if ($diff > 48 * 60 * 60) {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error, senha older than 48 hours"]);
        return;
    }

    //insert refunded state into db
    $stateUpdateQuery  = query($conn, "insert into estado_senha (ess_est_id, ess_sen_id) values (4, $senhaId)");


    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;

} 

// dias a bloquear no calendario
else if($queryType == "holidays") {
    $year = $_GET['year'] ?? date("Y");

    $data = getBlockedDays($year);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

//buscar os pratos disponiveis para uma data
else if ($queryType == "fetchPratosForSenha") {
    $date = $_GET['date'];

    $q2 = query($conn, "select p.pra_id, p.pra_nome, p.pra_tipo, mdp.mdp_id from prato p inner join menu_dia_prato mdp on mdp.mdp_pra_id = p.pra_id inner join menu_dia mnd on mnd.mnd_id = mdp.mdp_mnd_id where mnd.mnd_data = DATE('$date') and p.pra_estado = 1");

    $pratos = [];
    while ($row = assoc($q2)) {
        $pratos[$row['pra_id']] = ["prato_tipo" => $row['pra_tipo'], "mdp" => $row['mdp_id'], "prato_nome" => $row['pra_nome']];
    }

    $jsonObject['status'] = "success";
    $jsonObject['pratos'] = json_encode($pratos);
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

//editar senha
else if ($queryType == "editarSenha") {
    $senhaId = isset($_GET['senhaId']) ? $_GET['senhaId'] : null;
    $mdp_id  = isset($_GET['mdp_id']) ? $_GET['mdp_id'] : null;
    $extras  = isset($_GET['extras']) ? $_GET['extras'] : null;
    $date  = isset($_GET['date']) ? $_GET['date'] : null;

    if ($mdp_id) {
        $q = query($conn, "update senha set sen_mdp_id = $mdp_id where sen_id = $senhaId");
    }

    $q = query($conn, "delete from senha_extra where sex_sen_id = $senhaId");
    
    if ($extras) {
        $extrasArray = explode(',', $extras);
        foreach ($extrasArray as $extra) {
            $extra = trim($extra);
            $q = query($conn, "insert into senha_extra (sex_sen_id, sex_ext_id) values ($senhaId, $extra)");
        }
    }

    if ($date) {
        $iq = queryassoc($conn, "select estado_senha.ess_est_id from estado_senha where ess_sen_id = $senhaId order by ess_id desc limit 1");
        if ($iq['ess_est_id'] == "3") {
             if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                $sqlDate = $date . ' 00:00:00';
                $q = query($conn, "insert into estado_senha (ess_est_id, ess_sen_id) values (1, $senhaId)");
                $q = query($conn, "update senha set sen_data = '$sqlDate' where sen_id = $senhaId");
             }
             else {
                $jsonObject['status'] = "dateError";
                header('Content-Type: application/json');
                echo json_encode($jsonObject);
                exit;
             }
        }
    }

    $jsonObject['status'] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

//buscar todos os pratos disponiveis para a biblioteca tagify, utilizado no filtro no historico.php
else if ($queryType == "fetchAllPratosTagify") {
    $pq = query($conn, "select * from prato");
    $pratos = [];
    if (numrows($pq) > 0) {
        while ($pf = assoc($pq)) {
            $pratos[$pf['pra_id']] = ["prato_nome" => $pf['pra_nome']];
        }
    }

    $jsonObject['status'] = "success";
    $jsonObject['content'] = $pratos;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
} 

else if ($queryType == "fetchSenhaEstadoHistory") {
    $senhaId = $_GET['senhaId'];
    $q = query($conn, "select ess.ess_id, est.est_descricao, ess.ess_data from estado_senha ess join estado est on est.est_id = ess.ess_est_id where ess.ess_sen_id = $senhaId order by ess.ess_data asc");
    $estados = [];

    if (numrows($q) > 0) {
        while ($qf = assoc($q)) {
            $estados[$qf['ess_id']] = ["estado_desc" => $qf['est_descricao'], "data" => $qf['ess_data']];
        }
    }
    $jsonObject['status'] = "success";
    $jsonObject['content'] = $estados;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
} 

else if ($type == "enviarPedidoSuporte") {
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    $stmt = $conn->prepare("INSERT INTO chat_suporte (csp_pes_id, csp_est_atual_id, csp_assunto) VALUES (?, 5, ?)");
    $stmt->bind_param("is", $pessoa_id, $assunto);
    $stmt->execute();
    $insertId = $conn->insert_id;
    $stmt->close();

    $q = query($conn, "insert into chat_suporte_estado (cse_est_id, cse_csp_id) values (5, $insertId)");

    $stmt = $conn->prepare("INSERT INTO mensagem (msg_csp_id, msg_pes_id, msg_texto) VALUES ($insertId, $pessoa_id, ?)");
    $stmt->bind_param("s", $mensagem);
    $stmt->execute();
    $stmt->close();

    $jsonObject['status'] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

























else if ($queryType == "fetchPratosMdpDashboard") {
    $year = $_GET['year'];
    $month = $_GET['month'];
    $allRows = [];
    $q = mysqli_query($conn, "SELECT p.pra_id, p.pra_nome, m.mnd_data, mdp.mdp_id FROM menu_dia_prato mdp JOIN prato p ON mdp.mdp_pra_id = p.pra_id JOIN menu_dia m ON mdp.mdp_mnd_id = m.mnd_id and month(m.mnd_data) = '$month' and year(m.mnd_data) = '$year'");
    if (mysqli_num_rows($q) != 0) {
        while ($f = mysqli_fetch_assoc($q)) {
            $date = $f['mnd_data'];
            $start = $date . "T00:00:00";
            $end = $date . "T00:00:00";

            $allRows[] = [
                "title" => $f['pra_nome'],
                "start" => $start,
                "end" => $end,
                "color" => "",
                "id" => $f['pra_id'],
                "mdp_id" => $f['mdp_id']
            ];
        }
    }

    $jsonObject = $allRows;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "triggerCriarMdpModal") {
    $date = $_GET['date'];
    $dateObj = new DateTime($date);
    $dateConverted = $dateObj->format("Y");
    $blockedDays = getBlockedDays($dateConverted);

    if (in_array($date, $blockedDays)) {
        $jsonObject['status'] = "error, blocked day";
        header('Content-Type: application/json');
        echo json_encode($jsonObject);
        exit;
    }
    $allRows = [];
    $q = query($conn, "SELECT p.pra_id, p.pra_nome, p.pra_tipo FROM prato p WHERE NOT EXISTS ( SELECT 1 FROM menu_dia_prato mdp JOIN menu_dia m ON mdp.mdp_mnd_id = m.mnd_id WHERE mdp.mdp_pra_id = p.pra_id AND m.mnd_data = '$date' ) and p.pra_estado = 1");
        if (mysqli_num_rows($q) != 0) {
        while ($f = mysqli_fetch_assoc($q)) {
            $allRows[$f['pra_id']] = [
                "prato_nome" => $f['pra_nome'],
            ];
        }
    }

    $jsonObject["status"] = "success";
    $jsonObject["content"] = $allRows;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "createMdp") {
    $date = $_GET['date'];
    $pratoId = $_GET['prato'];

    $dayOfWeek = date('w', strtotime($date));

    if ($dayOfWeek == 0 || $dayOfWeek == 6) {
        $jsonObject["status"] = "Erro, weekend";
        header('Content-Type: application/json');
        echo json_encode($jsonObject);
        exit;
    }


    $q1 = query($conn, "insert into menu_dia(mnd_data) values ('$date')");
    $insertedId = mysqli_insert_id($conn);
    $q2 = query($conn , "insert into menu_dia_prato (mdp_mnd_id, mdp_pra_id) values ($insertedId, $pratoId)");
    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "fetchMdpInfo") {
    $mdpId = $_GET['mdp_id'];
    $allRows = [];

    $q = queryassoc($conn, "SELECT mdp.mdp_id, mdp.mdp_estado, ep.est_pra_descricao AS mdp_estado_descricao, p.pra_estado, p.pra_nome, p.pra_tipo, COUNT(s.sen_id) AS vezes_usado FROM menu_dia_prato mdp LEFT JOIN prato p ON mdp.mdp_pra_id = p.pra_id LEFT JOIN estados_prato ep ON mdp.mdp_estado = ep.est_pra_id LEFT JOIN senha s ON mdp.mdp_id = s.sen_mdp_id AND s.sen_data >= DATE_FORMAT(CURDATE(), '%Y-%m-01') WHERE mdp.mdp_id = $mdpId GROUP BY mdp.mdp_id, p.pra_nome, ep.est_pra_descricao");

    $jsonObject["status"] = "success";
    $jsonObject["content"] = $q;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "toggleMdpEstadoButton") {
    $mdpId = $_GET['mdp_id'];
    $toggleState = $_GET['toggleState'];

    $q = query($conn, "update menu_dia_prato set mdp_estado = $toggleState where mdp_id = $mdpId");

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "togglePlateState") {
    $pratoId = $_GET['pratoId'];
    $state = $_GET['state'];

    $q = query($conn, "update prato set pra_estado = $state where pra_id = $pratoId");

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "editPrato") {
    $pratoId = $_GET['pratoId'] ?? null;
    $nome = $_GET['nome'] ?? null;
    $tipo = $_GET['tipo'] ?? null;
    $estado = $_GET['estado'] ?? null;

    if (!$pratoId || !$nome || !$tipo || !$estado) {
        die("Missing required parameters.");
    }
    $stmt = $conn->prepare("UPDATE prato SET pra_nome = ?, pra_tipo = ?, pra_estado = ? WHERE pra_id = ?");
    $stmt->bind_param("ssii", $nome, $tipo, $estado, $pratoId);
    $stmt->execute();
    $stmt->close();


    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "createPrato") {
    $nome = $_GET['nome'] ?? null;
    $tipo = $_GET['tipo'] ?? null;
    $estado = $_GET['estado'] ?? null;

    if (!$nome || !$tipo || !$estado) {
        die("Missing required parameters.");
    }
    $stmt = $conn->prepare("INSERT INTO prato (pra_nome, pra_tipo, pra_estado) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $nome, $tipo, $estado);
    $stmt->execute();
    $stmt->close();


    $jsonObject["status"] = "success";
    $jsonObject["id"] = $conn->insert_id;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($type == "fetchPratosRows") {
    $sql = query($conn, "SELECT prato.*, estados_prato.est_pra_descricao FROM prato, estados_prato where prato.pra_estado = estados_prato.est_pra_id");
    if (numrows($sql) != 0) {
        while ($f = assoc($sql)) {
            $jsonObject['content'][] = $f;
        }
    }

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($type == "fetchExtrasRows") {
    $sql = query($conn, "SELECT extras.*, estados_prato.est_pra_descricao FROM extras, estados_prato where extras.ext_estado = estados_prato.est_pra_id");
    if (numrows($sql) != 0) {
        while ($f = assoc($sql)) {
            $jsonObject['content'][] = $f;
        }
    }

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "createExtra") {
    $nome = $_GET['nome'] ?? null;
    $estado = $_GET['estado'] ?? null;

    if (!$nome || !$estado) {
        die("Missing required parameters.");
    }
    $stmt = $conn->prepare("INSERT INTO extras (ext_nome, ext_estado) VALUES (?, ?)");
    $stmt->bind_param("si", $nome, $estado);
    $stmt->execute();
    $stmt->close();


    $jsonObject["status"] = "success";
    $jsonObject["id"] = $conn->insert_id;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "toggleExtraState") {
    $extraId = $_GET['extraId'];
    $state = $_GET['state'];

    $q = query($conn, "update extras set ext_estado = $state where ext_id = $extraId");

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "editExtra") {
    $extraId = $_GET['extraId'] ?? null;
    $nome = $_GET['nome'] ?? null;
    $estado = $_GET['estado'] ?? null;

    if (!$extraId || !$nome || !$estado) {
        die("Missing required parameters.");
    }
    $stmt = $conn->prepare("UPDATE extras SET ext_nome = ?, ext_estado = ? WHERE ext_id = ?");
    $stmt->bind_param("sii", $nome, $estado, $extraId);
    $stmt->execute();
    $stmt->close();


    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($type == "fetchFaqRows") {
    $sql = query($conn, "SELECT * FROM faq ORDER BY faq_id DESC");
    if (numrows($sql) != 0) {
        while ($f = assoc($sql)) {
            $jsonObject['content'][] = $f;
        }
    }

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "createFaq") {
    $titulo = $_GET['titulo'];
    $conteudo = $_GET['conteudo'];
    
    query($conn, "INSERT INTO faq (faq_titulo, faq_conteudo) VALUES ('$titulo', '$conteudo')");

    $jsonObject["status"] = "success";
    $jsonObject["id"] = $conn->insert_id;
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "editFaq") {
    $faqId = $_GET['faqId'];
    $titulo = $_GET['titulo'];
    $conteudo = $_GET['conteudo'];
    
    query($conn, "UPDATE faq SET faq_titulo = '$titulo', faq_conteudo = '$conteudo' WHERE faq_id = $faqId");

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "getFaqById") {
    $faqId = $_GET['faqId'];
    
    $sql = query($conn, "SELECT * FROM faq WHERE faq_id = $faqId");
    
    if (numrows($sql) > 0) {
        $jsonObject['content'] = assoc($sql);
        $jsonObject["status"] = "success";
    } else {
        $jsonObject["status"] = "error";
    }
    
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "deleteFaq") {
    $faqId = $_GET['faqId'];
    
    query($conn, "DELETE FROM faq WHERE faq_id = $faqId");

    $jsonObject["status"] = "success";
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

else if ($queryType == "markAllNotificationsRead") {
    // Marcar todas as notificações como lidas
    $q = query($conn, "UPDATE notificacao SET not_lida = 1 WHERE not_pes_id = $pessoa_id AND not_lida = 0");
    
    if ($q) {
        $jsonObject["status"] = "success";
    } else {
        $jsonObject["status"] = "error";
        $jsonObject["message"] = mysqli_error($conn);
    }
    
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}
else if ($queryType == "clearNotifications") {
    // Eliminar todas as notificações do utilizador
    $q = query($conn, "DELETE FROM notificacao WHERE not_pes_id = $pessoa_id");
    
    if ($q) {
        $jsonObject["status"] = "success";
    } else {
        $jsonObject["status"] = "error";
        $jsonObject["message"] = mysqli_error($conn);
    }
    
    header('Content-Type: application/json');
    echo json_encode($jsonObject);
    exit;
}

