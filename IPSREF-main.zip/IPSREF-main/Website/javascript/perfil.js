document.addEventListener("DOMContentLoaded", () => {

    // === Mostrar / Ocultar palavra-passe ===
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('pass');

    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', () => {
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;
            togglePassword.querySelector('i').classList.toggle('fa-eye');
            togglePassword.querySelector('i').classList.toggle('fa-eye-slash');
        });
    }

    // === Foto de Perfil ===
    const fotoPerfil = document.getElementById("fotoPerfil");
    const inputFoto = document.getElementById("inputFoto");
    const perfilForm = document.getElementById("perfilForm"); // form principal

    if (fotoPerfil && inputFoto && perfilForm) {
        // Clicar na imagem abre o input file
        fotoPerfil.addEventListener("click", () => inputFoto.click());

        inputFoto.addEventListener("change", () => {
            const file = inputFoto.files[0];
            if (file) {
                // Mostrar preview imediatamente
                const reader = new FileReader();
                reader.onload = e => {
                    fotoPerfil.src = e.target.result;
                };
                reader.readAsDataURL(file);

                // Copiar o ficheiro para o form principal
                const newInput = document.createElement("input");
                newInput.type = "file";
                newInput.name = "foto";
                newInput.files = inputFoto.files;
                newInput.style.display = "none";
                perfilForm.appendChild(newInput);

                // Submeter automaticamente o form principal
                perfilForm.submit();
            }
        });
    }


    // === Campos ===
    const form = document.querySelector("form.info");
    const fields = {
        nome: document.getElementById("nome"),
        apelido: document.getElementById("apelido"),
        email: document.getElementById("email"),
        pass: document.getElementById("pass")
    };

    // Validação ao digitar
    Object.values(fields).forEach(field => {
        field.addEventListener("input", () => validateField(field));
    });

    // Funções de validação
    function setInvalid(field, msg) {
        field.classList.add("invalid");
        field.classList.remove("valid");
        const erro = document.getElementById(field.id + "_error");
        if (erro) erro.textContent = msg;
        return false;
    }

    function setValid(field) {
        field.classList.remove("invalid");
        field.classList.add("valid");
        const erro = document.getElementById(field.id + "_error");
        if (erro) erro.textContent = "";
        return true;
    }

    function validateField(field) {
        const value = field.value.trim();

        switch(field.id) {
            case "nome":
                if (!value) return setInvalid(field, "O nome é obrigatório.");
                if (/[^a-zA-ZÀ-ÿ\s'-]/.test(value)) return setInvalid(field, "O nome não pode conter números.");
                return setValid(field);

            case "apelido":
                if (!value) return setInvalid(field, "O apelido é obrigatório.");
                if (/[^a-zA-ZÀ-ÿ\s'-]/.test(value)) return setInvalid(field, "O apelido não pode conter números.");
                return setValid(field);

           case "email":
                if (!value) return setInvalid(field, "O email é obrigatório.");
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(value)) return setInvalid(field, "Formato de email inválido.");
                return setValid(field);

            case "pass":
                if (!value) return setInvalid(field, "A palavra-passe é obrigatória.");
            
            default:
                return true;
        }
    }

    // Validação ao submeter
    if (form) {
        form.addEventListener("submit", (e) => {
            let valid = true;
            Object.values(fields).forEach(f => {
                if (!validateField(f)) valid = false;
            });
            if (!valid) e.preventDefault();
        });
    }

    // === Botão Editar ===
    const editAllBtn = document.getElementById("editAllBtn");
    if (editAllBtn) {
        editAllBtn.addEventListener("click", () => {
            const inputs = document.querySelectorAll(".field input");
            inputs.forEach(input => {
    if (!input.closest(".locked")) { // remove a condição do pass
        input.readOnly = false;
        input.classList.add("editable");
    }
});
        });
    }
});
