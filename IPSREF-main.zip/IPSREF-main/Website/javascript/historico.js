let totalPages = 0;
const resultsPerPage = 10;
let currentPage = 1;
let activeOrdenationParam = null
let activeFilterParams = {};

function getPaginationRange(currentPage, maxPages) {
    const visibleCount = 5;
    let start = Math.max(1, currentPage - Math.floor(visibleCount / 2));
    let end = start + visibleCount - 1;

    if (end > maxPages) {
        end = maxPages;
        start = Math.max(1, end - visibleCount + 1);
    }

    const pages = [];
    for (let i = start; i <= end; i++) {
        pages.push(i);
    }

    return pages;
}

function initialPaginationRender(totalButtons) {
    const pagButton = document.querySelector(".pagination-buttons");
    pagButton.innerHTML = "";
    for (let i = 0; i < totalButtons; i++) {
        const button = document.createElement("button");
        button.classList.add("page-number");
        button.classList.add(`pg-${i}`);
        pagButton.appendChild(button)
    }
}
function renderPagination(currentPage, maxPages, refresh) {
    if (document.querySelectorAll(".page-number").length == 0 || refresh) {
        initialPaginationRender(maxPages < 5 ? maxPages : 5);
    }

    const visibleCount = getPaginationRange(currentPage, maxPages);

    document.querySelectorAll(".page-number").forEach(e => {
        e.classList.remove("active");
    });

    for (let i = 0; i < (maxPages < 5 ? maxPages : 5); i++) {
        const button = document.querySelector(`.pg-${i}`);
        button.innerHTML = visibleCount[i];
        button.setAttribute("data-page", visibleCount[i]);
        if (visibleCount[i] == currentPage) {
            button.classList.add("active");
        }
    }
}

async function fetchSenhas() {
    try {
        let url = `../api.php?type=fetchSenhaHistory&currentPage=${currentPage}&resultsPerPage=${resultsPerPage}`;

        if (activeOrdenationParam) {
            url += `&ordenationParam=${activeOrdenationParam}`;
        }

        if (Object.keys(activeFilterParams).length > 0) {
            const params = new URLSearchParams();

            Object.entries(activeFilterParams).forEach(([key, value]) => {
                if (value !== null && value !== '') {
                    params.append(key, value);
                }
            });

            const query = params.toString();
            if (query) {
                url += '&filterEnable=true';
                url += '&' + query;
            }
        }
        const response = await fetch(url);
        const data = await response.json();
        if (data.status == "success") {
            totalPages = data.totalPages;
            document.querySelector('.historico-container').innerHTML = "";
            for (let senha of data.content) {
                document.querySelector('.historico-container').innerHTML += `<div class="senha" data-senha-id="${senha.senha_id}">
            <p><strong>Data:</strong> ${senha.senha_data ? senha.senha_data : "N/A"}</p>


            <p style="display: flex; justify-content: space-between; align-items: center;">
            <span><strong>Período:</strong> ${senha.tipo_senha || 'N/A'}</span>
            <i class="fa-solid fa-arrow-right triggerCalenderRedirect pointer" data-senha-id="${senha.senha_id}"></i>
            </p>


           <p style="display: flex; justify-content: space-between; align-items: center;">

            <span>
                <strong>Prato:</strong> ${senha.prato_nome || 'N/A'} 

                ${!senha.prato_nome && senha.estado_descricao == 'A' ? 
                    `<img class="triggerCalenderRedirect" data-senha-id="${senha.senha_id}" width="17px" style="cursor:pointer; margin-bottom:-2px" src="../logos/pencilIcon.svg">` : 
                    ``
                }

            </span>

            <i class="fa-solid fa-circle-info triggerEstadoInfo pointer" data-senha-id="${senha.senha_id}"></i>
           </p>


            <p><strong>Extras: </strong>
            ${senha.extras || "N/A"}
            ${senha.estado_descricao == 'A' ? ` <img class="triggerCalenderRedirect" data-senha-id="${senha.senha_id}" width="17px" style="cursor:pointer; margin-bottom:-2px" src="../logos/pencilIcon.svg">` : ""}
           
            </p>
          </div>`;
            }
        }
        else if (data.status == "Senhas Não Encontrados") {
            totalPages = data.totalPages;
            document.querySelector('.historico-container').innerHTML = "Senhas Não Encontrados";
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}


document.addEventListener("change", async (e) => {
    if (e.target.id == 'filter-specialEstado') {
        const value = e.target.value;
        if (value !== "Nenhum") {
            qs("#filter-startDate").value = null;
            qs("#filter-endDate").value = null;
            qs("#filter-estado").value = "Nenhum";
            qs("#filter-startDate").disabled = true;
            qs("#filter-endDate").disabled = true;
            qs("#filter-estado").disabled = true;
        }
        else {
            qs("#filter-startDate").disabled = false;
            qs("#filter-endDate").disabled = false;
            qs("#filter-estado").disabled = false;
        }
    }
});


document.addEventListener("click", async (e) => {

    if (e.target.classList.contains("triggerCalenderRedirect")) {
        const senhaId = e.target.dataset.senhaId;
        window.open(`calendario.php?senhaId=${senhaId}`, "_blank");
    }

    if (e.target.classList.contains("triggerEstadoInfo")) {
        const senhaElement = e.target.closest(".senha")
        const senhaId = e.target.dataset.senhaId;
        if (!senhaId) return;

        senhaElement.style.borderColor = "rgb(3, 213, 3)";

        await fetchSenhaEstadoHistory(senhaId);

        MicroModal.show('dayInformationModal', {
            onClose: () => {
                senhaElement.style.borderColor = "white";
            }
        });

    }

    if (e.target.classList.contains("sortByOption")) {
        if (!e.target.dataset.option) { return; }
        const ordenationParam = e.target.dataset.option;

        const currentActive = qs('.sortByActive');
        if (currentActive) {
            currentActive.classList.remove("sortByActive");
        }

        if (currentActive != e.target) {
            e.target.classList.toggle("sortByActive")
        }

        activeOrdenationParam = ordenationParam === activeOrdenationParam ? null : ordenationParam;

        activeOrdenationParam === null ? qs('.filterActive-sortBy').classList.add("d-none") : qs('.filterActive-sortBy').classList.remove("d-none");

        currentPage = 1;
        renderPagination(currentPage, totalPages);
        await fetchSenhas();
    }

    if (e.target.classList.contains("page-arrow-previous")) {
        if (currentPage == 1) return;
        currentPage -= 1;
        renderPagination(currentPage, totalPages);
        await fetchSenhas();
    }

    if (e.target.classList.contains("page-arrow-next")) {
        if (currentPage == totalPages) return;
        currentPage += 1;
        renderPagination(currentPage, totalPages);
        await fetchSenhas();
    }

    if (e.target.classList.contains("page-number")) {
        const pageNumber = e.target.dataset.page;
        currentPage = pageNumber;
        renderPagination(currentPage, totalPages);
        await fetchSenhas();
    }
});


function filterWindowHandler(e) {
    const parentElement = e.target.parentElement;

    const currentActiveButton = qs(".title-section-button-active")
    const currentActiveWindow = qs('.floating-window.active');
    const internalElementWindow = parentElement.querySelector(".floating-window");

    if (currentActiveButton) {
        currentActiveButton.classList.remove("title-section-button-active");
    }

    if (currentActiveButton !== e.target) {
        parentElement.querySelector('button').classList.toggle("title-section-button-active");
    }

    if (currentActiveWindow) {
        currentActiveWindow.classList.remove("active");
        currentActiveWindow.classList.add("d-none");
    }

    if (currentActiveWindow != internalElementWindow) {
        internalElementWindow.classList.toggle("d-none");
        internalElementWindow.classList.toggle("active");
    }
}

async function applyFiltersHandler() {
    const dateFrom = qs("#filter-startDate").value || null;
    const dateUntil = qs("#filter-endDate").value || null;
    let estado = qs("#filter-estado").value || null;
    let periodo = qs("#filter-periodo").value || null;
    const pratos = window.tagify ? window.tagify.value.map(tag => tag.id).join(",") : null;
    let specialEstado = qs("#filter-specialEstado").value || null;

    if (estado === "Nenhum") { estado = null; }
    if (periodo === "Nenhum") { periodo = null; }
    if (specialEstado === "Nenhum") { specialEstado = null; }

    activeFilterParams = { dateFrom: dateFrom, dateUntil: dateUntil, estado: estado, periodo: periodo, pratos: pratos, specialEstado: specialEstado };
    const activeCount = Object.values(activeFilterParams).filter(v => v !== null && v !== '').length;
    qsin(".filterActive-filterBy", activeCount);
    qs(".filterActive-filterBy").classList.remove("d-none");
    currentPage = 1;
    await fetchSenhas();
    renderPagination(currentPage, totalPages, true);
}

async function removeFiltersHandler() {
    qs("#filter-startDate").value = '';
    qs("#filter-endDate").value = '';
    qs("#filter-estado").value = 'Nenhum';
    qs("#filter-periodo").value = 'Nenhum';
    qs("#filter-specialEstado").value = 'Nenhum';

    qs("#filter-startDate").disabled = false;
    qs("#filter-endDate").disabled = false;
    qs("#filter-estado").disabled = false;


    if (window.tagify) {
        window.tagify.removeAllTags();
    }

    activeFilterParams = {};
    currentPage = 1;
    qs(".filterActive-filterBy").classList.add("d-none");
    await fetchSenhas();
    renderPagination(currentPage, totalPages, true);
}

async function fetchSenhaEstadoHistory(senhaId) {
    try {
        const response = await fetch(`../api.php?type=fetchSenhaEstadoHistory&senhaId=${senhaId}`);
        const data = await response.json();
        if (data.error && data.error === "Not Logged In") { window.location.href = "login.php"; return; }

        if (data.status && data.status == "success") {
            const estados = data.content;
            let html = ``;
            const estadoMap = {
                "A": "Senha Agendada",
                "U": "Senha Utilizada",
                "PA": "Senha por Agendar",
                "R": "Senha Reembolsada",
                "C": "Chat Criado",
                "CEC": "Chat em Curso",
                "F": "Chat Fechado"
            };

            for (const [id, estado] of Object.entries(estados)) {
                html += `
                    <tr>
                        <th>${estadoMap[estado.estado_desc] || "-"}:</th>
                        <td>${estado.data}</td>
                    </tr>
                `;
            }
            qsin("#senha-estadoHistorico-tbody", html);
            qs("#dayInformationModal-trigger").click();
        }
        else {
            genericErr();
        }

    }
    catch (e) {
        genericErr();
    }
}

document.addEventListener("DOMContentLoaded", async (event) => {
    MicroModal.init({
        awaitOpenAnimation: true
    });


    await fetchSenhas();
    renderPagination(currentPage, totalPages);

    const pratoRequest = await fetch("../api.php?type=fetchAllPratosTagify");
    const pratoData = await pratoRequest.json();

    if (pratoData.error && pratoData.error === "Not Logged In") { window.location.href = "login.php"; return; }

    if (pratoData.status && pratoData.status === "success" && Object.keys(pratoData.content).length > 0) {
        const whitelist = Object.entries(pratoData.content).map(([id, obj]) => ({
            id: id,
            value: obj.prato_nome
        }));

        whitelist.push({ id: "empty", value: "Prato Vazio" });

        var input = document.querySelector('input[name="input-custom-dropdown"]');
        window.tagify = new Tagify(input, {
            whitelist: whitelist,
            maxTags: 10,
            dropdown: {
                maxItems: 10,
                classname: 'tags-look',
                enabled: 0,
                closeOnSelect: false
            }
        })
    }

    qs('#sort-by-button').addEventListener('click', filterWindowHandler);
    qs('#filter-by-button').addEventListener('click', filterWindowHandler);

    qs("#apply-filtersHistorico-button").addEventListener('click', applyFiltersHandler);
    qs("#remove-filtersHistorico-button").addEventListener('click', removeFiltersHandler);

});