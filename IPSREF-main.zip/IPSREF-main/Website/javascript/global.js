// ===============================
// start util functions //
// ===============================

function qs(el) {
  return document.querySelector(el);
}

function qsin(el, content) {
  document.querySelector(el).innerHTML = content;
}

function qsinplus(el, content) {
  document.querySelector(el).innerHTML += content;
}

function cl(el) {
  console.log(el)
}

async function apiFetch(url, options = {}, errRedir = "login.php") {
  try {
    const res = await fetch(url, options);

    if (!res.ok) {
      throw new Error(`HTTP error! status: ${res.status}`);
    }

    const data = await res.json();
    if (data.error && data.error == "Not Logged In") {
      window.location.href = errRedir;
      return;
    }
    return data;
  } catch (err) {
    console.error("Fetch error:", err);
    throw err;
  }
}

// ===============================
// end util functions //
// ===============================