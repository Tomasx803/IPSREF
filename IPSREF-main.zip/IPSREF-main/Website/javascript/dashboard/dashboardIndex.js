function renderCalendar(userId) {
    const calendarEl = document.querySelector('.app-modal__content');
    let selectedEventType = 'all';

    window.calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: "pt-pt",
        selectable: true,
        dayHeaderFormat: { weekday: 'short' },
        titleFormat: info => {
            const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
            const month = monthNames[info.date.month];
            return `${month} ${info.date.year}`;
        },
        headerToolbar: { left: 'prev', center: 'title', right: 'next' },

        editable: true,
        events: function (info, successCallback) {
            const dateObj = new Date(info.start);
            if (dateObj.getDate() != 1) {
                dateObj.setDate(1);
                dateObj.setMonth(dateObj.getMonth() + 1);
            }
            const year = dateObj.getFullYear();
            const month = dateObj.getMonth() + 1;

            fetch(`../api.php?type=fetchCalenderEvents&year=${year}&month=${month}&eventType=all&userId=${userId}`)
                .then(r => r.json())
                .then(data => successCallback(data))
                .catch(() => genericErr());
        },
        eventDidMount: info => { info.el.style.fontSize = '12px'; },
        dayMaxEvents: true,
        eventClick: async info => {
            document.querySelectorAll('.fc-popover').forEach(p => p.remove());
            await fetchCalendarEventInfo(info.event.id);
        }
    });

    calendar.render();
    calendar.setOption('height', 691);
    calendar.setOption('aspectRatio', 3.8);

    document.querySelectorAll(".fc-button-primary").forEach(el => el.classList.remove("fc-button-primary"));
}

async function fetchCalendarEventInfo(eventId) {
    try {
        const ft = await fetch(`../api.php?type=fetchCalendarEventInfo&eventId=${eventId}`)
        const data = await ft.json();
        if (data.error && data.error === "Senha não encontrados") {
            notify("error", "Erro!", "Não existe senhas para este dia");
            return;
        }
        else if (data.error && data.error === "Not Logged In") {
            window.location.href = "login.php";
            return;
        }
        else {
            const estadoMap = {
                "A": "Agendado",
                "U": "Utilizado",
                "PA": "Por Agendar",
                "C": "Chat Criado",
                "R": "Reembolsado",
                "CEC": "Chat em Curso",
                "F": "Fechado",
            };
            qsin("#tipo-senha", data.descricao);
            qsin("#dataCompra-senha", data.data_senha.split(' ')[0]);
            qsin("#estado-senha", estadoMap[data.estado] || "-");
            qsin("#prato-senha", (data.prato?.length > 0) ? data.pratoName + " - " + data.prato : "Para Escolher");
            qsin("#extras-senha", data.extras ? JSON.parse(data.extras).map(item => item.ext_nome).join(', ') : '-');

            qs("#dayInformationModal2-trigger").click();

        }
    }
    catch (err) {
        genericErr();
    }
}


document.addEventListener("click", (event) => {
    if (event.target.classList.contains("senhasUserClass")) {
        const userId = event.target.dataset.userId;
        renderCalendar(userId);
        qs('#senhasUserSpan').innerHTML = event.target.closest('tr').querySelector('td').innerHTML
        qs("#dayInformationModal-trigger").click();

    }
});


document.addEventListener("DOMContentLoaded", (event) => {

    MicroModal.init({
        awaitOpenAnimation: true
    });

    let table = new DataTable('#tabelaAlunos', {
        pageLength: 10,
        language: {
            decimal: ",",
            thousands: ".",
            lengthMenu: "Mostrar _MENU_ linhas",
            zeroRecords: "Nenhum linha encontrado",
            info: "A mostrar _START_ a _END_ de _TOTAL_ linhas",
            infoEmpty: "A mostrar 0 a 0 de 0 linhas",
            infoFiltered: "(filtrado de _MAX_ registros no total)",
            search: "Pesquisar:",
            paginate: {
                first: "«",
                previous: "‹",
                next: "›",
                last: "»"
            },
        },
    });
});
