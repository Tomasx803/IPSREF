const apiPath = "../api.php?type=";

function initializeDataTable() {
    if (window.table && $.fn.DataTable.isDataTable(window.table.table().node())) {
        window.table.clear().destroy();
        window.table = null; 
    }
    window.table = new DataTable('#tabelaAlunos', {
        pageLength: 10,
        language: {
            decimal: ",",
            thousands: ".",
            lengthMenu: "Mostrar _MENU_ linhas",
            zeroRecords: "Nenhum linha encontrado",
            info: "A mostrar _START_ a _END_ de _TOTAL_ linhas",
            infoEmpty: "A mostrar 0 a 0 de 0 linhas",
            infoFiltered: "(filtrado de _MAX_ registros no total)",
            search: "Pesquisar:",
            paginate: {
                first: "«",
                previous: "‹",
                next: "›",
                last: "»"
            },
        },
        createdRow: function (row, data, dataIndex) {
            $('td', row).eq(0).addClass('id');
            $('td', row).eq(1).addClass('name');
            $('td', row).eq(2).addClass('estado');
            $('td', row).eq(3).addClass('actions');
        }
    });
    //qs(".dt-search").innerHTML += `<i style="margin-left:20px" class="fa-solid fa-plus pointer" onclick="qs('#criarExtra-trigger').click();"></i>`

    const searchContainer = qs(".dt-search");
    if (searchContainer) {
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-plus pointer";
        icon.style.marginLeft = "20px"
        icon.addEventListener("click", function(e) {
            qs('#criarExtra-trigger').click();
        })
        searchContainer.appendChild(icon); 
    }
}

async function fetchContent() {
    try {
        const r = await apiFetch(`${apiPath}fetchExtrasRows`);
        if (r.status && r.status == "success") {
            qs('#extrasTableTBody').innerHTML = "";
            let increment = 0;
            let html = '';

            for (const item of r.content) {
                html += `
                <tr id="row-${item.ext_id}">
                    <td data-increment="${increment}" class="id">${item.ext_id}</td>
                    <td class="name">${item.ext_nome}</td>
                    <td class="estado">${item.est_pra_descricao}</td>
                    <td style="width: 20px !important;">
                        <div class="dropdown">
                            <button class="dropbtn">
                                <img src="../logos/ellipsisIcon.svg" class="pointer" data-extra-id="${item.ext_id}" width="20">
                            </button>
                            <div class="dropdown-content">
                                <a class="toggleExtraState" data-increment="${increment}" data-state="${item.ext_estado == "1" ? "2" : "1"}" data-extra-id="${item.ext_id}">
                                    ${item.est_pra_descricao == "Ativo" ? "Desativar" : "Ativar"} Extra
                                </a>
                                <a class="editarExtraTrigger" data-increment="${increment}" data-state="${item.ext_estado}" data-extra-id="${item.ext_id}">
                                    Editar Extra
                                </a>
                            </div>
                        </div>
                    </td>
                </tr>
            `;
                increment++; 
            }

            document.querySelector('#extrasTableTBody').innerHTML = html;
            

        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}


document.addEventListener("click", async (event) => {
    const tgDataset = event.target.dataset;
    const tgClass = event.target.classList;
    const tg = event.target;

    if (tgClass.contains("criarExtraButton")) {
        const name = document.querySelector("#nome-criarExtra").value;
        const estado = document.querySelector("#estado-criarExtra").value;

        if (name.length == 0) {
            notify("error", "Erro!", "O nome não pode estar vazio");
            return;
        }

        const r = await apiFetch(`${apiPath}createExtra&nome=${name}&estado=${estado}`);
        if (r.status && r.status == "success") {
            notify("success", "Sucesso!", `A extra foi criado com sucesso!`);
            var currentPage = window.table.page();
            window.table.clear().destroy();
            window.table = null; 
            await fetchContent();
            initializeDataTable();
            window.table.page(currentPage).draw('page');
        }
        else {
            genericErr();
        }

    }


    if (tgClass.contains("editarExtraButton")) {
        const extraId = tgDataset.extraId;
        const increment = tgDataset.increment;
        const name = document.querySelector("#nome-editarExtra").value;
        const estado = document.querySelector("#estado-editarExtra").value;

        if (name.length == 0) {
            notify("error", "Erro!", "O nome não pode estar vazio");
            return;
        }
        const r = await apiFetch(`${apiPath}editExtra&extraId=${extraId}&nome=${name}&estado=${estado}`);
        if (r.status && r.status == "success") {
            notify("success", "Sucesso!", `A extra com ID ${extraId} foi atualizada com sucesso!`);
            window.table.cell(increment, 1).data(name);
            window.table.cell(increment, 2).data(estado == "1" ? "Ativo" : "Desativado");
            window.table.draw(false);
            qs(`.toggleExtraState[data-increment="${increment}"]`).dataset.state = estado == "1" ? "2" : "1";
            qs(`.toggleExtraState[data-increment="${increment}"]`).innerHTML = estado == "1" ? "Desativar Extra" : "Ativar Extra"
        }
        else {
            genericErr();
        }
    }


    if (tgClass.contains("editarExtraTrigger")) {
        const extraId = tgDataset.extraId;
        const state = tgDataset.state;
        const name = tg.closest('tr').querySelector('.name').innerHTML;
        document.querySelector("#nome-editarExtra").value = name;
        document.querySelector("#estado-editarExtra").value = state;
        document.querySelector(".editarExtraButton").dataset.extraId = extraId;
        document.querySelector(".editarExtraButton").dataset.increment = tgDataset.increment;
        qs("#modal-1-trigger").click();
    }


    if (tgClass.contains("toggleExtraState")) {
        const extraId = tgDataset.extraId;
        const state = tgDataset.state;
        const increment = tgDataset.increment;
        const r = await apiFetch(`${apiPath}toggleExtraState&extraId=${extraId}&state=${state}`);
        if (r.status && r.status == "success") {
            notify("success", "Sucesso!", "O estado da extra foi atualizada com sucesso!");
            window.table.cell(increment, 2).data(state == "1" ? "Ativo" : "Desativado");
            window.table.draw(false);
            tgDataset.state = state == "1" ? "2" : "1";
            tg.innerHTML = state == "1" ? "Desativar Extra" : "Ativar Extra"
        }
        else {
            genericErr();
        }
    }

});


document.addEventListener("DOMContentLoaded", async (event) => {
    MicroModal.init({
        awaitOpenAnimation: true
    });

    await fetchContent();
    initializeDataTable();

});
