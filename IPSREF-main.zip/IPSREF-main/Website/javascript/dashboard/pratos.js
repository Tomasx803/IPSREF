const apiPath = "../api.php?type=";

function initializeDataTable() {
    if (window.table && $.fn.DataTable.isDataTable(window.table.table().node())) {
        window.table.clear().destroy();
        window.table = null; 
    }
    window.table = new DataTable('#tabelaAlunos', {
        pageLength: 10,
        language: {
            decimal: ",",
            thousands: ".",
            lengthMenu: "Mostrar _MENU_ linhas",
            zeroRecords: "Nenhum linha encontrado",
            info: "A mostrar _START_ a _END_ de _TOTAL_ linhas",
            infoEmpty: "A mostrar 0 a 0 de 0 linhas",
            infoFiltered: "(filtrado de _MAX_ registros no total)",
            search: "Pesquisar:",
            paginate: {
                first: "«",
                previous: "‹",
                next: "›",
                last: "»"
            },
        },
        createdRow: function (row, data, dataIndex) {
            $('td', row).eq(0).addClass('id');
            $('td', row).eq(1).addClass('name');
            $('td', row).eq(2).addClass('tipo');
            $('td', row).eq(3).addClass('estado');
            $('td', row).eq(4).addClass('actions');
        }
    });

    
    const searchContainer = qs(".dt-search");
    if (searchContainer) {
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-plus pointer";
        icon.style.marginLeft = "20px";
        icon.addEventListener("click", () => {
            qs('#criarPrato-trigger').click();
        });
        searchContainer.appendChild(icon); 
    }
}

async function fetchContent() {
    try {
        const r = await apiFetch(`${apiPath}fetchPratosRows`);
        if (r.status && r.status == "success") {
            qs('#pratoTableTBody').innerHTML = "";
            let increment = 0;
            let html = '';

            for (const item of r.content) {
                html += `
                <tr id="row-${item.pra_id}">
                    <td data-increment="${increment}" class="id">${item.pra_id}</td>
                    <td class="name">${item.pra_nome}</td>
                    <td class="tipo">${item.pra_tipo}</td>
                    <td class="estado">${item.est_pra_descricao}</td>
                    <td style="width: 20px !important;">
                        <div class="dropdown">
                            <button class="dropbtn">
                                <img src="../logos/ellipsisIcon.svg" class="pointer" data-prato-id="${item.pra_id}" width="20">
                            </button>
                            <div class="dropdown-content">
                                <a class="togglePlateState" data-increment="${increment}" data-state="${item.pra_estado == "1" ? "2" : "1"}" data-plate-id="${item.pra_id}">
                                    ${item.est_pra_descricao == "Ativo" ? "Desativar" : "Ativar"} Prato
                                </a>
                                <a class="editarPratoTrigger" data-increment="${increment}" data-state="${item.pra_estado}" data-plate-id="${item.pra_id}">
                                    Editar Prato
                                </a>
                            </div>
                        </div>
                    </td>
                </tr>
            `;
                increment++; 
            }

            document.querySelector('#pratoTableTBody').innerHTML = html;
            

        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}


document.addEventListener("click", async (event) => {
    const tgDataset = event.target.dataset;
    const tgClass = event.target.classList;
    const tg = event.target;

    if (tgClass.contains("criarPratoButton")) {
        const name = document.querySelector("#nome-criarPrato").value;
        const tipo = document.querySelector("#tipo-criarPrato").value;
        const estado = document.querySelector("#estado-criarPrato").value;

        if (name.length == 0) {
            notify("error", "Erro!", "O nome não pode estar vazio");
            return;
        }

        const r = await apiFetch(`${apiPath}createPrato&nome=${name}&tipo=${tipo}&estado=${estado}`);
        if (r.status && r.status == "success") {
            notify("success", "Sucesso!", `O prato foi criado com sucesso!`);
            var currentPage = window.table.page();
            window.table.clear().destroy();
            window.table = null; 
            await fetchContent();
            initializeDataTable();
            window.table.page(currentPage).draw('page');
        }
        else {
            genericErr();
        }

    }


    if (tgClass.contains("editarPratoButton")) {
        const pratoId = tgDataset.pratoId;
        const increment = tgDataset.increment;
        const name = document.querySelector("#nome-editarPrato").value;
        const tipo = document.querySelector("#tipo-editarPrato").value;
        const estado = document.querySelector("#estado-editarPrato").value;

        if (name.length == 0) {
            notify("error", "Erro!", "O nome não pode estar vazio");
            return;
        }
        const r = await apiFetch(`${apiPath}editPrato&pratoId=${pratoId}&nome=${name}&tipo=${tipo}&estado=${estado}`);
        if (r.status && r.status == "success") {
            notify("success", "Sucesso!", `O prato com ID ${pratoId} foi atualizado com sucesso!`);
            window.table.cell(increment, 1).data(name);
            window.table.cell(increment, 2).data(tipo);
            window.table.cell(increment, 3).data(estado == "1" ? "Ativo" : "Desativado");
            window.table.draw(false);
            qs(`.togglePlateState[data-increment="${increment}"]`).dataset.state = estado == "1" ? "2" : "1";
            qs(`.togglePlateState[data-increment="${increment}"]`).innerHTML = estado == "1" ? "Desativar Prato" : "Ativar Prato"
        }
        else {
            genericErr();
        }
    }


    if (tgClass.contains("editarPratoTrigger")) {
        const pratoId = tgDataset.plateId;
        const state = tgDataset.state;
        const name = tg.closest('tr').querySelector('.name').innerHTML;
        const tipo = tg.closest('tr').querySelector('.tipo').innerHTML;
        document.querySelector("#nome-editarPrato").value = name;
        document.querySelector("#tipo-editarPrato").value = tipo;
        document.querySelector("#estado-editarPrato").value = state;
        document.querySelector(".editarPratoButton").dataset.pratoId = pratoId;
        document.querySelector(".editarPratoButton").dataset.increment = tgDataset.increment;
        qs("#modal-1-trigger").click();
    }


    if (tgClass.contains("togglePlateState")) {
        const pratoId = tgDataset.plateId;
        const state = tgDataset.state;
        const increment = tgDataset.increment;
        const r = await apiFetch(`${apiPath}togglePlateState&pratoId=${pratoId}&state=${state}`);
        if (r.status && r.status == "success") {
            notify("success", "Sucesso!", "O estado do prato foi atualizado com sucesso!");
            window.table.cell(increment, 3).data(state == "1" ? "Ativo" : "Desativado");
            window.table.draw(false);
            tgDataset.state = state == "1" ? "2" : "1";
            tg.innerHTML = state == "1" ? "Desativar Prato" : "Ativar Prato"
        }
        else {
            genericErr();
        }
    }

});


document.addEventListener("DOMContentLoaded", async (event) => {
    MicroModal.init({
        awaitOpenAnimation: true
    });

    await fetchContent();
    initializeDataTable();

});
