let totalPages = 0;
const resultsPerPage = 10;
let currentPage = 1;
let activeOrdenationParam = "5"

function getPaginationRange(currentPage, maxPages) {
    const visibleCount = 5;
    let start = Math.max(1, currentPage - Math.floor(visibleCount / 2));
    let end = start + visibleCount - 1;

    if (end > maxPages) {
        end = maxPages;
        start = Math.max(1, end - visibleCount + 1);
    }

    const pages = [];
    for (let i = start; i <= end; i++) {
        pages.push(i);
    }

    return pages;
}

function initialPaginationRender(totalButtons) {
    const pagButton = document.querySelector(".pagination-buttons");
    pagButton.innerHTML = "";
    for (let i = 0; i < totalButtons; i++) {
        const button = document.createElement("button");
        button.classList.add("page-number");
        button.classList.add(`pg-${i}`);
        pagButton.appendChild(button)
    }
}
function renderPagination(currentPage, maxPages, refresh) {
    if (document.querySelectorAll(".page-number").length == 0 || refresh) {
        initialPaginationRender(maxPages < 5 ? maxPages : 5);
    }

    const visibleCount = getPaginationRange(currentPage, maxPages);

    document.querySelectorAll(".page-number").forEach(e => {
        e.classList.remove("active");
    });

    for (let i = 0; i < (maxPages < 5 ? maxPages : 5); i++) {
        const button = document.querySelector(`.pg-${i}`);
        button.innerHTML = visibleCount[i];
        button.setAttribute("data-page", visibleCount[i]);
        if (visibleCount[i] == currentPage) {
            button.classList.add("active");
        }
    }
}

async function fetchChats() {
    try {
        let url = `../api.php?type=fetchChatsAdmin&currentPage=${currentPage}&resultsPerPage=${resultsPerPage}&chatType=${activeOrdenationParam}`;
        const response = await fetch(url);
        const data = await response.json();
        const estadoMap = {
            "1": "Senha Agendada",
            "2": "Senha Utilizada",
            "3": "Senha por Agendar",
            "4": "Senha Reembolsada",
            "5": "Chat Criado",
            "6": "Chat em Curso",
            "7": "Chat Fechado"
        };
        if (data.status == "success") {
            totalPages = data.totalPages;
            document.querySelector('.historico-container').innerHTML = "";


            for (let chat of data.content) {
                document.querySelector('.historico-container').innerHTML += `<div class="senha chat pointer" data-chat-id="${chat.csp_id}">
            <p><strong>Assunto:</strong> ${chat.csp_assunto ? chat.csp_assunto : "N/A"}</p>


            <p style="display: flex; justify-content: space-between; align-items: center;">
            <span>
            <strong>Mensagem:</strong> 
            ${chat.latest_msg_text
                        ? (chat.latest_msg_text.length > 40
                            ? chat.latest_msg_text.slice(0, 40) + '...'
                            : chat.latest_msg_text)
                        : 'N/A'}
            </span>  
            </p>


           <p style="display: flex; justify-content: space-between; align-items: center;">

            <span>
            <strong>Data:</strong> 
            ${chat.latest_msg_date
                        ? new Date(chat.latest_msg_date).toISOString().split('T')[0]
                        : 'N/A'}
            </span>
           </p>


            <p><strong>Estado: </strong>
            ${estadoMap[chat.csp_est_atual_id] || "N/A"}
           
            </p>
          </div>`;
            }
        }
        else if (data.status == "Chats Não Encontrados") {
            totalPages = data.totalPages;
            document.querySelector('.historico-container').innerHTML = "Chats Não Encontrados";
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr(e);
    }
}



document.addEventListener("click", async (e) => {

    const tg = e.target;
    const tgClass = e.target.classList;
    const tgClassParent = e.target.parentElement;

    if (tgClass.contains("chat") || tgClassParent.classList.contains("chat")) {
        const chatId = tgClass.contains("chat") ? tg.dataset.chatId : tgClassParent.dataset.chatId;
        if (!chatId) return;

        window.location.href = `chat.php?chatId=${chatId}`;
    }

    if (e.target.classList.contains("chatOption")) {
        if (!e.target.dataset.option) { return; }
        const ordenationParam = e.target.dataset.option;

        const currentActive = qs('.sortByActive');
        if (currentActive) {
            currentActive.classList.remove("sortByActive");
        }

            e.target.classList.add("sortByActive")
        

        activeOrdenationParam = ordenationParam;
        currentPage = 1;
        await fetchChats();
        renderPagination(currentPage, totalPages, true);
    }

    if (e.target.classList.contains("page-arrow-previous")) {
        if (currentPage == 1) return;
        currentPage -= 1;
        renderPagination(currentPage, totalPages);
        await fetchChats();
    }

    if (e.target.classList.contains("page-arrow-next")) {
        if (currentPage == totalPages) return;
        currentPage += 1;
        renderPagination(currentPage, totalPages);
        await fetchChats();
    }

    if (e.target.classList.contains("page-number")) {
        const pageNumber = e.target.dataset.page;
        currentPage = pageNumber;
        renderPagination(currentPage, totalPages);
        await fetchChats();
    }
});


function filterWindowHandler(e) {
    const parentElement = e.target.parentElement;

    const currentActiveButton = qs(".title-section-button-active")
    const currentActiveWindow = qs('.floating-window.active');
    const internalElementWindow = parentElement.querySelector(".floating-window");

    if (currentActiveButton) {
        currentActiveButton.classList.remove("title-section-button-active");
    }

    if (currentActiveButton !== e.target) {
        parentElement.querySelector('button').classList.toggle("title-section-button-active");
    }

    if (currentActiveWindow) {
        currentActiveWindow.classList.remove("active");
        currentActiveWindow.classList.add("d-none");
    }

    if (currentActiveWindow != internalElementWindow) {
        internalElementWindow.classList.toggle("d-none");
        internalElementWindow.classList.toggle("active");
    }
}


document.addEventListener("DOMContentLoaded", async (event) => {
    await fetchChats();

    renderPagination(currentPage, totalPages);

    qs('#sort-by-button').addEventListener('click', filterWindowHandler);
  

});