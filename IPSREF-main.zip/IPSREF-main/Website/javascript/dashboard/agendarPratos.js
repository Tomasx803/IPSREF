const errRedir = "../php/login.php";
const apiPath = "../api.php?type=";

function validateDate(date) {
    const selectedDate = new Date(date);
    const dayOfWeek = selectedDate.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
        notify("error", "Erro!", "Não é possível agendar senhas para fins de semana!");
        return false;
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    selectedDate.setHours(0, 0, 0, 0);
    if (selectedDate < today) {
        notify("error", "Erro!", "Não é possível selecionar datas passadas!");
        return false;
    }
    return true;
}

function renderCalendar() {
    const calendarEl = document.querySelector('.calendario-content-box');

    window.calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: "pt-pt",
        selectable: true,
        dayHeaderFormat: {
            weekday: 'short'
        },
        titleFormat: (info) => {
            const monthNames = [
                'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
            ];
            const month = monthNames[info.date.month];
            return `${month}  ${info.date.year}`;
        },
        headerToolbar: {
            left: 'prev',
            center: 'title',
            right: 'next'
        },
        editable: true,
        events: function (info, successCallback, failureCallback) {
            let dateObject = new Date(info.start)
            const date = dateObject.getDate();
            if (date != 1) {
                dateObject.setDate(1);
                dateObject.setMonth(dateObject.getMonth() + 1);
            }
            const year = dateObject.getFullYear();
            const month = dateObject.getMonth() + 1;
            fetch(`../api.php?type=fetchPratosMdpDashboard&year=${year}&month=${month}`)
                .then(response => response.json())
                .then(data => successCallback(data))
                .catch((e) => genericErr());
        },

        eventDidMount: function (info) {
            const el = info.el;
            el.style.fontSize = '12px';
        },

        dayMaxEvents: true,
        datesSet: function (info) {
            const dayCells = document.querySelectorAll('.fc-day');

            dayCells.forEach(cell => {
                const date = cell.getAttribute('data-date');
                const day = new Date(date);
                const isWeekend = (day.getDay() === 0 || day.getDay() === 6);

                if (isWeekend) {
                    cell.querySelector(".fc-daygrid-day-number").style.color = "#c1c1c1";
                    cell.querySelector(".fc-daygrid-day-top").style.opacity = "1";
                }
            });
        },
        select: async function (info) {
            calendar.unselect();
            await triggerCriarMdpModal(info.startStr);
        },
        eventClick: async function (info) {
            const pratoId = info.event.id;
            const mdpId = info.event.extendedProps.mdp_id;
            const popovers = document.querySelectorAll('.fc-popover');
            popovers.forEach(p => p.remove());
            fetchPratoInfo(pratoId, mdpId);
        }
    });

    calendar.render();
    calendar.setOption('height', 691);
    calendar.setOption('aspectRatio', 3.8);

    document.querySelectorAll(".fc-button-primary").forEach(el => {
        el.classList.remove("fc-button-primary");
    });
}



async function triggerCriarMdpModal(date) {
    if (!date || date.length == 0) {
        genericErr();
        return;
    }

    if (!validateDate(date)) {
        return;
    }
    try {
        const r = await apiFetch(`../api.php?type=triggerCriarMdpModal&date=${date}`, null, errRedir);
        if (r.status && r.status === "error, blocked day") {
            notify("error", "Erro!", "Este dia é um feriado!");
            return;
        }
        if (r.status && r.status == "success") {
            qsin("#criarMdp-prato", "");
            if (Object.keys(r.content).length > 0) {
                for (let key in r.content) {
                    qsinplus("#criarMdp-prato", `<option value="${key}">${r.content[key].prato_nome}</option>`);
                }
                qs("#criarMdp-data").value = date;
                qs("#criarMenuDiaModal-trigger").click();
            }
            else {
                notify("error", "Erro!", "Nâo existe pratos para assignar");
            }
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}

async function createMdp(prato, date) {
    try {
        const r = await apiFetch(`../api.php?type=createMdp&date=${date}&prato=${prato}`, {}, errRedir);
        console.log(r)
        if (r.status && r.status == "success") {
            notify("success", "Sucesso!", "O menu dia foi criado com sucesso!");
            qs(".closeAgendarSenhaModal").click();
            window.calendar.refetchEvents();
        }
        else if (r.status && r.status == "Erro, weekend") {
            notify("error", "Erro!", "Não pode criar menu dias para os fins de semana!");
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}

async function fetchPratoInfo(pratoId, mdpId) {
    try {
        const r = await apiFetch(`${apiPath}fetchMdpInfo&mdp_id=${mdpId}`);
        if (r.status && r.status === "success") {
            const content = r.content;
            qsin('#id-pratoInfo', content.mdp_id);
            qsin('#nome-pratoInfo', content.pra_nome);
            qsin('#tipo-pratoInfo', content.pra_tipo);
            qsin('#estadoMDP-pratoInfo', content.mdp_estado_descricao);
            qsin('#estadoPrato-pratoInfo', content.pra_estado == "1" ? "Ativo" : "Desativado");
            qsin('#timesBought-pratoInfo', content.vezes_usado);


            qs('.toggleMdpEstadoButton').dataset.mdpId = mdpId;

            if (content.mdp_estado_descricao == "Ativo") {
                qs('.toggleMdpEstadoButton').innerHTML = "Desativar";
                qs('.toggleMdpEstadoButton').dataset.toggleState = "2";
                qs('.toggleMdpEstadoButton').classList.remove('modal__btn-primary');
                qs('.toggleMdpEstadoButton').classList.add('modal__btn-red');
            }
            else if (content.mdp_estado_descricao == "Desativado") {
                qs('.toggleMdpEstadoButton').innerHTML = "Ativar";
                qs('.toggleMdpEstadoButton').dataset.toggleState = "1";
                qs('.toggleMdpEstadoButton').classList.remove('modal__btn-red');
                qs('.toggleMdpEstadoButton').classList.add('modal__btn-primary');
            }

            qs('#dayInformationModal-trigger').click();
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}

document.addEventListener("click", async (e) => {
    const tg = e.target;
    const tgClass = e.target.classList;

    if (tgClass.contains("criarMdpButton")) {
        const date = qs("#criarMdp-data").value;
        const prato = qs("#criarMdp-prato").value;
        createMdp(prato, date);
        return;
    }

    if (tgClass.contains('toggleMdpEstadoButton')) {
        const mdpId = tg.dataset.mdpId;
        const toggleState = tg.dataset.toggleState;
        if (!mdpId) return;
        console.log(`${apiPath}toggleMdpEstadoButton&mdpId=${mdpId}&toggleState=${toggleState}`)
        const r = await apiFetch(`${apiPath}toggleMdpEstadoButton&mdp_id=${mdpId}&toggleState=${toggleState}`);
        if (r.status && r.status === "success") {
            notify("success", "Sucesso!", "O prato foi editado com sucesso!");
            fetchPratoInfo(null, mdpId);
        }
        else {
            genericErr();
        }
    }

});


document.addEventListener("DOMContentLoaded", (event) => {
    MicroModal.init({
        awaitOpenAnimation: true
    });
    renderCalendar();
});