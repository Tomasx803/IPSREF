const apiPath = "../api.php?type=";

function initializeDataTable() {
    if (window.table && $.fn.DataTable.isDataTable(window.table.table().node())) {
        window.table.clear().destroy();
        window.table = null; 
    }
    window.table = new DataTable('#tabelaAlunos', {
        pageLength: 10,
        language: {
            decimal: ",",
            thousands: ".",
            lengthMenu: "Mostrar _MENU_ linhas",
            zeroRecords: "Nenhum linha encontrado",
            info: "A mostrar _START_ a _END_ de _TOTAL_ linhas",
            infoEmpty: "A mostrar 0 a 0 de 0 linhas",
            infoFiltered: "(filtrado de _MAX_ registos no total)",
            search: "Pesquisar:",
            paginate: {
                first: "«",
                previous: "‹",
                next: "›",
                last: "»"
            },
        },
        createdRow: function (row, data, dataIndex) {
            $('td', row).eq(0).addClass('titulo');
            $('td', row).eq(1).addClass('conteudo');
            $('td', row).eq(2).addClass('actions');
        }
    });

    const searchContainer = qs(".dt-search");
    if (searchContainer) {
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-plus pointer";
        icon.style.marginLeft = "20px"
        icon.addEventListener("click", function(e) {
            qs('#criarFaq-trigger').click();
        })
        searchContainer.appendChild(icon); 
    }
}

function truncateText(text, maxLength = 100) {
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}

async function fetchContent() {
    try {
        const response = await apiFetch(`${apiPath}fetchFaqRows`);
        if (response.status && response.status == "success") {
            qs('#faqTableTBody').innerHTML = "";
            let increment = 0;
            let html = '';

            for (const item of response.content) {
                html += `
                <tr id="row-${item.faq_id}">
                    <td class="titulo">${item.faq_titulo}</td>
                    <td class="conteudo">${truncateText(item.faq_conteudo)}</td>
                    <td style="width: 20px !important;">
                        <div class="dropdown">
                            <button class="dropbtn">
                                <img src="../logos/ellipsisIcon.svg" class="pointer" data-faq-id="${item.faq_id}" width="20">
                            </button>
                            <div class="dropdown-content">
                                <a class="verFaqTrigger" data-increment="${increment}" data-faq-id="${item.faq_id}">
                                    Ver Detalhes
                                </a>
                                <a class="editarFaqTrigger" data-increment="${increment}" data-faq-id="${item.faq_id}">
                                    Editar FAQ
                                </a>
                                <a class="deleteFaq" data-increment="${increment}" data-faq-id="${item.faq_id}">
                                    Eliminar FAQ
                                </a>
                            </div>
                        </div>
                    </td>
                </tr>
            `;
                increment++; 
            }

            document.querySelector('#faqTableTBody').innerHTML = html;
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr(e);
    }
}

document.addEventListener("click", async (event) => {
    const targetDataset = event.target.dataset;
    const targetClass = event.target.classList;
    const target = event.target;

    if (targetClass.contains("criarFaqButton")) {
        const title = document.querySelector("#titulo-criarFaq").value;
        const content = document.querySelector("#conteudo-criarFaq").value;

        if (title.length == 0) {
            notify("error", "Erro!", "O título não pode estar vazio");
            return;
        }

        if (content.length == 0) {
            notify("error", "Erro!", "O conteúdo não pode estar vazio");
            return;
        }

        const response = await apiFetch(`${apiPath}createFaq&titulo=${encodeURIComponent(title)}&conteudo=${encodeURIComponent(content)}`);
        if (response.status && response.status == "success") {
            notify("success", "Sucesso!", `A FAQ foi criada com sucesso!`);
            document.querySelector("#titulo-criarFaq").value = "";
            document.querySelector("#conteudo-criarFaq").value = "";
            MicroModal.close('criarFaq');
            var currentPage = window.table.page();
            window.table.clear().destroy();
            window.table = null; 
            await fetchContent();
            initializeDataTable();
            window.table.page(currentPage).draw('page');
        }
        else {
            genericErr();
        }
    }

    if (targetClass.contains("editarFaqButton")) {
        const faqId = targetDataset.faqId;
        const increment = targetDataset.increment;
        const title = document.querySelector("#titulo-editarFaq").value;
        const content = document.querySelector("#conteudo-editarFaq").value;

        if (title.length == 0) {
            notify("error", "Erro!", "O título não pode estar vazio");
            return;
        }

        if (content.length == 0) {
            notify("error", "Erro!", "O conteúdo não pode estar vazio");
            return;
        }

        const response = await apiFetch(`${apiPath}editFaq&faqId=${faqId}&titulo=${encodeURIComponent(title)}&conteudo=${encodeURIComponent(content)}`);
        if (response.status && response.status == "success") {
            notify("success", "Sucesso!", `A FAQ foi atualizada com sucesso!`);
            MicroModal.close('editarFaq');
            window.table.cell(increment, 0).data(title);
            window.table.cell(increment, 1).data(truncateText(content));
            window.table.draw(false);
        }
        else {
            genericErr();
        }
    }

    if (targetClass.contains("editarFaqTrigger")) {
        const faqId = targetDataset.faqId;
        
        const response = await apiFetch(`${apiPath}getFaqById&faqId=${faqId}`);
        if (response.status && response.status == "success") {
            document.querySelector("#titulo-editarFaq").value = response.content.faq_titulo;
            document.querySelector("#conteudo-editarFaq").value = response.content.faq_conteudo;
            document.querySelector(".editarFaqButton").dataset.faqId = faqId;
            document.querySelector(".editarFaqButton").dataset.increment = targetDataset.increment;
            qs("#editarFaq-trigger").click();
        }
    }

    if (targetClass.contains("verFaqTrigger")) {
        const faqId = targetDataset.faqId;
        
        const response = await apiFetch(`${apiPath}getFaqById&faqId=${faqId}`);
        if (response.status && response.status == "success") {
            document.querySelector("#titulo-verFaq").textContent = response.content.faq_titulo;
            document.querySelector("#conteudo-verFaq").textContent = response.content.faq_conteudo;
            qs("#verFaq-trigger").click();
        }
    }

    if (targetClass.contains("deleteFaq")) {
        const faqId = targetDataset.faqId;
        const increment = targetDataset.increment;

        Swal.fire({
            title: 'Tem a certeza?',
            text: "Esta ação não pode ser revertida!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sim, eliminar!',
            cancelButtonText: 'Cancelar'
        }).then(async (result) => {
            if (result.isConfirmed) {
                const response = await apiFetch(`${apiPath}deleteFaq&faqId=${faqId}`);
                if (response.status && response.status == "success") {
                    Swal.fire(
                        'Eliminado!',
                        'A FAQ foi eliminada com sucesso.',
                        'success'
                    );
                    var currentPage = window.table.page();
                    window.table.clear().destroy();
                    window.table = null; 
                    await fetchContent();
                    initializeDataTable();
                    window.table.page(currentPage).draw('page');
                }
                else {
                    genericErr();
                }
            }
        });
    }
});

document.addEventListener("DOMContentLoaded", async (event) => {
    MicroModal.init({
        awaitOpenAnimation: true
    });

    await fetchContent();
    initializeDataTable();
});