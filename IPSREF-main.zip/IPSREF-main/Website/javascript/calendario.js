function checkRefundElegibility(sqlDatetime) {
    const date = new Date(sqlDatetime);
    const now = new Date();
    const diffMs = now - date;
    const fortyEightHoursMs = 48 * 60 * 60 * 1000;
    return diffMs < fortyEightHoursMs;
}

function validateDate(date) {
    const selectedDate = new Date(date);
    const dayOfWeek = selectedDate.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
        notify("error", "Erro!", "Não é possível agendar senhas para fins de semana!");
        return false;
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    selectedDate.setHours(0, 0, 0, 0);
    if (selectedDate < today) {
        notify("error", "Erro!", "Não é possível selecionar datas passadas!");
        return false;
    }
    return true;
}

async function fetchCalendarEventInfo(eventId) {
    try {
        const ft = await fetch(`../api.php?type=fetchCalendarEventInfo&eventId=${eventId}`)
        const data = await ft.json();
        if (data.error && data.error === "Senha não encontrados") {
            notify("error", "Erro!", "Não existe senhas para este dia");
            return;
        }
        else if (data.error && data.error === "Not Logged In") {
            window.location.href = "login.php";
            return;
        }
        else {
            const estadoMap = {
                "A": "Agendado",
                "U": "Utilizado",
                "PA": "Por Agendar",
                "C": "Chat Criado",
                "R": "Reembolsado",
                "CEC": "Chat em Curso",
                "F": "Fechado",
            };
            qsin("#tipo-senha", data.descricao);
            qsin("#dataCompra-senha", data.data_senha.split(' ')[0]);
            qsin("#estado-senha", estadoMap[data.estado] || "-");
            qsin("#prato-senha", (data.prato?.length > 0) ? data.pratoName + " - " + data.prato : "Para Escolher");
            qsin("#extras-senha", data.extras ? JSON.parse(data.extras).map(item => item.ext_nome).join(', ') : '-');

            //edit prato attributes
            qs("#editSenha-prato-button").dataset.senhaId = eventId;
            qs("#editSenha-prato-button").dataset.date = data.data_senha;

            //edit extras attributes
            qs("#editSenha-extras-button").dataset.senhaId = eventId;
            qs("#editSenha-extras-button").dataset.selectedExtras = data.extras ? JSON.parse(data.extras).map(item => item.ext_id).join(', ') : '';

            //edit date attributes
            qs("#editSenha-data-button").dataset.senhaId = eventId;


            //edit prato toggle
            qs("#editSenha-prato-button").style.display = "none";
            qs("#editSenha-select-prato").style.display = "none";
            qs("#editSenha-select-prato").innerHTML = "";
            qs("#prato-senha").style.display = "block";

            //edit extras toggle
            qs("#editSenha-extras-container").style.display = "none";
            qs("#editSenha-extras-container").querySelector('.icon-slot').style.display = "none";
            qs("#editSenha-extras-button").style.display = "none";
            qs("#extras-senha").style.display = "block";

            //edit date toggle
            qs("#editSenha-data-button").style.display = "none";
            qs("#editSenha-input-date").style.display = "none";
            const today = new Date().toISOString().split('T')[0]; 
            qs("#editSenha-input-date").value = today;
            qs("#editSenha-input-date").min = today;
            qs("#dataCompra-senha").style.display = "";

            //toogle footer
            qs(".mdft").style.display = "none";

            qs(".editSenhaButton").dataset.senhaId = eventId;

            //toggle reembolsa button
            if (checkRefundElegibility(data.data_senha) && data.estado == "A") {
                qs(".reemboolsarSenhaDiv").classList.remove("d-none");
            }
            else {
                qs(".reemboolsarSenhaDiv").classList.add("d-none");
            }

            qs('.reemboolsarSenhaButton').dataset.senhaId = eventId;

            if (data.estado == "A") {
                if (!data.prato) {
                    qs("#editSenha-prato-button").style.display = "block";
                }
                qs("#editSenha-extras-button").style.display = "";
            }
            else if (data.estado == "PA") {
                qs("#editSenha-data-button").style.display = "";
            }

            qs("#dayInformationModal-trigger").click();
        }
    }
    catch (err) {
        genericErr();
    }
}

async function triggerAgendarSenhaModal(date) {
    if (!date || date.length == 0) {
        genericErr();
        return;
    }

    if (!validateDate(date)) {
        return;
    }

    try {
        const data = await fetch(`../api.php?type=triggerAgendarSenhaModal&date=${date}`)
        const response = await data.json();
        console.log(response)

        if (response.status === "already exists") {
            notify("error", "Erro!", "Não pode ter mais 2 que senhas por dia");
            return;
        }
        else if (response.status === "error, blocked day") {
            notify("error", "Erro!", "Este dia é um feriado!");
            return;
        }

        if (response.status === "success") {
            const pratos = JSON.parse(response.pratos);
            const names = JSON.parse(response.names);
            qsin('#agendarSenha-prato', "");
            const option = document.createElement("option");
            option.value = "nenhum";
            option.textContent = "Nenhum";
            qs('#agendarSenha-prato').appendChild(option);
            for (let prato in pratos) {
                const option = document.createElement("option");
                option.value = prato;
                option.textContent = names[prato] + " - " + pratos[prato];
                qs('#agendarSenha-prato').appendChild(option);
            }
            qs("#modal-1-trigger").setAttribute('data-date', date)
            qs('#agendarSenha-prato').setAttribute('data-mdp-ids', response.mdp_ids);
            qs("#modal-1-trigger").click();
        }
    }
    catch (e) {
        genericErr();
    }
}


function renderCalendar() {
    const calendarEl = document.querySelector('.calendario-content-box');
    let selectedEventType = 'all';
    let renderCalenderSelectedOptionType = "Opções ▾";

    window.calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: "pt-pt",
        selectable: true,
        dayHeaderFormat: { weekday: 'short' },
        titleFormat: info => {
            const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
            const month = monthNames[info.date.month];
            return `${month} ${info.date.year}`;
        },
        headerToolbar: { left: 'prev', center: 'title', right: 'myDropdown, next' },
        customButtons: {
            myDropdown: {
                text: renderCalenderSelectedOptionType, click: () => {
                    const menu = document.getElementById('myDropdownMenu');
                    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
                }
            }
        },
        editable: true,
        events: function (info, successCallback) {
            const dateObj = new Date(info.start);
            if (dateObj.getDate() != 1) {
                dateObj.setDate(1);
                dateObj.setMonth(dateObj.getMonth() + 1);
            }
            const year = dateObj.getFullYear();
            const month = dateObj.getMonth() + 1;

            fetch(`../api.php?type=fetchCalenderEvents&year=${year}&month=${month}&eventType=${selectedEventType}`)
                .then(r => r.json())
                .then(data => successCallback(data))
                .catch(() => genericErr());
        },
        eventDidMount: info => { info.el.style.fontSize = '12px'; },
        dayMaxEvents: true,
        select: async info => { calendar.unselect(); await triggerAgendarSenhaModal(info.startStr); },
        eventClick: async info => {
            document.querySelectorAll('.fc-popover').forEach(p => p.remove());
            await fetchCalendarEventInfo(info.event.id);
        }
    });

    calendar.render();
    calendar.setOption('height', 691);
    calendar.setOption('aspectRatio', 3.8);

    document.querySelectorAll(".fc-button-primary").forEach(el => el.classList.remove("fc-button-primary"));

    const dropdownBtn = document.querySelector('.fc-myDropdown-button');
    dropdownBtn.classList.add("modal__btn-primary")
    const toolbarEl = document.querySelector('.fc-toolbar-chunk:last-child');

    // Create dropdown menu once
    const dropdownMenu = document.createElement('div');
    dropdownMenu.id = 'myDropdownMenu';
    dropdownMenu.style.position = 'absolute';
    dropdownMenu.style.background = '#fff';
    dropdownMenu.style.boxShadow = '0 8px 16px rgba(0,0,0,0.2)';
    dropdownMenu.style.border = '1px solid #ccc';
    dropdownMenu.style.textAlign = 'left';
    dropdownMenu.style.display = 'none';
    dropdownMenu.style.zIndex = '1000';

    const items = [
        { label: 'Todas as senhas', type: 'all' },
        { label: 'Senhas Reembolsaveis', type: 'refundable' },
        { label: 'Senhas Expiradas', type: 'expire' }
    ];

    items.forEach(itemObj => {
        const el = document.createElement('div');
        el.textContent = itemObj.label;
        el.style.padding = '10px 20px 10px 5px';
        el.style.fontSize = '15px';
        el.style.cursor = 'pointer';
        el.addEventListener('click', () => {
            selectedEventType = itemObj.type;
            renderCalenderSelectedOptionType = itemObj.label + ' ▾';

            const btn = document.querySelector('.fc-myDropdown-button');
            if (btn) btn.innerHTML = itemObj.label + ' ▾';

            dropdownMenu.style.display = 'none';
            calendar.refetchEvents();
        });
        el.addEventListener('mouseover', () => el.style.background = '#eee');
        el.addEventListener('mouseout', () => el.style.background = '#fff');
        dropdownMenu.appendChild(el);
    });

    toolbarEl.appendChild(dropdownMenu);

    document.addEventListener('click', e => {
        if (!toolbarEl.contains(e.target)) dropdownMenu.style.display = 'none';
    });

    const button = document.querySelector('.fc-myDropdown-button.fc-button');

    if (button) {
        const observer = new MutationObserver((mutationsList) => {
            for (let mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    if (button.innerHTML !== renderCalenderSelectedOptionType) {
                        button.innerHTML = renderCalenderSelectedOptionType;
                    }
                }
            }
        });

        observer.observe(button, { childList: true, subtree: true });
    }

}



function addExtraFunction(extras, container, identifierClass, selectId) {
    const select = document.createElement("select");
    select.classList.add('extras-select-ev');
    select.classList.add('agendarSenha-input-div-select');
    select.classList.add(identifierClass);
    const option = document.createElement("option");
    option.value = "remover";
    option.textContent = "remover";
    for (let extra in extras) {
        const option = document.createElement("option");
        option.value = extra;
        option.textContent = extras[extra];
        select.appendChild(option);
    }
    select.appendChild(option);
    if (selectId) {
        select.value = selectId;
    }

    const selectContainer = document.querySelector(container);
    const addExtraOptionElement = selectContainer.querySelector('.icon-slot');

    selectContainer.insertBefore(select, addExtraOptionElement);

    const count = selectContainer.querySelectorAll('select').length;
    if (count >= Object.keys(extras).length) {
        selectContainer.querySelector('.icon-slot').style.display = "none";
    }

}

document.addEventListener('change', function (e) {
    if (e.target.classList.contains('extras-select-ev') && e.target.value == "remover") {
        e.target.parentElement.querySelector('.icon-slot').style.display = "";
        e.target.remove();
    }
});


async function createSenhaHelper() {
    const prato = qs('#agendarSenha-prato').value;
    const extras = document.querySelectorAll('.agendarSenha-select-extras-identifier');
    const extrasValues = [];

    
    extras.forEach(extra => {
        extrasValues.push(extra.value);
    });

    const uniqueValues = new Set(extrasValues);
    if (extrasValues.length !== uniqueValues.size) {
        notify("error", "Erro!", "Não pode haver dois extras iguais.");
        return;
    }

    const periodo = qs('#agenderSenha-periodo').value;
    const date = qs("#modal-1-trigger").getAttribute('data-date');
    let mdp_id = null;

    if (prato !== "nenhum") {
        const mdp_ids = JSON.parse(qs('#agendarSenha-prato').getAttribute('data-mdp-ids'));
        mdp_id = mdp_ids[prato];
    }

    await createSenha(extrasValues, periodo, date, mdp_id);
}


async function createSenha(extras, periodo, date, mdp_id) {
    try {
        const data = await fetch(`../api.php?type=createSenha&mdp_id=${mdp_id ? mdp_id : "empty"}&extras=${extras.length > 0 ? extras.join(",") : "empty"}&periodo=${periodo}&date=${date}`);
        const resp = await data.json();
        if (resp.status === "already exists") {
            notify("error", "Erro!", `Ja tem uma senha para o periodo selecionado`);
            return;
        }

        if (resp.status == "success") {
            notify("success", "Sucesso!", "Senha agendada com sucesso!");
            window.calendar.refetchEvents();
            qs('.closeAgendarSenhaModal').click();
        }
    }
    catch (e) {
        genericErr();
    }
}

async function toggleEditSenha(e) {
    const target = e.currentTarget;
    let eventId = target.dataset.senhaId;
    let selectedExtras = target.dataset.selectedExtras;
    console.log(selectedExtras)
    let avalibleExtras = qs("#editSenha-extras-container").dataset.extraOptions;

    if (avalibleExtras && avalibleExtras.length > 0) {
        avalibleExtras = JSON.parse(avalibleExtras);
    } else {
        notify("error", "Erro!", "Não existe extras, tenta depois!");
        return;
    }

    target.style.display = "none";
    qs("#editSenha-extras-container").style.display = "";
    qs("#editSenha-extras-container").querySelector('.icon-slot').style.display = "";
    qs("#extras-senha").style.display = "none";
    qs(".mdft").style.display = "";

    qs("#editSenha-extras-container").innerHTML = `<div class="icon-slot addExtraOptionEditarSenha "><svg xmlns="http://www.w3.org/2000/svg"  width="22" viewBox="0 0 640 640"><path d="M352 128C352 110.3 337.7 96 320 96C302.3 96 288 110.3 288 128L288 288L128 288C110.3 288 96 302.3 96 320C96 337.7 110.3 352 128 352L288 352L288 512C288 529.7 302.3 544 320 544C337.7 544 352 529.7 352 512L352 352L512 352C529.7 352 544 337.7 544 320C544 302.3 529.7 288 512 288L352 288L352 128z"></path></svg></div>`;
    
    if (selectedExtras && selectedExtras.length > 0) {
        const selectedExtrasJson = selectedExtras.split(",");

        for (let extra of selectedExtrasJson) {
            addExtraFunction(avalibleExtras, "#editSenha-extras-container", "editarSenha-select-extras-identifier", Number(extra));
        }
    }


    const extras = JSON.parse(qs('#editSenha-extras-container').getAttribute('data-extra-options'));

    qs('.addExtraOptionEditarSenha').addEventListener('click', function () {
        addExtraFunction(extras, "#editSenha-extras-container", "editarSenha-select-extras-identifier");
    });
}


async function toggleEditPrato(e) {
    let eventId = e.target.dataset.senhaId;
    let date = e.target.dataset.date;

    if (!eventId) {
        const svg = e.target.closest('svg');
        if (svg) {
            eventId = svg.dataset.senhaId;
            date = svg.dataset.date;
        }
    }

    const response = await fetch(`../api.php?type=fetchPratosForSenha&date=${date}`);
    const data = await response.json();

    if (data.error && data.error === "Not Logged In") {
        window.location.href = "login.php";
        return;
    }

    if (data.status && data.status === "success") {
        const pratos = JSON.parse(data.pratos);

        if (Object.keys(pratos).length > 0) {
            qsin("#editSenha-select-prato", "");

            for (const key in pratos) {
                const item = pratos[key];
                qs("#editSenha-select-prato").innerHTML += `<option value="${item.mdp}">${item.prato_nome} - ${item.prato_tipo}</option>`;
            }

            e.target.style.display = "none";
            qs("#prato-senha").style.display = "none";
            qs("#editSenha-select-prato").style.display = "";
            qs(".mdft").style.display = "";
        } else {
            notify("error", "Erro!", "Ainda não existe pratos para este dia, tenta depois!");
        }
    }
}


async function handleEditSenha(e) {
    try {
        const eventId = e.target.dataset.senhaId;
        const prato = qs("#editSenha-select-prato").value;
        const extras = document.querySelectorAll('.editarSenha-select-extras-identifier');
        const extrasValues = [];
        const date = qs('#editSenha-input-date').value;

        extras.forEach(extra => {
            extrasValues.push(extra.value);
        });

        const uniqueValues = new Set(extrasValues);
        if (extrasValues.length !== uniqueValues.size) {
            notify("error", "Erro!", "Não pode haver dois extras iguais.");
            return;
        }

        let url = `../api.php?type=editarSenha&senhaId=${eventId}`;

        if (prato.length > 0) {
            url += `&mdp_id=${prato}`;
        }

        const arr = [...uniqueValues];

        if (arr.length > 0) {
            url += `&extras=${arr.join(",")}`;
        }

        if (date.length > 0) {
            url += `&date=${date}`;
        }

        const response = await fetch(url);
        const data = await response.json();


        if (data.error && data.error === "Not Logged In") {
            window.location.href = "login.php";
            return;
        }

        if (data.status && data.status === "success") {
            notify("success", "Sucesso!", "Senha editada com sucesso!");
            window.calendar.refetchEvents();
            qs('.closeSenhaInformacaoButton').click();
        }
        else {
            genericErr();
        }
    } catch (e) {
        genericErr(e);
    }
}



function handleCancelEditSenha() {
    qs(".mdft").style.display = "none";

    qs("#editSenha-select-prato").style.display = "none";
    qs("#prato-senha").style.display = "";
    qs("#editSenha-prato-button").style.display = qs("#prato-senha").innerHTML === "Para Escolher" ? "" : "none";

    qs("#editSenha-extras-container").style.display = "none";
    qs("#extras-senha").style.display = "";
    qs("#editSenha-extras-button").style.display = "";

    qs("#editSenha-input-date").style.display = "none";
    qs("#dataCompra-senha").style.display = "";
    qs("#editSenha-data-button").style.display = qs("#estado-senha").innerHTML === "Por Agendar" ? "" : "none";
}

async function handleRefund(e) {
    const senhaId = e.target.dataset.senhaId;
    if (!senhaId) {
        genericErr();
        return;
    }
    try {
        const r = await apiFetch(`../api.php?type=reembolsaSenha&senhaId=${senhaId}`);
        if (r.status) {
            const status = r.status;
            switch (status) {
                case "error, senha not found":
                    notify("error", "Erro!", "A senha não existe. Se acha que isto é um engano, contacte-nos.");
                    break;
                case "error, senha already refunded":
                    notify("error", "Erro!", "A senha ja foi Reembolsada. Se acha que isto é um engano, contacte-nos.");
                    break;
                case "error, senha state not equal to agendado":
                    notify("error", "Erro!", 'Não é possivel Reembolsar uma senha cujo estado não é igual a "Agendado". Se acha que isto é um engano, contacte-nos.');
                    break;
                case "error, senha older than 48 hours":
                    notify("error", "Erro!", "Não é possível reembolsar uma senha com mais de 48 horas a contar de agora. Se acha que isto é um engano, contacte-nos.");
                    break;
                case "success":
                    notify("success", "Sucesso!", "A senha foi Reembolsado com sucesso!.");
                    qs(".closeSenhaInformacaoButton").click();
                    break;
                default:
                    notify("error", "Erro!", `Ocorreu um erro inesperado, contacte-nos para resolver.`);
                    break;
            }
        }
    }
    catch (e) {
        genericErr();
    }
}

async function toggleEditData(e) {
    e.target.style.display = "none";
    qs("#dataCompra-senha").style.display = "none";
    qs("#editSenha-input-date").style.display = "";
    qs(".mdft").style.display = "";
}



document.addEventListener('DOMContentLoaded', async function () {

    MicroModal.init({
        awaitOpenAnimation: true
    });

    renderCalendar();

    const extras = JSON.parse(qs('.select-container-agendarSenha').getAttribute('data-extra-options'));

    qs('.addExtraOptionAgendarSenha').addEventListener('click', function () {
        addExtraFunction(extras, ".select-container-agendarSenha", "agendarSenha-select-extras-identifier");
    });

    qs('.agendarSenha').addEventListener('click', createSenhaHelper);

    qs("#editSenha-extras-button").addEventListener("click", toggleEditSenha);

    qs("#editSenha-prato-button").addEventListener("click", toggleEditPrato);    
    
    qs("#editSenha-data-button").addEventListener("click", toggleEditData);


    

    qs(".mdftbtn").addEventListener("click", handleCancelEditSenha);

    qs(".editSenhaButton").addEventListener("click", handleEditSenha);

    qs(".reemboolsarSenhaButton").addEventListener("click", handleRefund);



    const params = new URLSearchParams(window.location.search);
    const senhaId = params.get("senhaId");
    if (senhaId) {
        fetchCalendarEventInfo(senhaId);
    }

});

