// Tipos de notificação
const notyf = new Notyf({
    duration: 4000,
    position: { x: 'right', y: 'top' },
    dismissible: true,
    types: [
        // Notificação de alerta
        {
          type: 'warning',
          background: 'orange',
          icon: {
            className: 'fas fa-triangle-exclamation',
            tagName: 'i',
            color: 'white'
          }
        },
        // Notificação de informação
        {
          type: 'info',
          background: '#0d6efd',
          icon: {
            className: 'fas fa-info-circle',
            tagName: 'i',
            color: 'white'
          }
        }
    ]
});

// Função para exibir notificações
function notify(type, title, message, duration = 4000) {
    let text = message;

    if (title) {
        text = `<strong>${title}</strong><br>${message}`;
    }

    switch(type) {
        case 'success':
            notyf.success({ message: text, duration });
            break;

        case 'error':
            notyf.error({ message: text, duration });
            break;

        default:
            notyf.open({ type: type, message: text, duration });
            break;
    }
}

function genericErr(e) {
  if (e) {
    console.log(e);
  }
  else {
    notify("error", "Erro!", "Houve um erro, tenta depois!");
  }
}