// Máscara para o campo do número de estudante
document.addEventListener("DOMContentLoaded", () => {
    const nEstudante = document.getElementById("n_estudante");
    Inputmask("9999999999", {
        placeholder: "",
        showMaskOnHover: false,
        showMaskOnFocus: false
    }).mask(nEstudante);
});

// Variáveis
const form = document.getElementById("registarForm");
const fields = {
    nEstudante: document.getElementById("n_estudante"),
    nome: document.getElementById("nome"),
    apelido: document.getElementById("apelido"),
    email: document.getElementById("email"),
    pass: document.getElementById("pass"),
    confirm: document.getElementById("confirm"),
};

// Detecta mudanças nos campos do formulário
form.addEventListener("input", (event) => {
    validateInput(event.target);
});

// Retorna false + atributos de erro
function setInvalid(field, message) {
    const erro = field.nextElementSibling;
    erro.textContent = message;
    field.classList.add("invalid");
    field.classList.remove("valid");
    return false;
}

// Retorna true + atributos de sucesso
function setValid(field) {
    const erro = field.nextElementSibling;
    erro.textContent = "";
    field.classList.remove("invalid");
    field.classList.add("valid");
    return true;
}

// Validação dos campos do formulário
async function validateInput(field) {
    const value = field.value.trim();

    switch (field.id) {
        case "n_estudante":
            if (!value) return setInvalid(field, "Número de estudante obrigatório");
            if (!/^\d{10}$/.test(value)) return setInvalid(field, "Número de estudante inválido");

            const resultado = await checkIfStudentNumberExists(value);

            if (resultado.exists) {
                return setInvalid(field, "Este número de estudante já está a ser usado");
            }
            break;

        case "nome":
            if (!value) return setInvalid(field, "Nome obrigatório");
            if (/[^a-zA-ZÀ-ÿ\s'-]/.test(value)) return setInvalid(field, "Introduza um nome válido");
            break;

        case "apelido":
            if (!value) return setInvalid(field, "Apelido obrigatório");
            if (/[^a-zA-ZÀ-ÿ\s'-]/.test(value)) return setInvalid(field, "Introduza um apelido válido");
            break;

        case "email":
            if (!value) return setInvalid(field, "Email obrigatório");
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return setInvalid(field, "Email inválido");

            const resultadoEmail = await checkIfEmailExists(value);

            if (resultadoEmail.exists) {
                return setInvalid(field, "Este email já está a ser usado");
            }
            break;

        case "pass":
            if (!value) return setInvalid(field, "Password obrigatória");
            break;

        case "confirm":
            const passValue = document.getElementById("pass").value;
            if (!value) return setInvalid(field, "Confirmação obrigatória");
            if (value !== passValue) return setInvalid(field, "As palavras-passe não coincidem");
            break;
    }

    return setValid(field);
}

// Validação ao submeter o formulário
form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const results = await Promise.all(
        Object.values(fields).map(field => validateInput(field))
    );

    const valid = results.every(function(result) { return result === true });

    if (valid) form.submit();
});

// Chamada AJAX para verificar se o número de estudante já existe
async function checkIfStudentNumberExists(nEstudante) {
    const response = await fetch("../api.php?type=checkStudentNumber", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "nEstudante=" + encodeURIComponent(nEstudante)
    });

    return await response.json();
}

// Chamada AJAX para verificar se o email já existe
async function checkIfEmailExists(email) {
    const response = await fetch("../api.php?type=checkPersonEmail", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "email=" + encodeURIComponent(email)
    });
    return await response.json();
}