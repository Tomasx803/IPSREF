
// ===============================
// Icon de Notificações do Header
// ===============================

async function markAllAsRead() {
  try {
    const response = await fetch(`../api.php?type=markAllNotificationsRead`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Fetch error:", error);
    throw error;
  }
}

async function clearNotifications() {
  try {
    const response = await fetch(`../api.php?type=clearNotifications`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Fetch error:", error);
    throw error;
  }
}

// Função para atualizar a interface após marcar como lidas
function updateUIAfterMarkingRead() {
  // Remover badges "NOVA"
  document.querySelectorAll('.nova-badge').forEach(badge => {
    badge.remove();
  });
  
  // Atualizar classes para "lida"
  document.querySelectorAll('.notificacao-item.nao-lida').forEach(item => {
    item.classList.remove('nao-lida');
    item.classList.add('lida');
    item.style.opacity = '0.6';
    item.style.backgroundColor = '#fefefe';
    item.style.paddingTop = '8px';
    item.querySelectorAll('p').forEach(p => {
      p.style.fontWeight = 'normal';
    });
  });
  
  // Atualizar contador no sino (remover badge)
  const badge = document.querySelector('.badge');
  if (badge) {
    badge.remove();
  }
}

document.addEventListener("DOMContentLoaded", (event) => {
  const bell = document.getElementById("bell");
  const popup = document.getElementById("popup");

  if (bell) {
    bell.addEventListener("click", (e) => {
      e.stopPropagation();
      popup.style.display = popup.style.display === "block" ? "none" : "block";
    });
  }

  document.addEventListener("click", (e) => {
    if (!bell.contains(e.target) && !popup.contains(e.target)) {
      popup.style.display = "none";
    }
  });

  // Botão "Marcar todas como lidas"
  const marcarLidasBtn = document.getElementById("marcarLidas");
  if (marcarLidasBtn) {
    marcarLidasBtn.addEventListener("click", async () => {
      try {
        const result = await markAllAsRead();
        
        if (result.status === 'success') {
          updateUIAfterMarkingRead();
          notificationsMarkedAsRead = true;
        } else {
          notify("error", "Erro!", "Não foi possível realizar a operação!");
        }
      } catch (error) {
        console.error("Error:", error);
        notify("error", "Erro!", "Não foi possível realizar a operação!");
      }
    });
  }

  // Botão "Limpar" (eliminar todas)
  const limparBtn = document.getElementById("limpar");
  if (limparBtn) {
    limparBtn.addEventListener("click", async () => {
      try {
        const result = await clearNotifications();
        
        if (result.status === 'success') {
          // Limpar visualmente as notificações do popup
          const notificacoesContainer = document.querySelector('.popup');
          const items = notificacoesContainer.querySelectorAll('.notificacao-item');
          const hrElements = notificacoesContainer.querySelectorAll('hr');
          
          // Remover todas as notificações e os HRs existentes
          items.forEach(item => item.remove());
          hrElements.forEach(hr => hr.remove());
          
          // Adicionar mensagem de "Sem notificações"
          const semNotificacoes = document.createElement('div');
          semNotificacoes.className = 'notificacao-item';
          semNotificacoes.innerHTML = '<p>Sem notificações</p>';
          
          // Inserir após o título e antes dos botões
          const titulo = notificacoesContainer.querySelector('p:first-child');
          const acoes = notificacoesContainer.querySelector('.popup-acoes');
          
          // Criar um novo HR
          const hr = document.createElement('hr');
          
          notificacoesContainer.insertBefore(hr, acoes);
          notificacoesContainer.insertBefore(semNotificacoes, hr);
          
          // Remover badge do sino
          const badge = document.querySelector('.badge');
          if (badge) {
            badge.remove();
          }
          
        } else {
          notify("error", "Erro!", "Não foi possível eliminar as notificações!");
        }
      } catch (error) {
        console.error("Error:", error);
        notify("error", "Erro!", "Não foi possível eliminar as notificações!");
      }
    });
  }
});