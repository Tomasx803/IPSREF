// External async function to handle form submission
async function enviarPedidoSuporte(event) {
    event.preventDefault();

    const assuntoEl = qs('#reason');
    const mensagemEl = qs('#mensagem');

    // Simple validation
    if (!assuntoEl.value.trim()) {
        assuntoEl.style.borderColor = 'red';
        return;
    } else {
        assuntoEl.style.borderColor = '';
    }

    if (!mensagemEl.value.trim()) {
        mensagemEl.style.borderColor = 'red';
        return;
    } else {
        mensagemEl.style.borderColor = '';
    }

    // Prepare form data
    const formData = new URLSearchParams();
    formData.append('assunto', assuntoEl.value.trim());
    formData.append('mensagem', mensagemEl.value.trim());

    // Send fetch request
    const r = await fetch('../api.php?type=enviarPedidoSuporte', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
    });

    const data = await r.json();

    // Handle responses
    if (data.error && data.error === "Not Logged In") {
        window.location.href = "login.php";
        return;
    }

    if (data.status && data.status === "success") {
        notify("success", "Sucesso!", "O chat de suporte foi criado com sucesso. Um administrador entrará em contato em breve.");
    } else {
        genericErr();
    }
}

document.addEventListener('DOMContentLoaded', function () {


    qs('.faq-form').addEventListener('submit', enviarPedidoSuporte);


});
