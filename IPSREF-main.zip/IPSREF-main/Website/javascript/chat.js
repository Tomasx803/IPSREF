let chatId;
let lastMsgId;

function scrollToBottomMsgContainer() {
    const messageArea = qs(".message-area");
    messageArea.scrollTop = messageArea.scrollHeight;
}

async function sendMessageEnterInput(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        await sendMessage();
        scrollToBottomMsgContainer();
    }
}

function formatMessageTime(rawTime = null, includeDate = false) {
    const date = rawTime ? new Date(rawTime) : new Date();
    if (isNaN(date.getTime())) return "";

    if (includeDate) {
        return date.toLocaleString([], {
            month: 'short',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            hour12: true
        });
    } else {
        return date.toLocaleTimeString([], {
            hour: 'numeric',
            minute: 'numeric',
            hour12: true
        });
    }
}


async function sendMessage(e) {
    const msg = qs("#messageInput").value.trim();
    if (!chatId) return;
    if (msg.length == 0) return;

    try {
        const r = await fetch('../api.php?type=enviarMensagem', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                chatId: chatId,
                message: msg
            })
        });

        const d = await r.json();
        if (d.error && d.error == "Not Logged In") {
            window.location.href = "login.php";
            return;
        }

        if (d.status && d.status == "success") {

            lastMsgId = d.msg_id;
            qs("#messageInput").value = "";
            qs(".message-area").innerHTML += `                    <div class="message sender">
                        ${msg}
                    <span class="message-time">${formatMessageTime()}</span>
                    </div>`;
            scrollToBottomMsgContainer();
        }
        else if (d.status && d.status == "refreshPage") {
            window.location.reload();
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}

async function fetchMessages() {
    if (!chatId) return;
    try {
        const r = await apiFetch(`../api.php?type=fetchAllMessagesUser&chatId=${chatId}`);
        if (r.status && r.status == "success") {
            const content = r.content;
            const usId = r.userId;
            let html = "";


            content.forEach(msg => {
                lastMsgId = msg.msg_id;
                const isUs = msg.msg_pes_id == r.userId ? true : false;
                html += `
                <div class="message ${isUs ? "sender" : "receiver"}">
                    ${msg.msg_texto}
                    <span class="message-time">${formatMessageTime(msg.msg_data)}</span>
                </div>
                    `;

            });
            qs(".message-area").innerHTML = html;
            scrollToBottomMsgContainer();

            if (r.currentChatState && r.currentChatState == "7") {
                qs("#messageInput").disabled = true;
                qs("#messageInput").placeholder = "Este chat foi fechado por um administrador. Inicie um novo chat se ainda tiver dúvidas.";
                qs("#messageInput").style.border = "3px solid #007BFF";
                qs("#messageInput").style.outline = "none";
            }
        }
        else {
            genericErr();
        }
    }
    catch (e) {
        genericErr();
    }
}

async function longPollMessages() {
    try {
        const r = await apiFetch(`../longPollMessagesUser.php?last_id=${lastMsgId}&chatId=${chatId}`);
        let html = "";
        if (r.status && r.status == "success") {

            r.messages.forEach(msg => {
                const isUs = msg.msg_pes_id == r.usId ? true : false;
                lastMsgId = msg.msg_id;
                if (!isUs) {
                    html += `
                    <div class="message ${isUs ? "sender" : "receiver"}">
                        ${msg.msg_texto}
                        <span class="message-time">${formatMessageTime(msg.msg_data)}</span>
                    </div>
                    `;
                }

            })
            qs(".message-area").innerHTML += html;
            scrollToBottomMsgContainer();
            await longPollMessages();
        }
        else if (r.status && r.status == "noMessagesFound") {
            longPollMessages();
        }
    }
    catch (e) {
        genericErr();
    }
}

document.addEventListener('DOMContentLoaded', async function () {
    const urlParams = new URLSearchParams(window.location.search);
    chatId = urlParams.get('chatId');
    if (!chatId) {
        window.location.href = 'chats.php';
        return;
    }

    window.scrollTo({
        top: document.body.scrollHeight,
        behavior: 'smooth'
    });

    qs("#sendButton").addEventListener("click", sendMessage);
    qs("#messageInput").addEventListener("keydown", sendMessageEnterInput);

    await fetchMessages();
    scrollToBottomMsgContainer();
    await longPollMessages();
});