const emailForm = document.getElementById("emailForm");
const codigoForm = document.getElementById("codigoForm");
const passwordForm = document.getElementById("passwordForm");

if (emailForm) {
    const emailInput = document.getElementById("email");

    emailForm.addEventListener("input", (event) => {
        validateInput(event.target);
    });

    emailForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const valid = validateInput(emailInput);
        if (valid) emailForm.submit();
    });
}

if (codigoForm) {
    const codigoInput = document.getElementById("codigo");
    Inputmask("AAAAAA", {
        placeholder: "",
        showMaskOnHover: false,
        showMaskOnFocus: false,
        definitions: {
            'A': {
                validator: "[0-9A-Z]",
                casing: "upper"
            }
        }
    }).mask(codigoInput);

    codigoForm.addEventListener("input", (event) => {
        validateInput(event.target);
    });

    codigoForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const valid = await validateInput(codigoInput);
        if (valid) codigoForm.submit();
    });
}

if (passwordForm) {
    const passwordInput = document.getElementById("password");
    const confirmInput = document.getElementById("confirm_password");

    passwordForm.addEventListener("input", (event) => {
        validateInput(event.target);
    });

    passwordForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        const validPassword = validateInput(passwordInput);
        const validConfirm = validateInput(confirmInput);
        if (validPassword && validConfirm) passwordForm.submit();
    });
}

function setInvalid(field, message) {
    const erro = field.nextElementSibling;
    erro.textContent = message;
    field.classList.add("invalid");
    field.classList.remove("valid");
    return false;
}

function setValid(field) {
    const erro = field.nextElementSibling;
    erro.textContent = "";
    field.classList.remove("invalid");
    field.classList.add("valid");
    return true;
}

function validateInput(field) {
    const value = field.value.trim();

    switch (field.id) {
        case "email":
            if (!value) return setInvalid(field, "Email obrigatório");
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return setInvalid(field, "Email inválido");
            break;

        case "codigo":
            if (!value) return setInvalid(field, "Código obrigatório");
            if (!/^[0-9A-Z]{6}$/.test(value)) return setInvalid(field, "Código inválido");
            break;

        case "password":
            if (!value) return setInvalid(field, "Password obrigatória");
            break;

        case "confirm_password":
            const passValue = document.getElementById("password").value;
            if (!value) return setInvalid(field, "Confirmação obrigatória");
            if (value !== passValue) return setInvalid(field, "As passwords não coincidem");
            break;
    }

    return setValid(field);
}