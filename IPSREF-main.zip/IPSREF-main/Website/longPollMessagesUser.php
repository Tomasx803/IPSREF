<?php
session_start();
include 'conexao.php';

header('Content-Type: application/json');

if (!isset($_SESSION['aluno_id']) && !isset($_SESSION['adm_pes_id'])) {
    echo json_encode(["error" => "Not Logged In"]);
    exit;
}


$pessoa_id = isset($_SESSION['aluno_id']) ? $_SESSION['aluno_id'] : null;
$admin_id = isset($_SESSION['adm_pes_id']) ? $_SESSION['adm_pes_id'] : null;

$userId = $pessoa_id != null ? $pessoa_id : ($admin_id != null ? $admin_id : null);
session_write_close();
$lastMsgId = isset($_GET['last_id']) ? intval($_GET['last_id']) : null;
$chatId = isset($_GET['chatId']) ? intval($_GET['chatId']) : null;

if (!$lastMsgId || !$chatId){
    header('Content-Type: application/json');
    echo json_encode(["error" => "params not provided"]);
    exit;
}

$timeout = 30;
$startTime = time();

$newMessages = [];

while ((time() - $startTime) < $timeout) {
    $q = query($conn, "SELECT * FROM mensagem WHERE msg_id > $lastMsgId and msg_csp_id  = $chatId ORDER BY msg_data ASC");

    if (numrows($q) > 0) {
        while ($f = assoc($q)) {
            $newMessages[] = $f;
        }
        break; 
    }

    usleep(1000000);
}

$response = [];

if (!empty($newMessages)) {
    $response = [
        'status' => 'success',
        'messages' => $newMessages,
        'usId' => $userId
    ];
} else {
    $response = [
        'status' => 'noMessagesFound',
        'messages' => []
    ];
}

echo json_encode($response);