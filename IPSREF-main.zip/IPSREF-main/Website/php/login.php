<?php
include '../conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n_estudante = $_POST['n_estudante'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM view_utilizadores WHERE aluno_n_estudante = '$n_estudante' AND pessoa_pass = '$pass'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        // se exisitir sessao eliminar
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_unset();
            session_destroy();
        }else {
            session_start();
        }
        $_SESSION = [];
        $_SESSION['aluno_id'] = $user['pessoa_id'];
        $_SESSION['nome'] = $user['pessoa_nome'];
        header("Location: calendario.php");
        exit();
    } else {    
        $erro = "Número de estudante ou palavra-passe incorretos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IPSREF - Senhas Online</title>
    <link rel="stylesheet" href="../css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

</head>
<body>
<div class="container">
    <header>
        <img src="../logos/logoipsref.jpg" alt="Logo IPSREF" class="logo">
    </header>

    <main class="login-section">
        <div class="login-box">
            <h2>Bem-vindo/a ao <span style="color: #0077b6;">IPSREF</span></h2>

            <?php if (!empty($erro)): ?>
                <p style="color:red;"><?= $erro ?></p>
            <?php endif; ?>

            <form method="POST">
                <input type="text" name="n_estudante" placeholder="Número de estudante" class="input-field" required>
                <input type="password" name="pass" placeholder="Palavra-passe" class="input-field" required>
                <button type="submit" class="btn">Entrar</button>
            </form>

            <div class="links">
                <a href="../php/registar.php">Criar conta</a>
            </div>
            <div class="links">
                <a href="../php/recuperar_password.php">Recuperar palavra-passe</a>
            </div>
        </div>
    </main>
</div>
</body>
</html>
