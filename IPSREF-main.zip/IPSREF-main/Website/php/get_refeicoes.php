<?php
session_start();
include '../conexao.php';

if (!isset($_SESSION['aluno_id'])) {
    http_response_code(403);
    echo json_encode(["erro" => "Não autenticado."]);
    exit();
}

$id_aluno = $_SESSION['aluno_id'];

// Buscar as senhas (refeições) do aluno logado
$sql = "SELECT tipo, periodo, data_agendada 
        FROM senha 
        WHERE id_aluno = ? AND data_agendada IS NOT NULL";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_aluno);
$stmt->execute();
$result = $stmt->get_result();

$refeicoes = [];

while ($row = $result->fetch_assoc()) {
    $refeicoes[] = [
        "title" => ucfirst($row['tipo']) . " (" . $row['periodo'] . ")",
        "start" => $row['data_agendada']
    ];
}

header('Content-Type: application/json');
echo json_encode($refeicoes);
?>
