<?php
session_start();
include '../conexao.php';

// Se o utilizador não estiver logado, redireciona para o login
if (!isset($_SESSION['aluno_id'])) {
  header("Location: login.php");
  exit();
}

$id = $_SESSION['aluno_id'];
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IPSREF - Histórico</title>
  <link rel="stylesheet" href="../css/historico.css?v=3232<?php echo time(); ?>">
  <link rel="stylesheet" href="../css/style.css?v=23<?php echo time(); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">



  <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>


  <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />

      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>

  <style>
    .pagination {
      display: flex;
      align-items: center;
      gap: 6px;
      font-family: sans-serif;
      justify-content: center;
    }

    .pagination .page-number {
      border: 1px solid #ccc;
      padding: 7px 10px;
      background: #fff;
      cursor: pointer;
      border-radius: 4px;
    }

    .page-arrow {
      display: flex;
      justify-content: center;
      align-items: center;
      border: 1px solid #ccc;
      background: #fff;
      cursor: pointer;
      border-radius: 4px;
      padding: 2.5px 2px;
    }

    .pagination .active {
      background: #007bff;
      color: white;
      border-color: #007bff;
    }

    .pagination button:hover {
      background: #8f8f8fff;
      border-color: #8f8f8fff;
      color: white;
    }
  </style>
</head>

<body>

  <!-- === Barra lateral === -->
  <?php include 'sidebar.php'; ?>

  <main class="content">
    <!-- === Header === -->
    <?php include 'header.php'; ?>

    <!-- === Secção principal === -->
    <section class="historico">

      <div class="title-section">
        <h2>Histórico de Senhas</h2>

        <div class="controls">


          <div class="dropdown-wrapper">

            <button id="sort-by-button" class="title-section-button">
              <img src="../logos/sortByIcon.svg">
              Ordenar
              <span class="filterActive-badge filterActive-sortBy d-none">1</span>
            </button>

            <div id="floating-window-sortBy" class="floating-window d-none">
              <div class="floating-item sortByOption" data-option="date:asc">Data: Ascendente</div>
              <div class="floating-item sortByOption" data-option="date:desc">Data: Descendente</div>
              <div class="floating-item sortByOption" data-option="plate:asc">Prato: Ascendente</div>
              <div class="floating-item sortByOption" data-option="plate:desc">Prato: Descendente</div>
            </div>

          </div>

          <div class="dropdown-wrapper">
            <button id="filter-by-button" class="title-section-button">
              <img src="../logos/filterByIcon.svg">
              Filtrar
              <span class="filterActive-badge filterActive-filterBy d-none">1</span>
            </button>

            <div id="floating-window-filterBy" class="floating-window floating-window-large d-none">


              <div class="filter-block">
                <h4 class="filter-title">Data de Agendação</h4>

                <div class="filter-options">
                  <div class="filter-item">
                    <label for="filter-startDate">De:</label>
                    <input type="date" id="filter-startDate" name="start-date">
                  </div>

                  <div class="filter-item">
                    <label for="filter-endDate">Até:</label>
                    <input type="date" id="filter-endDate" name="end-date">
                  </div>
                </div>

              </div>


              <div class="filter-block">
                <h4 class="filter-title">Estado Atual:</h4>

                <div class="filter-options">
                  <div class="filter-item">
                    <select id="filter-estado">
                      <option>Nenhum</option>
                      <?php
                      $statusComments = [
                        'A'   => 'Senha agendada',
                        'U'   => 'Senha utilizada',
                        'PA'  => 'Senha por agendar',
                        'R'   => 'Senha reembolsada',
                        'C'   => 'Chat criado',
                        'CEC' => 'Chat em curso',
                        'F'   => 'Chat fechado'
                      ];
                      $eq = query($conn, "select * from estado");
                      if (numrows($eq) > 0) {
                        while ($qf = assoc($eq)) {
                          $code = $qf["est_descricao"];
                          $label = isset($statusComments[$code]) ? $statusComments[$code] : $code;
                          echo "<option value='" . $code . "'>" . $label . "</option>";
                        }
                      }
                      ?>
                    </select>
                  </div>
                </div>

              </div>


              <div class="filter-block">
                <h4 class="filter-title">Periodo:</h4>

                <div class="filter-options">
                  <div class="filter-item">
                    <select id="filter-periodo">
                      <option>Nenhum</option>
                      <?php
                      $pq = query($conn, "select * from tipo_senha");
                      if (numrows($pq) > 0) {
                        while ($pf = assoc($pq)) {
                          echo "<option value='" . $pf['tps_descricao'] . "'>" . $pf['tps_descricao'] . "</option>";
                        }
                      }
                      ?>
                    </select>
                  </div>
                </div>

              </div>

              <div class="filter-block">
                <h4 class="filter-title">Prato:</h4>

                <div class="filter-options">
                  <div class="filter-item">
                    <input id="filter-pratos" name='input-custom-dropdown' class='tagify--custom-dropdown' placeholder='Escolhe vários pratos, no máximo 10'>
                  </div>
                </div>

              </div>

              <div class="filter-block">
                <h4 class="filter-title">Estado Especiais:</h4>

                <div class="filter-options">
                  <div class="filter-item">
                    <select id="filter-specialEstado">
                      <option>Nenhum</option>
                      <option value="refundable">Reembolsável</option>
                      <option value="expired">Expirado</option>
              
                    </select>
                  </div>
                </div>

              </div>



              <div class="filter-block filter-block-footer">
                <div class="filter-options">

                  <button id="remove-filtersHistorico-button">Repor Todos</button>
                  <button id="apply-filtersHistorico-button">Aplicar Filtros</button>

                </div>
              </div>



            </div>

          </div>


        </div>


      </div>




      <div class="historico-container"></div>

      <div class="pagination">
        <button class="page-arrow page-arrow-previous">

          <svg viewBox="0 0 24 24" class="page-arrow-previous" fill="none" width="24" xmlns="http://www.w3.org/2000/svg" transform="rotate(180)">
            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
            <g id="SVGRepo_iconCarrier">
              <path d="M10 7L15 12L10 17" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            </g>
          </svg>

        </button>
        <div class="pagination-buttons">

        </div>
        <button class="page-arrow page-arrow-next">
          <svg viewBox="0 0 24 24" fill="none" class="page-arrow-next" width="24" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 7L15 12L10 17" stroke="#000000" stroke-width="1.5"
              stroke-linecap="round" stroke-linejoin="round"></path>
          </svg>

        </button>

      </div>

      <!-- === Botão para visualizar o modal === -->
      <button style="display:none" id="dayInformationModal-trigger" data-micromodal-trigger="dayInformationModal">Open modal</button>

      <div class="app-modal micromodal-slide" id="dayInformationModal" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
          <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">

            <header class="app-modal__header">
              <h2 class="app-modal__title" id="modal-1-title">Histórico de Estado da senha</h2>
              <button class="app-modal__close closeSenhaInformacaoButton" aria-label="Close modal" data-micromodal-close></button>
            </header>

            <main class="app-modal__content" id="modal-1-content">
              <table class="dayInformationModal-table">
                <tbody id="senha-estadoHistorico-tbody">
                  <tr>

                  </tr>
                </tbody>
              </table>
            </main>
          </div>
        </div>
      </div>

    </section>
  </main>

  <!-- === JS Global === -->
  <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
  <script src="../javascript/alertas.js?v=<?php echo time(); ?>"></script>

  <!-- === JS Histórico === -->
  <script src="../javascript/historico.js?v=<?php echo time(); ?>"></script>
  <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>


</body>

</html>