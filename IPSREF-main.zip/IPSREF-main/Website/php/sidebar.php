<?php
    // Obtem o nome do ficheiro atual
    $activePage = basename($_SERVER['PHP_SELF']);
?>

<aside class="sidebar">
    <a href="calendario.php">
        <img src="../logos/logoipsref.jpg" alt="Logo IPSREF" class="logo">
    </a>
    <nav>
        <ul>
            <li><a href="../php/calendario.php" class="<?= $activePage == 'calendario.php' ? 'active' : '' ?>">Calendário</a></li>

            <li><a href="../php/historico.php" class="<?= $activePage == 'historico.php' ? 'active' : '' ?>">Histórico</a></li>

            <li><a href="../php/perfil.php" class="<?= $activePage == 'perfil.php' ? 'active' : '' ?>">Perfil</a></li>
 
            <li><a href="../php/suporte.php" class="<?= $activePage == 'suporte.php' || $activePage == "chats.php"  || $activePage == "chat.php" ? 'active' : '' ?>">Suporte</a></li>

            <li><a href="../php/faq.php" class="<?= $activePage == 'faq.php' ? 'active' : '' ?>">FAQs</a></li>
        </ul>
    </nav>
</aside>