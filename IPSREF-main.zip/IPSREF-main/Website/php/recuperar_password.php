<?php
session_start();
include '../conexao.php';
include "enviar_emails.php";

$msg = null;
$type = null;
$title = null;
$step = $_SESSION['step'] ?? 'email';
$old_email = $_POST['email'] ?? $_SESSION['email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['action']) && $_POST['action'] === 'enviar_email') {
        $email = $_POST['email'];
        $sql = "SELECT * FROM view_utilizadores WHERE pessoa_email = '$email'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 0) {
            $type = "warning";
            $title = "Erro";
            $msg = "Email não encontrado.";
        } else {
            $row = mysqli_fetch_assoc($result);
            $pesId = $row['pessoa_id'];
            $nome = $row['pessoa_nome'];

            $permittedChars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            do {
                $codigo = substr(str_shuffle($permittedChars), 0, 6);
                $sqlCheck = "SELECT * FROM codigos_recuperacao 
                             WHERE cor_pes_id = '$pesId' AND cor_codigo = '$codigo'";
                $resultCheck = mysqli_query($conn, $sqlCheck);
            } while (mysqli_num_rows($resultCheck) > 0);

            $expira = date("Y-m-d H:i:s", time() + 600);

            $sqlInsert = "INSERT INTO codigos_recuperacao (cor_pes_id, cor_codigo, cor_data_expiracao)
                          VALUES ('$pesId', '$codigo', '$expira')";
            mysqli_query($conn, $sqlInsert);

            $emailSent = enviarCodigoRecuperacao($email, $nome, $codigo);

            if ($emailSent) {
                $_SESSION['email'] = $email;
                $_SESSION['step'] = 'codigo';
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            } else {
                $type = "error";
                $title = "Erro";
                $msg = "Ocorreu um erro ao enviar o email. Tente novamente mais tarde.";
            }
        }
    }

    if (isset($_POST['action']) && $_POST['action'] === 'validar_codigo') {
        $email = $_SESSION['email'];
        $codigo = $_POST['codigo'];

        $sql = "SELECT * FROM view_utilizadores WHERE pessoa_email = '$email'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $pesId = $row['pessoa_id'];

            $sqlCodigo = "SELECT * FROM codigos_recuperacao 
                          WHERE cor_pes_id = '$pesId' 
                          AND cor_codigo = '$codigo' 
                          AND cor_data_expiracao > NOW()
                          ORDER BY cor_id DESC LIMIT 1";
            $resultCodigo = mysqli_query($conn, $sqlCodigo);

            if (mysqli_num_rows($resultCodigo) > 0) {
                $_SESSION['codigo'] = $codigo;
                $_SESSION['step'] = 'password';
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            } else {
                $type = "error";
                $title = "Erro";
                $msg = "Código inválido ou expirado.";
            }
        }
    }

    if (isset($_POST['action']) && $_POST['action'] === 'redefinir_password') {
        $email = $_SESSION['email'];
        $codigo = $_SESSION['codigo'];
        $novaPassword = $_POST['password'];
        $confirmarPassword = $_POST['confirm_password'];

        if ($novaPassword !== $confirmarPassword) {
            $type = "error";
            $title = "Erro";
            $msg = "As passwords não coincidem.";
        } else {
            $sql = "SELECT * FROM view_utilizadores WHERE pessoa_email = '$email'";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $pesId = $row['pessoa_id'];

                $sqlCodigo = "SELECT * FROM codigos_recuperacao 
                              WHERE cor_pes_id = '$pesId' 
                              AND cor_codigo = '$codigo' 
                              AND cor_data_expiracao > NOW()
                              ORDER BY cor_id DESC LIMIT 1";
                $resultCodigo = mysqli_query($conn, $sqlCodigo);

                if (mysqli_num_rows($resultCodigo) > 0) {
                    $sqlUpdate = "UPDATE pessoa SET pes_pass = '$novaPassword' WHERE pes_id = '$pesId'";
                    mysqli_query($conn, $sqlUpdate);

                    $sqlDelete = "DELETE FROM codigos_recuperacao WHERE cor_pes_id = '$pesId'";
                    mysqli_query($conn, $sqlDelete);

                    session_destroy();

                    $type = "success";
                    $title = "Sucesso";
                    $msg = "Password redefinida com sucesso!";

                    echo "<script>
                        setTimeout(function() {
                            window.location.href = 'login.php';
                        }, 2000);
                    </script>";
                } else {
                    $type = "error";
                    $title = "Erro";
                    $msg = "Código inválido ou expirado.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IPSREF - Senhas Online</title>
    <link rel="stylesheet" href="../css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
</head>

<body>
    <div class="container">
        <header>
            <img src="../logos/logoipsref.jpg" alt="Logo IPSREF" class="logo">
        </header>

        <main class="login-section">
            <div class="login-box">
                <?php if ($step === 'email'): ?>
                    <h2>Recuperar Palavra-Passe</h2>
                    <p style="margin-bottom: 10px;">Introduza o seu email abaixo e siga as instruções</p>

                    <form method="POST" id="emailForm">
                        <input type="hidden" name="action" value="enviar_email">
                        <input type="email" name="email" id="email" placeholder="Email" class="input-field" value="<?= htmlspecialchars($old_email, ENT_QUOTES, 'UTF-8') ?>">
                        <span class="message-error"></span>
                        <button type="submit" class="btn">Recuperar Palavra-Passe</button>
                    </form>
                <?php endif; ?>

                <?php if ($step === 'codigo'): ?>
                    <h2>Inserir Código</h2>
                    <p style="margin-bottom: 10px;">Insira o código de 6 dígitos enviado para o seu email</p>

                    <form method="POST" id="codigoForm">
                        <input type="hidden" name="action" value="validar_codigo">
                        <input type="text" name="codigo" id="codigo" placeholder="Código" class="input-field" maxlength="6">
                        <span class="message-error"></span>
                        <button type="submit" class="btn">Validar Código</button>
                    </form>
                <?php endif; ?>

                <?php if ($step === 'password'): ?>
                    <h2>Redefinir Password</h2>
                    <p style="margin-bottom: 10px;">Insira a sua nova palavra-passe</p>

                    <form method="POST" id="passwordForm">
                        <input type="hidden" name="action" value="redefinir_password">
                        <input type="password" name="password" id="password" placeholder="Nova Palavra-Passe" class="input-field">
                        <span class="message-error"></span>
                        <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirmar Palavra-Passe" class="input-field">
                        <span class="message-error"></span>
                        <button type="submit" class="btn">Redefinir palavra-passe</button>
                    </form>
                <?php endif; ?>
                <div class="links">
                    <a href="../php/login.php">Voltar para o login</a>
                </div>

                <?php if ($step !== 'email'): ?>

                <div class="links">
                    <a href="#" onclick="fetch(`../api.php?type=sessionSetStepEmail`).then(d => window.location.reload())"  class="resendCode" id="resendCodeLink">Reenviar Código</a>
                </div>

                <?php endif; ?>

            </div>
        </main>
    </div>

    <script src="../javascript/alertas.js"></script>
    <script src="../javascript/inputmask/dist/inputmask.min.js"></script>

    <script>
        <?php if ($msg): ?>
            notify("<?= $type ?>", "<?= $title ?>", "<?= $msg ?>");
        <?php endif; ?>
    </script>



    <script src="../javascript/recuperar_password.js"></script>
</body>

</html>