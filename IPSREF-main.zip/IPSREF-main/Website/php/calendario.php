<?php
include '../conexao.php';
session_start();
if (!isset($_SESSION['aluno_id'])) {
    header("Location: login.php");
    exit();
}
$sql = "SELECT * FROM aluno";
$result = $conn->query($sql);
$r = $result->fetch_assoc();

$extrasq = query($conn, "select * from extras where extras.ext_estado = 1");
$extras = [];
while ($row = assoc($extrasq)) {
    $extras[$row['ext_id']] = $row['ext_nome'];
}

?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IPSREF - Calendário</title>
    <link rel="stylesheet" href="../css/calendario.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>


    <style>
        a {
            color: inherit;
            text-decoration: none;
        }

        a:hover {
            text-decoration: none;
            color: inherit;
        }

        .fc-event-time {
            display: none !important;
        }
    </style>
</head>

<body>

    <!-- === Header === -->
    <?php include 'header.php' ?>

    <div class="calendario-container">

        <!-- === Barra lateral === -->
        <?php include 'sidebar.php'; ?>

        <main class="calendario-main">
            <div class="calendario-content-box"></div>
        </main>
    </div>

    <!-- === Botão para visualizar o modal === -->
    <button style="display:none" id="dayInformationModal-trigger" data-micromodal-trigger="dayInformationModal">Open modal</button>

    <!-- === Modal para visualizar informação adicional sobre as senhas === -->
    <div class="app-modal micromodal-slide" id="dayInformationModal" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">

                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">Mais Informação</h2>
                    <button class="app-modal__close closeSenhaInformacaoButton" aria-label="Close modal" data-micromodal-close></button>
                </header>

                <main class="app-modal__content" id="modal-1-content">
                    <table class="dayInformationModal-table">
                        <tbody>
                            <tr>
                                <th>Tipo:</th>
                                <td id="tipo-senha"></td>
                            </tr>
                            <tr>
                                <th>Date Compra:</th>
                                <td style="display:flex; align-items: center;">


                                    <span id="dataCompra-senha"></span>
                                    <input  id="editSenha-input-date" type="date">


                                    <svg xmlns="http://www.w3.org/2000/svg" id="editSenha-data-button" style="margin-left:15px; width:15px; cursor:pointer;" viewBox="0 0 640 640">
                                        <path style="pointer-events:none;" d="M416.9 85.2L372 130.1L509.9 268L554.8 223.1C568.4 209.6 576 191.2 576 172C576 152.8 568.4 134.4 554.8 120.9L519.1 85.2C505.6 71.6 487.2 64 468 64C448.8 64 430.4 71.6 416.9 85.2zM338.1 164L122.9 379.1C112.2 389.8 104.4 403.2 100.3 417.8L64.9 545.6C62.6 553.9 64.9 562.9 71.1 569C77.3 575.1 86.2 577.5 94.5 575.2L222.3 539.7C236.9 535.6 250.2 527.9 261 517.1L476 301.9L338.1 164z" />
                                    </svg>


                                </td>
                            </tr>
                            <tr>
                                <th>Estado:</th>
                                <td id="estado-senha"></td>
                            </tr>
                            <tr>
                                <th>Prato:</th>
                                <td style="display:flex; align-items: center;">


                                    <span id="prato-senha"></span>

                                    <select id="editSenha-select-prato" class="agendarSenha-input-div-select">
                                    </select>

                                    <svg xmlns="http://www.w3.org/2000/svg" id="editSenha-prato-button" style="margin-left:15px; width:15px; cursor:pointer; display:none !important;" viewBox="0 0 640 640">
                                        <path style="pointer-events:none;" d="M416.9 85.2L372 130.1L509.9 268L554.8 223.1C568.4 209.6 576 191.2 576 172C576 152.8 568.4 134.4 554.8 120.9L519.1 85.2C505.6 71.6 487.2 64 468 64C448.8 64 430.4 71.6 416.9 85.2zM338.1 164L122.9 379.1C112.2 389.8 104.4 403.2 100.3 417.8L64.9 545.6C62.6 553.9 64.9 562.9 71.1 569C77.3 575.1 86.2 577.5 94.5 575.2L222.3 539.7C236.9 535.6 250.2 527.9 261 517.1L476 301.9L338.1 164z" />
                                    </svg>




                                </td>
                            </tr>
                            <tr>
                                <th>Extras:</th>
                                <td style="display:flex; align-items: center;">

                                    <span id="extras-senha"></span>

                                    <div class="select-container" style="width: 100%" id="editSenha-extras-container" data-extra-options='<?php echo json_encode($extras); ?>'>



                                        <div class="icon-slot addExtraOptionEditarSenha">


                                            <svg xmlns="http://www.w3.org/2000/svg" width="22" viewBox="0 0 640 640">
                                                <path d="M352 128C352 110.3 337.7 96 320 96C302.3 96 288 110.3 288 128L288 288L128 288C110.3 288 96 302.3 96 320C96 337.7 110.3 352 128 352L288 352L288 512C288 529.7 302.3 544 320 544C337.7 544 352 529.7 352 512L352 352L512 352C529.7 352 544 337.7 544 320C544 302.3 529.7 288 512 288L352 288L352 128z" />
                                            </svg>
                                        </div>

                                    </div>

                                    <svg xmlns="http://www.w3.org/2000/svg" id="editSenha-extras-button" style="margin-left:15px; width:15px; cursor:pointer;" viewBox="0 0 640 640">
                                        <path d="M416.9 85.2L372 130.1L509.9 268L554.8 223.1C568.4 209.6 576 191.2 576 172C576 152.8 568.4 134.4 554.8 120.9L519.1 85.2C505.6 71.6 487.2 64 468 64C448.8 64 430.4 71.6 416.9 85.2zM338.1 164L122.9 379.1C112.2 389.8 104.4 403.2 100.3 417.8L64.9 545.6C62.6 553.9 64.9 562.9 71.1 569C77.3 575.1 86.2 577.5 94.5 575.2L222.3 539.7C236.9 535.6 250.2 527.9 261 517.1L476 301.9L338.1 164z" />
                                    </svg>

                                </td>
                            </tr>
                        </tbody>
                    </table>

                </main>
                <div style="display:flex">
                    <footer class="modal__footer reemboolsarSenhaDiv d-none" style="gap:9px">
                        <button class="modal__btn modal__btn-warning reemboolsarSenhaButton">Reembolsar</button>
                    </footer>
                    <footer class="modal__footer mdft" style="gap:9px; width: 100%; justify-content:space-between;">
                        <button class="modal__btn modal__btn-primary editSenhaButton">Editar</button>
                        <button class="modal__btn mdftbtn" aria-label="Close this dialog window">Cancelar</button>
                    </footer>
                </div> 
            </div>
        </div>
    </div>

    <button style="display:none" id="modal-1-trigger" data-micromodal-trigger="modal-1">Open modal</button>


    <div class="app-modal micromodal-slide" id="modal-1" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">
                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">
                        Agendar Senha
                    </h2>
                    <button class="app-modal__close closeAgendarSenhaModal" aria-label="Close modal" data-micromodal-close></button>
                </header>
                <main class="app-modal__content agendarSenha-modal-content" id="modal-1-content">


                    <div class="agendarSenha-input-div">
                        <label>Prato (Não Obrigatorio)</label>
                        <select id="agendarSenha-prato">
                            <option value="nenhum">Nenhum</option>
                        </select>
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Extras</label>
                        <div class="select-container select-container-agendarSenha" data-extra-options='<?php echo json_encode($extras); ?>'>



                            <div class="icon-slot addExtraOptionAgendarSenha">
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" viewBox="0 0 640 640">
                                    <path d="M352 128C352 110.3 337.7 96 320 96C302.3 96 288 110.3 288 128L288 288L128 288C110.3 288 96 302.3 96 320C96 337.7 110.3 352 128 352L288 352L288 512C288 529.7 302.3 544 320 544C337.7 544 352 529.7 352 512L352 352L512 352C529.7 352 544 337.7 544 320C544 302.3 529.7 288 512 288L352 288L352 128z" />
                                </svg>
                            </div>

                        </div>
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Periodo*</label>
                        <select id="agenderSenha-periodo" style="max-width: 40%;">

                            <?php
                            $tq = query($conn, "select * from tipo_senha");
                            while ($r = assoc($tq)) {
                                echo "<option value='" . $r['tps_id'] . "'>" . $r['tps_descricao'] . "</option> ";
                            }
                            ?>
                        </select>
                    </div>

                </main>
                <footer class="modal__footer">
                    <button class="modal__btn modal__btn-primary agendarSenha">Agendar</button>
                    <button class="modal__btn" data-micromodal-close aria-label="Close this dialog window">Cancelar</button>
                </footer>
            </div>
        </div>
    </div>


    <!-- Scripts -->
    <script src="../javascript/calendario.js?v=<?php echo time(); ?>"></script>
    <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
    <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>
    <script src="../javascript/alertas.js"></script>


</body>

</html>