<?php
include '../conexao.php';
session_start();

$faqQuery = "SELECT * FROM faq";
$faqResult = $conn->query($faqQuery);

$cont = 0;
?>

<!DOCTYPE html>
<html lang="pt">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perguntas Frequentes - IPSREF</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/faq.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  </head>
  <body>

    <!-- === Barra lateral === -->
    <?php include 'sidebar.php'; ?>

    <main class="content">
      <!-- === Barra lateral === -->
      <?php include 'header.php'; ?>

      <section class="faq-section">

        <h1>Perguntas Frequentes</h1>

        <?php while ($faq = mysqli_fetch_assoc($faqResult)): ?>
          <?php $cont ++; ?>
          <div class="faq-item">
            <button class="faq-question"><?= $cont . '. ' . $faq['faq_titulo'] ?></button>
            <div class="faq-answer">
              <p><?= $faq['faq_conteudo'] ?></p>
            </div>
          </div>
        <?php endwhile; ?>

      </section>
    </main>

    <!-- === JS Global === -->
    <script src="../javascript/global.js"></script>

    <!-- === JS Faq === -->
    <script src="../javascript/faq.js"></script>

  </body>
</html>

