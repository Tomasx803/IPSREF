<?php
include '../conexao.php';
session_start();

$sql = "SELECT * FROM aluno"; // ajusta o nome da tua tabela
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FAQ - IPSREF</title>
  <link rel="stylesheet" href="../css/suporte.css?v=<?php echo time(); ?>">
  <link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
  <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
</head>

<body>

  <!-- === Barra lateral === -->
  <?php include 'sidebar.php'; ?>

  <main class="content">

    <!-- === Header === -->
    <?php include 'header.php'; ?>

    <section class="faq-section">

      <div class="faq-header">


        <h1 style="font-size:40px;">Centro de Suporte</h1>


        <div>
          <button id="sort-by-button" class="title-section-button title-section-button-active" onclick="window.location.href='suporte.php'">
            <img src="../logos/leftArrowIcon.svg">
            Enviar
            <span class="filterActive-badge filterActive-sortBy d-none">1</span>
          </button>


          <button id="sort-by-button" class="title-section-button" onclick="window.location.href='chats.php'">
            <img src="../logos/chatBubbleIcon.svg">
            Chat
            <span class="filterActive-badge filterActive-sortBy d-none">1</span>
          </button>
        </div>


      </div>


      <h2>Enviar Pedido de Ajuda</h2>


      <?php
      $options = ["Problema no site", "Agendação da Senha", "Recomendações", "Outro"];
      ?>

      <form class="faq-form">


        <label style="font-size:22px; margin-bottom:10px;">Escolha a razão</label>
        <select style="margin-bottom:20px;" name="reason" id="reason">
          <?php
          foreach ($options as $option) {
            $safe = htmlspecialchars($option, ENT_QUOTES, 'UTF-8');
            echo "<option value=\"{$safe}\">{$safe}</option>\n";
          }
          ?>
        </select>



        <label style="font-size:22px; margin-bottom:10px;">Descreva o problema</label>
        <textarea id="mensagem" placeholder="Explique detalhadamente o que aconteceu..."></textarea>


        <button type="submit">Enviar Pedido</button>
      </form>


    </section>

  </main>

  <!-- === JS Global === -->
  <script src="../javascript/global.js"></script>
  <!-- === JS Suporte === -->
  <script src="../javascript/suporte.js?v=<?php echo time(); ?>"></script>
  <script src="../javascript/alertas.js?v=<?php echo time(); ?>"></script>

</body>

</html>