
<?php
echo "<script src='../javascript/notificationsHandler.js'></script>"
?>
<header class="topbar">
    <div class="icons">

        <!-- BOTÃO MENU MOBILE -->
        <button id="menu-btn" class="menu-btn" aria-label="Abrir menu">
            <i class="fa-solid fa-bars"></i>
        </button>

        <?php
            // Buscar notificações do aluno
            $aluno_id = $_SESSION['aluno_id'];
            $sql = "SELECT not_id, not_titulo, not_mensagem, not_data, not_lida 
                    FROM notificacao 
                    WHERE not_pes_id = $aluno_id 
                    ORDER BY not_data DESC";
            $result = mysqli_query($conn, $sql);

            // Contar notificações não lidas
            $sql_count = "SELECT COUNT(*) as total 
                        FROM notificacao 
                        WHERE not_pes_id = $aluno_id AND not_lida = FALSE";
            $result_count = mysqli_query($conn, $sql_count);
            $count = mysqli_fetch_assoc($result_count)['total'];
        ?>

        <div class="notificacao">
            <span id="bell" class="bell">
                <i class="fa-solid fa-bell"></i>
                <?php if ($count > 0): ?>
                    <span class="badge"><?php echo $count; ?></span>
                <?php endif; ?>
            </span>

            <div id="popup" class="popup">
                <p><strong>Notificações</strong></p>
                <hr>

                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($notif = mysqli_fetch_assoc($result)): ?>
                        <div class="notificacao-item <?php echo $notif['not_lida'] ? 'lida' : 'nao-lida'; ?>">
                            <?php if (!$notif['not_lida']): ?>
                                <span class="nova-badge">NOVA</span>
                            <?php endif; ?>
                            <p><strong><?php echo $notif['not_titulo']; ?></strong></p>
                            <p><?php echo $notif['not_mensagem']; ?></p>
                            <span class="data"><?php echo date('d/m/Y', strtotime($notif['not_data'])); ?></span>
                        </div>
                        <hr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="notificacao-item">
                        <p>Sem notificações</p>
                    </div>
                    <hr>
                <?php endif; ?>

                <div class="popup-acoes">
                    <button id="marcarLidas">Marcas todas como lidas</button>
                    <button id="limpar">Limpar</button>
                </div>
            </div>
        </div>
        <a href="perfil.php" style="text-decoration: none; color: inherit;">
            <span class="utilizador"><i class="fa-solid fa-user"></i></span>
        </a>
        <?= htmlspecialchars($_SESSION['nome']) ?></span>
        
        <a href="../php/logout.php" class="logout">Sair</a>
    </div>
</header>
