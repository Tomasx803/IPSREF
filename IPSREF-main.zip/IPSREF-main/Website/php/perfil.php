<?php
session_start();
include '../conexao.php';

if (!isset($_SESSION['aluno_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['aluno_id'];

// Buscar dados atuais
$sqlView = "SELECT * FROM view_utilizadores WHERE pessoa_id = $id";
$result = $conn->query($sqlView);
$viewRow = $result->fetch_assoc();

// Caminho da foto para mostrar
$imagemParaMostrar = $viewRow['pessoa_foto'] ?? "uploads/default.png";

// Estatísticas do utilizador
$precoSenha = 2.50; // preço unitário das senhas

$sqlTotalSenhas = "SELECT COUNT(*) AS total FROM senha WHERE sen_pes_id = ? AND sen_est_atual_id <> (SELECT est_id FROM estado WHERE est_descricao = 'R')";
$stmt = $conn->prepare($sqlTotalSenhas);
$stmt->bind_param("i", $id);
$stmt->execute();
$totalSenhas = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

$totalGasto = $totalSenhas * $precoSenha;

// Atualizar dados do perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $apelido = trim($_POST['apelido']);
    $email = trim($_POST['email']);
    $pass = trim($_POST['pass']);
    $notifSenhasExpirar = isset($_POST['notifSenhasExpirar']) ? 1 : 0;
    $notifPrazoReembolso = isset($_POST['notifPrazoReembolso']) ? 1 : 0;

    // Validação básica
    $errors = [];
    if (empty($nome) || !preg_match('/^[a-zA-ZÀ-ÿ\s\'-]+$/', $nome)) $errors['nome'] = "Nome inválido";
    if (empty($apelido) || !preg_match('/^[a-zA-ZÀ-ÿ\s\'-]+$/', $apelido)) $errors['apelido'] = "Apelido inválido";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = "Email inválido";

    if (!empty($errors)) {
        $_SESSION['erros_perfil'] = $errors;
        header("Location: perfil.php");
        exit();
    }

    // Foto
    $imagem = $viewRow['pessoa_foto'];
    if (!empty($_FILES['foto']['name']) && $_FILES['foto']['error'] === 0) {
        $target_dir_fs = "../uploads/";
        $target_dir_db = "uploads/";

        if (!is_dir($target_dir_fs)) mkdir($target_dir_fs, 0777, true);

        $foto_nome = basename($_FILES["foto"]["name"]);
        $target_file_fs = $target_dir_fs . $foto_nome;
        $target_file_db = $target_dir_db . $foto_nome;

        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file_fs)) {
            $imagem = $target_file_db;
        }
    }

    // UPDATE
    $sql = "UPDATE pessoa 
            SET pes_nome=?, pes_apelido=?, pes_email=?, pes_pass=?, pes_foto=?, pes_notif_senhas=?, pes_notif_reembolsos=?
            WHERE pes_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssiii", $nome, $apelido, $email, $pass, $imagem, $notifSenhasExpirar, $notifPrazoReembolso, $id);
    if ($stmt->execute()) {
        $_SESSION['foto'] = $imagem;
        $_SESSION['nome'] = $nome;
        $_SESSION['apelido'] = $apelido;
        $_SESSION['email'] = $email;
        $_SESSION['pass'] = $pass;
        header("Location: perfil.php");
        exit();
    } else {
        $_SESSION['erros_perfil'] = ['geral' => "Erro ao atualizar perfil: " . $conn->error];
        header("Location: perfil.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Perfil - IPSREF</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/perfil.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>

<body>
    <?php include 'sidebar.php'; ?>
    <main class="content">
        <?php include 'header.php'; ?>

        <section class="account">
            <!-- Foto -->
            <form method="post" enctype="multipart/form-data" class="perfilForm" id="perfilForm">

                <section>
                    <div class="icon-perfil">
                        <img id="fotoPerfil" src="<?= '../' . $imagemParaMostrar ?>">
                        <input type="file" id="inputFoto" name="foto" accept="image/*">
                    </div>
                </section>

                <section class="section2">

                    <div class="field locked">
                        <label>Número de estudante</label>
                        <div class="input-wrapper">
                            <input type="text" value="<?= !empty($viewRow['aluno_n_estudante']) ? $viewRow['aluno_n_estudante'] : '-' ?>" readonly>
                            <span class="lock-icon"><i class="fa-solid fa-lock"></i></span>
                        </div>
                    </div>

                    <div class="field">
                        <label>Nome</label>
                        <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($viewRow['pessoa_nome']) ?>">
                        <span id="nome_error" class="message-error"><?= $_SESSION['erros_perfil']['nome'] ?? '' ?></span>
                    </div>

                    <div class="field">
                        <label>Apelido</label>
                        <input type="text" id="apelido" name="apelido" value="<?= htmlspecialchars($viewRow['pessoa_apelido']) ?>">
                        <span id="apelido_error" class="message-error"><?= $_SESSION['erros_perfil']['apelido'] ?? '' ?></span>
                    </div>

                    <div class="field">
                        <label>Email</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($viewRow['pessoa_email']) ?>">
                        <span id="email_error" class="message-error"><?= $_SESSION['erros_perfil']['email'] ?? '' ?></span>
                    </div>

                    <div class="field">
                        <label>Palavra-passe</label>
                        <div class="password-wrapper">
                            <input type="password" id="pass" name="pass" value="<?= htmlspecialchars($viewRow['pessoa_pass']) ?>">
                            <span id="togglePassword" class="eye-icon"><i class="fa-solid fa-eye"></i></span>
                            <span id="pass_error" class="message-error"></span>
                        </div>
                    </div>

                    <!-- Switches -->
                    <div class="notif-row">
                        <span>Receber notificações de senhas a expirar</span>
                        <label class="switch">
                            <input type="checkbox" id="notifSenhasExpirar" name="notifSenhasExpirar" <?= $viewRow['pes_notif_senhas'] ? 'checked' : '' ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>

                    <div class="notif-row">
                        <span>Receber notificações de prazo de reembolso a terminar</span>
                        <label class="switch">
                            <input type="checkbox" id="notifPrazoReembolso" name="notifPrazoReembolso" <?= $viewRow['pes_notif_reembolsos'] ? 'checked' : '' ?>>
                            <span class="slider round"></span>
                        </label>
                    </div>

                    <button type="submit" id="editAllBtn" class="edit-all">Guardar Alterações</button>

                </section>

            </form>

            <!-- Estatísticas -->
            <div class="stats-container">
                <h2>Estatísticas</h2>
                <div class="stats-box">
                    <div class="stat">
                        <span class="stat-label">Senhas compradas</span>
                        <span class="stat-number"><?= $totalSenhas ?></span>
                    </div>
                    <div class="stat">
                        <span class="stat-label">Total gasto</span>
                        <span class="stat-number"><?= number_format($totalGasto, 2, ',', '.') ?> €</span>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script src="../javascript/global.js"></script>
    <script src="../javascript/perfil.js"></script>
    <script src="../javascript/alertas.js"></script>
</body>

</html>
<?php unset($_SESSION['erros_perfil']); ?>