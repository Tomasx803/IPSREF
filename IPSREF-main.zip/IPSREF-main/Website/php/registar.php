<?php
include '../conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n_estudante = $_POST['n_estudante'];
    $nome = $_POST['nome'];
    $apelido = $_POST['apelido'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $confirm = $_POST['confirm'];
    $n_estudante = $_POST['n_estudante'];

    // Inserir na tabela pessoa
    $sqlPessoa = "INSERT INTO pessoa (pes_nome, pes_apelido, pes_email, pes_pass)
    VALUES ('$nome', '$apelido', '$email', '$pass')";

    $resultPessoa = mysqli_query($conn, $sqlPessoa);

    if ($resultPessoa) {
        $pes_id = mysqli_insert_id($conn);

        $permittedChars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

        // Ciclo até gerar um número de cartão único
        do {
            $n_cartao = substr(str_shuffle($permittedChars), 0, 8);

            $sqlCheckCartao = "SELECT * FROM aluno WHERE alu_n_cartao = '$n_cartao'";
            $resultCheckCartao = mysqli_query($conn, $sqlCheckCartao);

        } while (mysqli_num_rows($resultCheckCartao) > 0);

        // Inserir na tabela aluno
        $sqlAluno = "INSERT INTO aluno (alu_pes_id, alu_n_cartao, alu_n_estudante) 
                    VALUES ('$pes_id', '$n_cartao', '$n_estudante')";
        $resultAluno = mysqli_query($conn, $sqlAluno);

        if ($resultAluno) {
            // Notificação de sucesso
            session_start();
            $_SESSION['aluno_id'] = $pes_id;
            $_SESSION['nome'] = $nome;
            header("Location: calendario.php");
            exit();
        } else {
            //  Notificação de erro
        }
    } else {
        //  Notificação de erro
        echo 'Erro';
    }
}
?>


<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>IPSREF - Registo</title>
        <link rel="stylesheet" href="../css/login.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    </head>
    <body>
        <div class="container">
            <header>
                <img src="../logos/logoipsref.jpg" alt="Logo IPSREF" class="logo">
            </header>

            <main class="login-section">
                <div class="login-box">
                    <h2>Criar Conta</h2>

                    <?php if (!empty($erro)): ?>
                        <p style="color:red;"><?= $erro ?></p>
                    <?php endif; ?>

                    <form method="POST" id="registarForm">
                        <input type="text" id="n_estudante" name="n_estudante" placeholder="Número de estudante" class="input-field">
                        <span id="n_estudante_error" class="message-error"></span>

                        <input type="text" id="nome" name="nome" placeholder="Nome" class="input-field">
                        <span id="nome_error" class="message-error"></span>

                        <input type="text" id="apelido" name="apelido" placeholder="Apelido" class="input-field">
                        <span id="apelido_error" class="message-error"></span>

                        <input type="email" id="email" name="email" placeholder="Email" class="input-field">
                        <span id="email_error" class="message-error"></span>

                        <input type="password" id="pass" name="pass" placeholder="Palavra-passe" class="input-field">
                        <span id="pass_error" class="message-error"></span>
                        
                        <input type="password" id="confirm" name="confirm" placeholder="Confirmar palavra-passe" class="input-field">
                        <span id="password_error" class="message-error"></span>

                        <button type="submit" class="btn">Criar Conta</button>
                    </form>

                    <div class="links">
                        <a href="../php/login.php">Entrar</a>
                    </div>
                </div>
            </main>
        </div>

        <!-- === Input Mask === -->
        <script src="../javascript/inputmask/dist/inputmask.min.js"></script>

        <!-- === JS Registar === -->
        <script src="../javascript/registar.js"></script>
        
    </body>
</html>
