<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function enviarCodigoRecuperacao($email, $nome, $codigo) {

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ipsrefoficial@gmail.com';
        $mail->Password = 'xxtl fmnw qynb eady'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('gocamppt@gmail.com', 'IPSREF - Recuperação de Password');

        $mail->addAddress($email, $nome);

        $mail->CharSet = 'UTF-8';

        $mail->isHTML(true);
        $mail->Subject = 'Código de Recuperação de Password';
        $mail->Body = "
            <h2>Recuperação de Password</h2>
            <p>Olá <strong>$nome</strong>,</p>
            <p>O seu código de recuperação é:</p>
            <h1 style='color:#0055ff;'>$codigo</h1>
            <p>Este código é válido por 10 minutos.</p>
            <p>Se não pediu esta recuperação, ignore este email.</p>
        ";

        $mail->send();
        return true;

    } catch (Exception $e) {
        return false;
    }
}


?>