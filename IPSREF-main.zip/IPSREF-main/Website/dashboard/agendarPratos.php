<?php
include '../conexao.php';
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IPSREF</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">


    <link rel="stylesheet" href="../css/dashboard/agendarPratos.css?v=<?php echo time(); ?>">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>

</head>

<body>

    <!-- === Barra lateral === -->
    <?php include '../dashboard/sidebar.php'; ?>

    <!-- === Header === -->
    <?php include '../dashboard/header.php'; ?>

    <div class="index-container">
        <h1 class="page-title">Agendar Pratos</h1>
        <main class="calendario-main">
            <div class="calendario-content-box"></div>
        </main>

    </div>


    <button style="display:none" id="criarMenuDiaModal-trigger" data-micromodal-trigger="criarMenuDiaModal">Open modal</button>


    <div class="app-modal micromodal-slide" id="criarMenuDiaModal" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">
                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">
                        Criar Menu Dia Prato
                    </h2>
                    <button class="app-modal__close closeAgendarSenhaModal" aria-label="Close modal" data-micromodal-close></button>
                </header>
                <main class="app-modal__content agendarSenha-modal-content" id="modal-1-content">


                    <div class="agendarSenha-input-div">
                        <label>Prato*</label>
                        <select id="criarMdp-prato">
                            <option value="nenhum">Nenhum</option>
                        </select>
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Data*</label>
                        <input type="date" readonly disabled id="criarMdp-data">
                    </div>

                </main>
                <footer class="modal__footer">
                    <button class="modal__btn modal__btn-primary criarMdpButton">Criar</button>
                    <button class="modal__btn" data-micromodal-close aria-label="Close this dialog window">Cancelar</button>
                </footer>
            </div>
        </div>
    </div>


    <!-- === Botão para visualizar o modal === -->
    <button style="display:none" id="dayInformationModal-trigger" data-micromodal-trigger="dayInformationModal">Open modal</button>



    <!-- === Modal para visualizar informação adicional sobre as senhas === -->
    <div class="app-modal micromodal-slide" id="dayInformationModal" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">

                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">Mais Informação</h2>
                    <button class="app-modal__close closeSenhaInformacaoButton" aria-label="Close modal" data-micromodal-close></button>
                </header>

                <main class="app-modal__content" id="modal-1-content">
                    <table class="dayInformationModal-table">
                        <tbody>
                            <tr>
                                <th>Id (mdp):</th>
                                <td id="id-pratoInfo"></td>
                            </tr>
                            <tr>
                                <th>Nome:</th>
                                <td id="nome-pratoInfo"></td>
                            </tr>
                            <tr>
                                <th>Tipo:</th>
                                <td id="tipo-pratoInfo"></td>
                            </tr>

                            <tr>
                                <th>Estado (mdp):</th>
                                <td id="estadoMDP-pratoInfo"></td>
                            </tr>
                            <tr>
                                <th>Estado (prato):</th>
                                <td id="estadoPrato-pratoInfo"></td>
                            </tr>
                            <tr>
                                <th>Vezes agendado neste mes:</th>
                                <td id="timesBought-pratoInfo"></td>
                            </tr>
                        </tbody>
                    </table>

                </main>
                <footer class="modal__footer mdft" style="gap:9px">
                    <button class="modal__btn modal__btn-red toggleMdpEstadoButton">Desativar</button>
                    <button class="modal__btn mdftbtn" onclick="qs('.closeSenhaInformacaoButton').click();" aria-label="Close this dialog window">Cancelar</button>
                </footer>

            </div>
        </div>
    </div>



    <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
    <script src="../javascript/dashboard/agendarPratos.js?v=<?php echo time(); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
    <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>
    <script src="../javascript/alertas.js"></script>


</body>

</html>