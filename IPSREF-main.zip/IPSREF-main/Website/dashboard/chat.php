<?php
session_start();
include '../conexao.php';

// Se o utilizador não estiver logado, redireciona para o login
if (!isset($_SESSION['adm_pes_id'])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IPSREF - Histórico</title>
    <link rel="stylesheet" href="../css/chat.css?v=3232<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/style.css?v=23<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">



    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>


    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>


</head>

<body>

    <!-- === Barra lateral === -->
    <?php include 'sidebar.php'; ?>

    <main class="content">
        <!-- === Header === -->
        <?php include 'header.php'; ?>

        <!-- === Secção principal === -->
        <section class="historico">


            <div class="chat-container">

                <div class="profile-area" style="display:flex; justify-content:space-between">
                    <div class="" style="display:flex; align-items:center; gap:10px;">
                        <img src="../uploads/default.png" alt="Profile Picture" class="profile-pic">
                        <span class="profile-name">Utilizador IPSREF</span>
                    </div>



                    <div class="dropdown">
                        <button class="dropbtn">
                            <img src="../logos/ellipsisIcon.svg" class="pointer" width="20">
                        </button>
                        <div class="dropdown-content" style="min-width:110px;">
                            <a class="closeChatButton">
                                Fechar Chat
                            </a>
                        </div>
                    </div>
                </div>


                <div class="message-area">

                </div>

                <div class="input-message-section">
                    <input type="text" id="messageInput" placeholder="Escreve o seu mensagem..." autocomplete="off">
                    <button id="sendButton">Enviar</button>
                </div>

            </div>
        </section>


    </main>

    <!-- === JS Global === -->
    <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
    <script src="../javascript/alertas.js?v=<?php echo time(); ?>"></script>

    <!-- === JS Histórico === -->
    <script src="../javascript/dashboard/chat.js?v=<?php echo time(); ?>"></script>
    <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>


</body>

</html>