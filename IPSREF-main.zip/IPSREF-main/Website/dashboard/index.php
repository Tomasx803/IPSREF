<?php
include '../conexao.php';
session_start();

$sql = "SELECT * FROM view_utilizadores where user_tipo COLLATE utf8mb4_unicode_ci = 'aluno'";
$result = $conn->query($sql);

$alunos = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $alunos[] = $row;
    }
}

$total_alunos = count($alunos);


$senhaThisMonthQuery = queryassoc($conn, "select count(*) as count from senha where sen_data >= DATE_FORMAT(CURRENT_DATE(), '%Y-%m-01')");
$senhaThisMonthCount = $senhaThisMonthQuery['count'];

$pratoTotalQuery = queryassoc($conn, "select count(*) as count from prato where pra_estado = 1");
$pratoTotalCount = $pratoTotalQuery['count'];


$senhasAExpirarQuery = queryassoc($conn, "select count(*) as count from senha, estado_senha where senha.sen_id = ess_sen_id and ess_est_id = 1 and ess_data <= (NOW() - INTERVAL 36 HOUR) and ess_data >= (NOW() - INTERVAL 48 HOUR) ");
$senhasAExpirarCount = $senhasAExpirarQuery['count'];

// Contar alunos com número de cartão (exemplo)
$alunos_com_cartao = 0;
foreach ($alunos as $aluno) {
    if (!empty($aluno['alu_n_cartao'])) {
        $alunos_com_cartao++;
    }
}

// Para exemplo, vamos gerar alguns dados fictícios
$alunos_ativos = $total_alunos; // Em um sistema real, isso viria de uma consulta com status
$novos_alunos_ultimo_mes = rand(2, 10); // Simulação

$meses = [
    'Jan' => 'JAN', 'Feb' => 'FEV', 'Mar' => 'MAR', 'Apr' => 'ABR',
    'May' => 'MAI', 'Jun' => 'JUN', 'Jul' => 'JUL', 'Aug' => 'AGO',
    'Sep' => 'SET', 'Oct' => 'OUT', 'Nov' => 'NOV', 'Dec' => 'DEZ'
];

$mesAtual = date('M'); // exemplo: 'Dec'
$mesPT = $meses[$mesAtual] ?? strtoupper($mesAtual); // consulta a chave do array
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IPSREF</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../css/style.css?=<?php echo time(); ?>">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.5/css/dataTables.dataTables.min.css">

    <!-- DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/2.3.5/js/dataTables.min.js"></script>
    <link rel="stylesheet" href="../css/dashboard/dashboardIndex.css?=<?php echo time(); ?>">

    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet">

</head>

<body>

    <!-- === Barra lateral === -->
    <?php include '../dashboard/sidebar.php'; ?>

    <!-- === Header === -->
    <?php include '../dashboard/header.php'; ?>

    <div class="index-container">
        <h1 class="page-title">Dashboard IPSREF</h1>

        <!-- Cartões de Estatísticas -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h3>TOTAL DE ALUNOS</h3>
                <div class="stat-value"><?php echo $total_alunos; ?></div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-id-card"></i>
                </div>
                <h3>SENHAS AGENDADAS (<?= $mesPT ?>)</h3>
                <div class="stat-value"><?php echo $senhaThisMonthCount; ?></div>

            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <h3>PRATOS ATIVOS</h3>
                <div class="stat-value"><?php echo $pratoTotalCount; ?></div>

            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-exclamation"></i>
                </div>
                <h3>SENHAS PRESTES A EXPIRAR</h3>
                <div class="stat-value"><?php echo $senhasAExpirarCount; ?></div>
            </div>
        </div>

        <!-- Container da Tabela -->
        <div class="table-container">
            <h2>Lista de Alunos</h2>

            <table id="tabelaAlunos" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Nº Estudante</th>
                        <th>Nº Cartão</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($alunos)): ?>
                        <?php foreach ($alunos as $aluno): ?>
                            <?php

                            ?>
                            <tr>
                                <td><?= $aluno['pessoa_nome'] ?> <?= $aluno['pessoa_apelido'] ?></td>
                                <td><?= $aluno['pessoa_email'] ?></td>
                                <td><?= $aluno['aluno_n_estudante'] ?></td>
                                <td><?= $aluno['aluno_n_cartao'] ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="dropbtn">
                                            <img src="../logos/ellipsisIcon.svg" class="pointer" width="20">
                                        </button>
                                        <div class="dropdown-content">
                                            <a class="senhasUserClass" data-user-id="<?php echo $aluno['pessoa_id']; ?>">Senhas</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 30px;">
                                Nenhum aluno encontrado.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>


    <button style="display:none" id="dayInformationModal-trigger" data-micromodal-trigger="dayInformationModal">Open modal</button>

    <!-- === Modal para visualizar informação adicional sobre as senhas === -->
    <div class="app-modal micromodal-slide" id="dayInformationModal" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">

                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">Senhas do utilizador: <span id="senhasUserSpan"></span></h2>
                    <button class="app-modal__close closeSenhaInformacaoButton" aria-label="Close modal" data-micromodal-close></button>
                </header>

                <main class="app-modal__content" id="modal-1-content">

                </main>

            </div>
        </div>
    </div>




    <button style="display:none" id="dayInformationModal2-trigger" data-micromodal-trigger="dayInformationModal2">Open modal</button>

    <!-- === Modal para visualizar informação adicional sobre as senhas === -->
    <div class="app-modal micromodal-slide" id="dayInformationModal2" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" style="max-width: 500px; max-height: 100vh;" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">

                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">Mais Informação</h2>
                    <button
                        class="app-modal__close closeSenhaInformacaoButton"
                        aria-label="Close modal"
                        data-micromodal-close>
                    </button>

                </header>

                <main class="app-modal__content" id="modal-1-content">
                    <table class="dayInformationModal-table">
                        <tbody>
                            <tr>
                                <th>Tipo:</th>
                                <td id="tipo-senha"></td>
                            </tr>
                            <tr>
                                <th>Date Compra:</th>
                                <td style="display:flex; align-items: center;">
                                    <span id="dataCompra-senha"></span>
                                </td>
                            </tr>
                            <tr>
                                <th>Estado:</th>
                                <td id="estado-senha"></td>
                            </tr>
                            <tr>
                                <th>Prato:</th>
                                <td style="display:flex; align-items: center;">
                                    <span id="prato-senha"></span>
                                </td>
                            </tr>
                            <tr>
                                <th>Extras:</th>
                                <td style="display:flex; align-items: center;">
                                    <span id="extras-senha"></span>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </main>

            </div>
        </div>
    </div>





    <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
    <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>
    <script src="../javascript/dashboard/dashboardIndex.js?v=<?php echo time(); ?>"></script>

</body>

</html>