<?php
session_start();
include '../conexao.php';

// Se o utilizador não estiver logado, redireciona para o login
if (!isset($_SESSION['adm_pes_id'])) {
  header("Location: login.php");
  exit();
}

$id = $_SESSION['adm_pes_id'];
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IPSREF - Histórico</title>
  <link rel="stylesheet" href="../css/historico.css?v=3232<?php echo time(); ?>">
  <link rel="stylesheet" href="../css/style.css?v=23<?php echo time(); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">



  <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>


  <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
  <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>

  <style>
    .pagination {
      display: flex;
      align-items: center;
      gap: 6px;
      font-family: sans-serif;
      justify-content: center;
    }

    .pagination .page-number {
      border: 1px solid #ccc;
      padding: 7px 10px;
      background: #fff;
      cursor: pointer;
      border-radius: 4px;
    }

    .page-arrow {
      display: flex;
      justify-content: center;
      align-items: center;
      border: 1px solid #ccc;
      background: #fff;
      cursor: pointer;
      border-radius: 4px;
      padding: 2.5px 2px;
    }

    .pagination .active {
      background: #007bff;
      color: white;
      border-color: #007bff;
    }

    .pagination button:hover {
      background: #8f8f8fff;
      border-color: #8f8f8fff;
      color: white;
    }

    .title-section-button-active {
      border: 2px solid rgb(3, 213, 3);
    }
  </style>
</head>

<body>

  <!-- === Barra lateral === -->
  <?php include 'sidebar.php'; ?>

  <main class="content">
    <!-- === Header === -->
    <?php include 'header.php'; ?>

    <!-- === Secção principal === -->
    <section class="historico">

      <div class="title-section">
        <h2>Chats de suporte</h2>

        <div class="controls">


          <div class="dropdown-wrapper">

            <button id="sort-by-button" class="title-section-button">
              <img src="../logos/eyeIcon.svg">
              Ver
              <span class="filterActive-badge filterActive-sortBy">1</span>
            </button>

            <div id="floating-window-sortBy" class="floating-window d-none">
              <div class="floating-item chatOption sortByActive" data-option="5">Chats Pendentes</div>
              <div class="floating-item chatOption" data-option="6">Chats em curso</div>
              <div class="floating-item chatOption" data-option="7">Chats Fechados</div>
            </div>

          </div>

        </div>


      </div>

      <div class="historico-container"></div>

      <div class="pagination">
        <button class="page-arrow page-arrow-previous">

          <svg viewBox="0 0 24 24" class="page-arrow-previous" fill="none" width="24" xmlns="http://www.w3.org/2000/svg" transform="rotate(180)">
            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
            <g id="SVGRepo_iconCarrier">
              <path d="M10 7L15 12L10 17" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            </g>
          </svg>

        </button>
        <div class="pagination-buttons">

        </div>
        <button class="page-arrow page-arrow-next">
          <svg viewBox="0 0 24 24" fill="none" class="page-arrow-next" width="24" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 7L15 12L10 17" stroke="#000000" stroke-width="1.5"
              stroke-linecap="round" stroke-linejoin="round"></path>
          </svg>

        </button>

      </div>

      <!-- === Botão para visualizar o modal === -->
      <button style="display:none" id="dayInformationModal-trigger" data-micromodal-trigger="dayInformationModal">Open modal</button>

      <div class="app-modal micromodal-slide" id="dayInformationModal" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
          <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">

            <header class="app-modal__header">
              <h2 class="app-modal__title" id="modal-1-title">Histórico de Estado da senha</h2>
              <button class="app-modal__close closeSenhaInformacaoButton" aria-label="Close modal" data-micromodal-close></button>
            </header>

            <main class="app-modal__content" id="modal-1-content">
              <table class="dayInformationModal-table">
                <tbody id="senha-estadoHistorico-tbody">
                  <tr>

                  </tr>
                </tbody>
              </table>
            </main>
          </div>
        </div>
      </div>

    </section>
  </main>

  <!-- === JS Global === -->
  <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
  <script src="../javascript/alertas.js?v=<?php echo time(); ?>"></script>

  <!-- === JS Histórico === -->
  <script src="../javascript/dashboard/chats.js?v=<?php echo time(); ?>"></script>
  <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>


</body>

</html>