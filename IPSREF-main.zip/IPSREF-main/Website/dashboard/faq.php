<?php
include '../conexao.php';
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IPSREF</title>

    <link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.5/css/dataTables.dataTables.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/2.3.5/js/dataTables.min.js"></script>
    <link rel="stylesheet" href="../css/dashboard/extras.css?v=<?php echo time(); ?>">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

     <style>
        .index-container {
            min-height: 100vh;
        }
        
        .table-container,
        .table-container * {
            overflow: visible !important;
        }
    </style>
</head>

<body>

    <?php include '../dashboard/sidebar.php'; ?>
    
    <?php include '../dashboard/header.php'; ?>

    <div class="index-container">
        <h1 class="page-title">Gestão de FAQs</h1>

        <div class="table-container">
            <h2>Lista de Perguntas Frequentes</h2>

            <table id="tabelaAlunos" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Título</th>
                        <th>Conteúdo</th>
                        <th style="width: 20px !important;">Ações</th>
                    </tr>
                </thead>
                <tbody id="faqTableTBody">

                </tbody>
            </table>
        </div>
    </div>
    

    <button style="display:none" id="criarFaq-trigger" data-micromodal-trigger="criarFaq">Open modal</button>

    <div class="app-modal micromodal-slide" id="criarFaq" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-criar-title">
                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-criar-title">
                        Criar FAQ
                    </h2>
                    <button class="app-modal__close closeAgendarSenhaModal" aria-label="Close modal" data-micromodal-close></button>
                </header>
                <main class="app-modal__content agendarSenha-modal-content">

                    <div class="agendarSenha-input-div">
                        <label>Título</label>
                        <input type="text" id="titulo-criarFaq">
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Conteúdo</label>
                        <textarea id="conteudo-criarFaq" rows="5" style="width: 100%; padding: 8px;"></textarea>
                    </div>

                </main>
                <footer class="modal__footer">
                    <button class="modal__btn modal__btn-primary criarFaqButton">Criar</button>
                    <button class="modal__btn" data-micromodal-close aria-label="Close this dialog window">Cancelar</button>
                </footer>
            </div>
        </div>
    </div>

    <button style="display:none" id="editarFaq-trigger" data-micromodal-trigger="editarFaq">Open modal</button>

    <div class="app-modal micromodal-slide" id="editarFaq" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-editar-title">
                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-editar-title">
                        Editar FAQ
                    </h2>
                    <button class="app-modal__close closeAgendarSenhaModal" aria-label="Close modal" data-micromodal-close></button>
                </header>
                <main class="app-modal__content agendarSenha-modal-content">

                    <div class="agendarSenha-input-div">
                        <label>Título</label>
                        <input type="text" id="titulo-editarFaq">
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Conteúdo</label>
                        <textarea id="conteudo-editarFaq" rows="5" style="width: 100%; padding: 8px;"></textarea>
                    </div>

                </main>
                <footer class="modal__footer">
                    <button class="modal__btn modal__btn-primary editarFaqButton">Editar</button>
                    <button class="modal__btn" data-micromodal-close aria-label="Close this dialog window">Cancelar</button>
                </footer>
            </div>
        </div>
    </div>

    <button style="display:none" id="verFaq-trigger" data-micromodal-trigger="verFaq">Open modal</button>

    <div class="app-modal micromodal-slide" id="verFaq" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-ver-title">
                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-ver-title">
                        Detalhes da FAQ
                    </h2>
                    <button class="app-modal__close closeAgendarSenhaModal" aria-label="Close modal" data-micromodal-close></button>
                </header>
                <main class="app-modal__content agendarSenha-modal-content">

                    <div class="agendarSenha-input-div">
                        <label>Título</label>
                        <p id="titulo-verFaq" style="margin: 10px 0; padding: 8px; background: #f5f5f5; border-radius: 4px;"></p>
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Conteúdo</label>
                        <p id="conteudo-verFaq" style="margin: 10px 0; padding: 8px; background: #f5f5f5; border-radius: 4px; white-space: pre-wrap;"></p>
                    </div>

                </main>
                <footer class="modal__footer">
                    <button class="modal__btn" data-micromodal-close aria-label="Close this dialog window">Fechar</button>
                </footer>
            </div>
        </div>
    </div>

    <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
    <script src="../javascript/dashboard/faq.js?v=<?php echo time(); ?>"></script>
    <script src="../javascript/alertas.js"></script>
    <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>

</body>

</html>