<?php
include '../conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $pass = $_POST['pass'];

    $sql = "SELECT p.pes_id, p.pes_nome, a.adm_pes_id, a.adm_id FROM pessoa p LEFT JOIN adm a ON p.pes_id = a.adm_pes_id WHERE p.pes_email = '$email' AND p.pes_pass = '$pass'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        session_destroy();
        session_start();
        $_SESSION = [];
        $_SESSION['adm_pes_id'] = $user['adm_pes_id'];
        $_SESSION['nome'] = $user['pes_nome'];
        header("Location: index.php");
        exit();
    } else {    
        $erro = "Email ou palavra-passe incorretos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IPSREF - Senhas Online</title>
    <link rel="stylesheet" href="../css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

</head>
<body>
<div class="container">
    <header>
        <img src="../logos/logoipsref.jpg" alt="Logo IPSREF" class="logo">
    </header>

    <main class="login-section">
        <div class="login-box">
            <h2> <span style="color: #0077b6;">IPSREF</span> Dashboard Admin
        </h2>

            <?php if (!empty($erro)): ?>
                <p style="color:red;"><?= $erro ?></p>
            <?php endif; ?>

            <form method="POST">
                <input type="text" name="email" placeholder="Email" class="input-field" required>
                <input type="password" name="pass" placeholder="Palavra-passe" class="input-field" required>
                <button type="submit" class="btn">Entrar</button>
            </form>
        </div>
    </main>
</div>
</body>
</html>
