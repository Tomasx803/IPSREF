<?php
include '../conexao.php';
session_start();

$sql = "SELECT prato.*, estados_prato.est_pra_descricao FROM prato, estados_prato where prato.pra_estado = estados_prato.est_pra_id";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IPSREF</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.5/css/dataTables.dataTables.min.css">

    <!-- DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/2.3.5/js/dataTables.min.js"></script>
    <link rel="stylesheet" href="../css/dashboard/pratos.css?v=<?php echo time(); ?>">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>

    <style>
        .index-container {
            min-height: 100vh;
        }
    </style>
</head>

<body>

    <!-- === Barra lateral === -->
    <?php include '../dashboard/sidebar.php'; ?>

    <!-- === Header === -->
    <?php include '../dashboard/header.php'; ?>

    <div class="index-container">
        <h1 class="page-title">Gestão de Pratos</h1>


        <!-- Container da Tabela -->
        <div class="table-container">
            <h2>Lista de pratos </h2>

            <table id="tabelaAlunos" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th class="">ID</th>
                        <th>Nome</th>
                        <th>Tipo</th>
                        <th>Estado Atual</th>
                        <th style="width: 20px !important;">Ações</th>
                    </tr>
                </thead>
                <tbody id="pratoTableTBody">

                </tbody>
            </table>
        </div>
    </div>


    <button style="display:none" id="modal-1-trigger" data-micromodal-trigger="modal-1">Open modal</button>

    <div class="app-modal micromodal-slide" id="modal-1" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">
                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">
                        Editar Prato
                    </h2>
                    <button class="app-modal__close closeAgendarSenhaModal" aria-label="Close modal" data-micromodal-close></button>
                </header>
                <main class="app-modal__content agendarSenha-modal-content" id="modal-1-content">

                    <div class="agendarSenha-input-div">
                        <label>Nome</label>
                        <input type="text" id="nome-editarPrato">
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Tipo</label>
                        <select id="tipo-editarPrato">
                            <option value="Carne">Carne</option>
                            <option value="Vegetariano">Vegetariano</option>
                            <option value="Peixe">Peixe</option>
                        </select>
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Estado</label>
                        <select id="estado-editarPrato">
                            <option value="1">Ativo</option>
                            <option value="2">Desativado</option>
                        </select>
                    </div>

                </main>
                <footer class="modal__footer">
                    <button class="modal__btn modal__btn-primary editarPratoButton">Editar</button>
                    <button class="modal__btn" data-micromodal-close aria-label="Close this dialog window">Cancelar</button>
                </footer>
            </div>
        </div>
    </div>


        <button style="display:none" id="criarPrato-trigger" data-micromodal-trigger="criarPrato">Open modal</button>

    <div class="app-modal micromodal-slide" id="criarPrato" aria-hidden="true">
        <div class="app-modal__overlay" tabindex="-1" data-micromodal-close>
            <div class="app-modal__container" role="dialog" aria-modal="true" aria-labelledby="modal-1-title">
                <header class="app-modal__header">
                    <h2 class="app-modal__title" id="modal-1-title">
                        Criar Prato
                    </h2>
                    <button class="app-modal__close closeAgendarSenhaModal" aria-label="Close modal" data-micromodal-close></button>
                </header>
                <main class="app-modal__content agendarSenha-modal-content" id="modal-1-content">

                    <div class="agendarSenha-input-div">
                        <label>Nome</label>
                        <input type="text" id="nome-criarPrato">
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Tipo</label>
                        <select id="tipo-criarPrato">
                            <option value="Carne">Carne</option>
                            <option value="Vegetariano">Vegetariano</option>
                            <option value="Peixe">Peixe</option>
                        </select>
                    </div>

                    <div class="agendarSenha-input-div">
                        <label>Estado</label>
                        <select id="estado-criarPrato">
                            <option value="1">Ativo</option>
                            <option value="2">Desativado</option>
                        </select>
                    </div>

                </main>
                <footer class="modal__footer">
                    <button class="modal__btn modal__btn-primary criarPratoButton">Criar</button>
                    <button class="modal__btn" data-micromodal-close aria-label="Close this dialog window">Cancelar</button>
                </footer>
            </div>
        </div>
    </div>




                            
    <script src="../javascript/global.js?v=<?php echo time(); ?>"></script>
    <script src="../javascript/dashboard/pratos.js?v=<?php echo time(); ?>"></script>
    <script src="../javascript/alertas.js"></script>
    <script src="https://unpkg.com/micromodal/dist/micromodal.min.js"></script>

</body>

</html>