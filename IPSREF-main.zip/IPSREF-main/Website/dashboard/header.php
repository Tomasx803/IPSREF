<?php
if (!isset($_SESSION['adm_pes_id'])) {
    header("Location: login.php");
    exit();
}

?>

<header class="topbar">
    <div class="icons">

        <button id="menu-btn" class="menu-btn" aria-label="Abrir menu">
            <i class="fa-solid fa-bars"></i>
        </button>

        <a style="text-decoration: none; color: inherit;">
            <span class="utilizador"><i class="fa-solid fa-user"></i></span>
        </a>
        <?= htmlspecialchars($_SESSION['nome']) ?></span>
        
        <a href="../dashboard/logout.php" class="logout">Sair</a>
    </div>
</header>
