<?php
// Obtem o nome do ficheiro atual
$activePage = basename($_SERVER['PHP_SELF']);

if (!isset($_SESSION['adm_pes_id'])) {
    header("Location: login.php");
    exit();
}


?>

<aside class="sidebar">
    <a href="index.php">
        <img src="../logos/logoipsref.jpg" alt="Logo IPSREF" class="logo">
    </a>
    <nav>
        <ul>
            <li><a href="../dashboard/index.php" class="<?= $activePage == 'index.php' ? 'active' : '' ?>">Utilizadores</a></li>

            <li><a href="../dashboard/agendarPratos.php" class="<?= $activePage == 'agendarPratos.php' ? 'active' : '' ?>">Agendar Pratos</a></li>

            <li><a href="../dashboard/pratos.php" class="<?= $activePage == 'pratos.php' ? 'active' : '' ?>">Pratos</a></li>

            <li><a href="../dashboard/extras.php" class="<?= $activePage == 'extras.php' ? 'active' : '' ?>">Extras</a></li>

            <li><a href="../dashboard/chats.php" class="<?= $activePage == 'chats.php' || $activePage == "chat.php" ? 'active' : '' ?>">Suporte</a></li>

            <li><a href="../dashboard/faq.php" class="<?= $activePage == 'faq.php' ? 'active' : '' ?>">FAQs</a></li>

        </ul>
    </nav>
</aside>