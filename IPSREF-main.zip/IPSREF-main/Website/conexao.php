<?php
$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = "root";
$pass = "";
$db = "ipsref"; // igual ao nome que criaste no phpMyAdmin

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Erro na ligação: " . $conn->connect_error);
}


/* UTIL FUNCTIONS */

function query ($conn, $query) {
    return mysqli_query($conn, $query);
}

function queryassoc ($conn, $query) {
    $v = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($v);
}

function assoc($mysqliQuery) {
    return mysqli_fetch_assoc($mysqliQuery);
}

function numrows($mysqliQuery) {
    return mysqli_num_rows($mysqliQuery);
}

/* END UTIL FUNCTIONS */


?>