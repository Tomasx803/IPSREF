CREATE DATABASE IF NOT EXISTS ipsref;
USE ipsref;

-- =========================
-- PREFIXOS
-- =========================
-- pes = pessoa
-- cor = codigo_recuperacao
-- alu = aluno
-- adm = administrador
-- mnd = menu_dia
-- pra = prato
-- mdp = menu_dia_prato
-- ext = extras
-- est = estado
-- tps = tipo_senha
-- sen = senha
-- sex = senha_extra
-- ess = estado_senha
-- not = notificacao
-- csp = chat_suporte
-- msg = mensagem
-- cse = chat_suporte_estado
-- faq = faq

-- =========================
-- TABELAS
-- =========================

CREATE TABLE pessoa (
    pes_id INT AUTO_INCREMENT NOT NULL,
    pes_nome VARCHAR(255) NOT NULL,
    pes_apelido VARCHAR(255) NOT NULL,
    pes_email VARCHAR(255) NOT NULL UNIQUE,
    pes_pass VARCHAR(255) NOT NULL,
    pes_foto VARCHAR(255),
    pes_notif_senhas BOOLEAN DEFAULT TRUE NOT NULL,
    pes_notif_reembolsos BOOLEAN DEFAULT TRUE NOT NULL,
    PRIMARY KEY (pes_id)
);

CREATE TABLE codigos_recuperacao (
    cor_id INT AUTO_INCREMENT NOT NULL,
    cor_pes_id INT NOT NULL,
    cor_codigo VARCHAR(6) NOT NULL,
    cor_data_expiracao DATETIME NOT NULL,
    PRIMARY KEY (cor_id)
);

CREATE TABLE aluno (
    alu_id INT AUTO_INCREMENT NOT NULL,
    alu_pes_id INT NOT NULL,
    alu_n_cartao VARCHAR(255) NOT NULL UNIQUE,
    alu_n_estudante VARCHAR(255) NOT NULL UNIQUE,
    PRIMARY KEY (alu_id)
);

CREATE TABLE adm (
    adm_id INT AUTO_INCREMENT NOT NULL,
    adm_pes_id INT NOT NULL,
    PRIMARY KEY (adm_id)
);

CREATE TABLE menu_dia (
    mnd_id INT AUTO_INCREMENT NOT NULL,
    mnd_data DATE NOT NULL,
    PRIMARY KEY (mnd_id)
);

CREATE TABLE prato (
    pra_id INT AUTO_INCREMENT NOT NULL,
    pra_nome VARCHAR(255) NOT NULL,
    pra_tipo VARCHAR(255) NOT NULL,
    pra_estado INT NOT NULL DEFAULT 1,
    PRIMARY KEY (pra_id)
);

CREATE TABLE menu_dia_prato (
    mdp_id INT AUTO_INCREMENT NOT NULL,
    mdp_mnd_id INT NOT NULL,
    mdp_pra_id INT NOT NULL,
    mdp_estado INT NOT NULL DEFAULT 1,
    PRIMARY KEY (mdp_id)
);

CREATE TABLE extras (
    ext_id INT AUTO_INCREMENT NOT NULL,
    ext_nome VARCHAR(255) NOT NULL,
    ext_estado INT NOT NULL DEFAULT 1,
    PRIMARY KEY (ext_id)
);

CREATE TABLE estado (
    est_id INT AUTO_INCREMENT NOT NULL,
    est_descricao VARCHAR(255) NOT NULL,
    PRIMARY KEY (est_id)
);

CREATE TABLE estados_prato (
    est_pra_id INT AUTO_INCREMENT NOT NULL,
    est_pra_descricao VARCHAR(255) NOT NULL,
    PRIMARY KEY (est_pra_id)
);

CREATE TABLE tipo_senha (
    tps_id INT AUTO_INCREMENT NOT NULL,
    tps_descricao VARCHAR(255) NOT NULL,
    PRIMARY KEY (tps_id)
);

CREATE TABLE senha (
    sen_id INT AUTO_INCREMENT NOT NULL,
    sen_mdp_id INT,
    sen_tps_id INT NOT NULL,
    sen_pes_id INT NOT NULL,
    sen_est_atual_id INT NOT NULL,
    sen_data DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    sen_data_expiracao DATETIME AS (DATE_ADD(sen_data, INTERVAL 1 YEAR)) STORED, -- Duração de 1 ano
    sen_reembolsada BOOLEAN DEFAULT FALSE NOT NULL, -- Indica se a senha foi reembolsada
    PRIMARY KEY (sen_id)
);

CREATE TABLE senha_extra (
    sex_id INT AUTO_INCREMENT NOT NULL,
    sex_sen_id INT NOT NULL,
    sex_ext_id INT NOT NULL,
    PRIMARY KEY (sex_id)
);

CREATE TABLE estado_senha (
    ess_id INT AUTO_INCREMENT NOT NULL,
    ess_est_id INT NOT NULL,
    ess_sen_id INT NOT NULL,
    ess_data DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (ess_id)
);

CREATE TABLE notificacao (
    not_id INT AUTO_INCREMENT NOT NULL,
    not_titulo VARCHAR(255) NOT NULL,
    not_mensagem TEXT NOT NULL,
    not_pes_id INT NOT NULL,
    not_data DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    not_lida BOOLEAN DEFAULT FALSE NOT NULL,
    PRIMARY KEY (not_id)
);

CREATE TABLE chat_suporte (
    csp_id INT AUTO_INCREMENT NOT NULL,
    csp_pes_id INT NOT NULL,
    csp_est_atual_id INT NOT NULL,
    csp_assunto VARCHAR(255) NOT NULL,
    PRIMARY KEY (csp_id)
);

CREATE TABLE mensagem (
    msg_id INT AUTO_INCREMENT NOT NULL,
    msg_csp_id INT NOT NULL,
    msg_pes_id INT NOT NULL,
    msg_texto VARCHAR(255) NOT NULL,
    msg_data DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (msg_id)
);

CREATE TABLE chat_suporte_estado (
    cse_id INT AUTO_INCREMENT NOT NULL,
    cse_est_id INT NOT NULL,
    cse_csp_id INT NOT NULL,
    cse_data DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (cse_id)
);

CREATE TABLE faq (
    faq_id INT AUTO_INCREMENT NOT NULL,
    faq_titulo VARCHAR(255) NOT NULL,
    faq_conteudo TEXT NOT NULL,
    PRIMARY KEY (faq_id)
);

-- =========================
-- FOREIGN KEYS
-- =========================

ALTER TABLE codigos_recuperacao
ADD CONSTRAINT cor_fk_pessoa
FOREIGN KEY (cor_pes_id) REFERENCES pessoa(pes_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE aluno
ADD CONSTRAINT aluno_fk_pessoa
FOREIGN KEY (alu_pes_id) REFERENCES pessoa(pes_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE adm
ADD CONSTRAINT adm_fk_pessoa
FOREIGN KEY (adm_pes_id) REFERENCES pessoa(pes_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE prato
ADD CONSTRAINT pra_fk_estado
FOREIGN KEY (pra_estado) REFERENCES estados_prato(est_pra_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE extras
ADD CONSTRAINT ext_fk_estado
FOREIGN KEY (ext_estado) REFERENCES estados_prato(est_pra_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE menu_dia_prato
ADD CONSTRAINT mdp_fk_menu_dia
FOREIGN KEY (mdp_mnd_id) REFERENCES menu_dia(mnd_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE menu_dia_prato
ADD CONSTRAINT mdp_fk_prato
FOREIGN KEY (mdp_pra_id) REFERENCES prato(pra_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE menu_dia_prato
ADD CONSTRAINT mdp_fk_estado
FOREIGN KEY (mdp_estado) REFERENCES estados_prato(est_pra_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE senha
ADD CONSTRAINT senha_fk_menu_dia_prato
FOREIGN KEY (sen_mdp_id) REFERENCES menu_dia_prato(mdp_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE senha
ADD CONSTRAINT senha_fk_tipo_senha
FOREIGN KEY (sen_tps_id) REFERENCES tipo_senha(tps_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE senha
ADD CONSTRAINT senha_fk_pessoa
FOREIGN KEY (sen_pes_id) REFERENCES pessoa(pes_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE senha
ADD CONSTRAINT senha_fk_estado_atual
FOREIGN KEY (sen_est_atual_id) REFERENCES estado(est_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE senha_extra
ADD CONSTRAINT senha_extra_fk_senha
FOREIGN KEY (sex_sen_id) REFERENCES senha(sen_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE senha_extra
ADD CONSTRAINT senha_extra_fk_extra
FOREIGN KEY (sex_ext_id) REFERENCES extras(ext_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE estado_senha
ADD CONSTRAINT estado_senha_fk_estado
FOREIGN KEY (ess_est_id) REFERENCES estado(est_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE estado_senha
ADD CONSTRAINT estado_senha_fk_senha
FOREIGN KEY (ess_sen_id) REFERENCES senha(sen_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE notificacao
ADD CONSTRAINT notificacao_fk_pessoa
FOREIGN KEY (not_pes_id) REFERENCES pessoa(pes_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE chat_suporte
ADD CONSTRAINT chat_suporte_fk_pessoa
FOREIGN KEY (csp_pes_id) REFERENCES pessoa(pes_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE chat_suporte
ADD CONSTRAINT chat_suporte_fk_estado_atual
FOREIGN KEY (csp_est_atual_id) REFERENCES estado(est_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE mensagem
ADD CONSTRAINT mensagem_fk_chat_suporte
FOREIGN KEY (msg_csp_id) REFERENCES chat_suporte(csp_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE mensagem
ADD CONSTRAINT mensagem_fk_pessoa
FOREIGN KEY (msg_pes_id) REFERENCES pessoa(pes_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE chat_suporte_estado
ADD CONSTRAINT chat_suporte_estado_fk_estado
FOREIGN KEY (cse_est_id) REFERENCES estado(est_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE chat_suporte_estado
ADD CONSTRAINT chat_suporte_estado_fk_chat_suporte
FOREIGN KEY (cse_csp_id) REFERENCES chat_suporte(csp_id)
ON DELETE NO ACTION ON UPDATE NO ACTION;

-- =========================
-- VIEWS
-- =========================

CREATE OR REPLACE VIEW view_senhas_dia_aluno AS
SELECT
    sen.sen_id AS senha_id,
    sen.sen_data AS senha_data,
    sen.sen_data_expiracao AS senha_data_expiracao,
    DATEDIFF(sen.sen_data_expiracao, NOW()) AS dias_ate_expirar,
    sen.sen_reembolsada AS senha_reembolsada,
    tps.tps_descricao AS senha_tipo,
    sen.sen_pes_id AS pessoa_id,
    pes.pes_nome AS pessoa_nome,
    pes.pes_apelido AS pessoa_apelido,
    pes.pes_email AS pessoa_email,
    pes.pes_foto AS pessoa_foto,
    alu.alu_n_cartao AS aluno_n_cartao,
    alu.alu_n_estudante AS aluno_n_estudante,
    COALESCE(pra.pra_nome, 'Não escolhido') AS prato_nome,
    COALESCE(pra.pra_tipo, 'Não escolhido') AS prato_tipo,
    est.est_descricao AS estado_atual,
    COALESCE(GROUP_CONCAT(ext.ext_nome SEPARATOR ', '), '') AS extras
FROM senha sen
JOIN pessoa pes ON sen.sen_pes_id = pes.pes_id
JOIN aluno alu ON alu.alu_pes_id = pes.pes_id
JOIN tipo_senha tps ON sen.sen_tps_id = tps.tps_id
LEFT JOIN menu_dia_prato mdp ON sen.sen_mdp_id = mdp.mdp_id
LEFT JOIN menu_dia mnd ON mdp.mdp_mnd_id = mnd.mnd_id
LEFT JOIN prato pra ON mdp.mdp_pra_id = pra.pra_id
JOIN estado est ON sen.sen_est_atual_id = est.est_id
LEFT JOIN senha_extra sex ON sex.sex_sen_id = sen.sen_id
LEFT JOIN extras ext ON sex.sex_ext_id = ext.ext_id
GROUP BY
    sen.sen_id,
    sen.sen_data,
    sen.sen_data_expiracao,
    sen.sen_reembolsada,
    tps.tps_descricao,
    sen.sen_pes_id,
    pes.pes_nome,
    pes.pes_apelido,
    pes.pes_email,
    pes.pes_foto,
    alu.alu_n_cartao,
    alu.alu_n_estudante,
    pra.pra_nome,
    pra.pra_tipo,
    est.est_descricao;

CREATE OR REPLACE VIEW view_historico_senhas_aluno AS
SELECT
    pes.pes_id AS pessoa_id,
    pes.pes_nome AS aluno_nome,
    pes.pes_apelido AS aluno_apelido,
    alu.alu_n_cartao AS numero_cartao,
    alu.alu_n_estudante AS numero_estudante,
    latest_ess.ess_id AS estado_senha_id,
    latest_ess.ess_sen_id AS senha_id,
    latest_ess.ess_data AS estado_data,
    est.est_descricao AS estado_descricao,
    tps.tps_descricao AS tipo_senha,
    COALESCE(pra.pra_id, NULL) AS prato_id,
    COALESCE(pra.pra_nome, 'Não escolhido') AS prato_nome,
    COALESCE(pra.pra_tipo, 'Não escolhido') AS prato_tipo,
    sen.sen_data AS senha_data,
    sen.sen_data_expiracao AS senha_data_expiracao,
    sen.sen_reembolsada AS senha_reembolsada,
    DATEDIFF(sen.sen_data_expiracao, NOW()) AS dias_ate_expirar,
    COALESCE(GROUP_CONCAT(ext.ext_nome SEPARATOR ', '), '') AS extras
FROM ipsref.senha sen
JOIN ipsref.tipo_senha tps ON sen.sen_tps_id = tps.tps_id
JOIN ipsref.pessoa pes ON sen.sen_pes_id = pes.pes_id
JOIN ipsref.aluno alu ON pes.pes_id = alu.alu_pes_id
LEFT JOIN ipsref.menu_dia_prato mdp ON sen.sen_mdp_id = mdp.mdp_id
LEFT JOIN ipsref.prato pra ON mdp.mdp_pra_id = pra.pra_id
LEFT JOIN ipsref.senha_extra sex ON sex.sex_sen_id = sen.sen_id
LEFT JOIN ipsref.extras ext ON sex.sex_ext_id = ext.ext_id
JOIN (SELECT ess_sen_id, MAX(ess_id) AS max_ess_id FROM ipsref.estado_senha GROUP BY ess_sen_id ) latest_ess_data ON latest_ess_data.ess_sen_id = sen.sen_id
JOIN ipsref.estado_senha latest_ess ON latest_ess.ess_sen_id = latest_ess_data.ess_sen_id AND latest_ess.ess_id = latest_ess_data.max_ess_id
LEFT JOIN ipsref.estado est ON latest_ess.ess_est_id = est.est_id
GROUP BY
    alu.alu_id,
    pes.pes_nome,
    pes.pes_apelido,
    alu.alu_n_cartao,
    alu.alu_n_estudante,
    latest_ess.ess_id,
    latest_ess.ess_sen_id,
    latest_ess.ess_data,
    est.est_descricao,
    tps.tps_descricao,
    pra.pra_id,
    pra.pra_nome,
    pra.pra_tipo,
    sen.sen_data,
    sen.sen_data_expiracao,
    sen.sen_reembolsada;

CREATE OR REPLACE VIEW view_utilizadores AS
SELECT 
    alu.alu_pes_id AS pessoa_id,
    pes.pes_nome AS pessoa_nome,
    pes.pes_apelido AS pessoa_apelido,
    pes.pes_email AS pessoa_email,
    pes.pes_pass AS pessoa_pass,
    pes.pes_foto AS pessoa_foto,
    pes.pes_notif_senhas,
    pes.pes_notif_reembolsos,
    alu.alu_n_estudante AS aluno_n_estudante,
    alu.alu_n_cartao AS aluno_n_cartao,
    'aluno' AS user_tipo
FROM aluno alu
JOIN pessoa pes ON alu.alu_pes_id = pes.pes_id

UNION ALL

SELECT 
    adm.adm_pes_id AS pessoa_id,
    pes.pes_nome AS pessoa_nome,
    pes.pes_apelido AS pessoa_apelido,
    pes.pes_email AS pessoa_email,
    pes.pes_pass AS pessoa_pass,
    pes.pes_foto AS pessoa_foto,
    pes.pes_notif_senhas,
    pes.pes_notif_reembolsos,
    NULL AS aluno_n_estudante,
    NULL AS aluno_n_cartao,
    'adm' AS user_tipo
FROM adm
JOIN pessoa pes ON adm.adm_pes_id = pes.pes_id;

-- =========================
-- EVENTOS
-- =========================

DELIMITER $$

CREATE EVENT IF NOT EXISTS evento_notificar_reembolso_terminar
-- ON SCHEDULE EVERY 1 MINUTE -- PARA TESTE
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    INSERT INTO notificacao (not_titulo, not_mensagem, not_pes_id)
    SELECT
        'Período de reembolso a terminar' AS not_titulo,
        CONCAT('Tem ', COUNT(sen.sen_id), ' senha(s) cujo período de reembolso termina em breve.') AS not_mensagem,
        pes.pes_id
    FROM senha sen
    JOIN pessoa pes ON sen.sen_pes_id = pes.pes_id
    JOIN aluno alu ON alu.alu_pes_id = pes.pes_id
    JOIN estado est ON sen.sen_est_atual_id = est.est_id
    WHERE
        sen.sen_reembolsada = FALSE
        AND est.est_descricao = 'A'
        AND pes.pes_notif_reembolsos = TRUE
        AND CURDATE() = DATE_ADD(DATE(sen.sen_data), INTERVAL 2 DAY)
        AND NOT EXISTS (
            SELECT 1
            FROM notificacao n
            WHERE n.not_pes_id = pes.pes_id
            AND n.not_titulo = 'Período de reembolso a terminar'
            AND DATE(n.not_data) = CURDATE()
        )
    GROUP BY pes.pes_id;
END$$

DELIMITER ;

DELIMITER $$

CREATE EVENT IF NOT EXISTS evento_notificar_senha_expirar
-- ON SCHEDULE EVERY 1 MINUTE -- PARA TESTE
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    INSERT INTO notificacao (not_titulo, not_mensagem, not_pes_id)
    SELECT
        'Senha a expirar em breve' AS not_titulo,
        CONCAT('Tem ', COUNT(sen.sen_id), ' senha(s) que expira(m) em breve. Use-as antes de expirarem.') AS not_mensagem,
        pes.pes_id
    FROM senha sen
    JOIN pessoa pes ON sen.sen_pes_id = pes.pes_id
    JOIN aluno alu ON alu.alu_pes_id = pes.pes_id
    JOIN estado est ON sen.sen_est_atual_id = est.est_id
    WHERE
        sen.sen_reembolsada = FALSE
        AND est.est_descricao = 'PA'
        AND pes.pes_notif_senhas = TRUE
        AND DATEDIFF(sen.sen_data_expiracao, CURDATE()) <= 30
        AND DATEDIFF(sen.sen_data_expiracao, CURDATE()) > 0
        AND NOT EXISTS (
            SELECT 1
            FROM notificacao n
            WHERE n.not_pes_id = pes.pes_id
            AND n.not_titulo = 'Senha a expirar em breve'
            AND DATE(n.not_data) = CURDATE()
        )
    GROUP BY pes.pes_id;
END$$

DELIMITER ;

DELIMITER $$

CREATE EVENT IF NOT EXISTS evento_marcar_senhas_por_agendar
-- ON SCHEDULE EVERY 1 MINUTE -- PARA TESTE
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    UPDATE senha sen
    JOIN estado est ON sen.sen_est_atual_id = est.est_id
    SET sen.sen_est_atual_id = (SELECT est_id FROM estado WHERE est_descricao = 'PA' LIMIT 1)
    WHERE 
        est.est_descricao = 'A'
        AND CURDATE() > DATE_ADD(DATE(sen.sen_data), INTERVAL 2 DAY);
    
    INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data)
    SELECT 
        (SELECT est_id FROM estado WHERE est_descricao = 'PA' LIMIT 1),
        sen.sen_id,
        NOW()
    FROM senha sen
    JOIN estado est ON sen.sen_est_atual_id = est.est_id
    WHERE 
        est.est_descricao = 'PA'
        AND sen.sen_reembolsada = FALSE
        AND NOT EXISTS (
            SELECT 1 
            FROM estado_senha ess 
            WHERE ess.ess_sen_id = sen.sen_id 
            AND ess.ess_est_id = (SELECT est_id FROM estado WHERE est_descricao = 'PA' LIMIT 1)
            AND DATE(ess.ess_data) = CURDATE()
        );
END$$

DELIMITER ;