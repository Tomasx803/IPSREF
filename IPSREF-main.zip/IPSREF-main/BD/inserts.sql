-- =========================
-- UTILIZADORES
-- =========================

-- Admin
INSERT INTO pessoa (pes_nome, pes_apelido, pes_email, pes_pass, pes_foto)
VALUES ('Admin', 'IPSREF', 'admin@gmail.com', 'admin', 'uploads/default.png');

INSERT INTO adm (adm_pes_id)
VALUES (LAST_INSERT_ID());

-- Aluno 1: João Alves
INSERT INTO pessoa (pes_nome, pes_apelido, pes_email, pes_pass, pes_foto)
VALUES ('João', 'Alves', 'joaoalves@gmail.com', '123', 'uploads/default.png');

INSERT INTO aluno (alu_pes_id, alu_n_cartao, alu_n_estudante)
VALUES (LAST_INSERT_ID(), '92674206', '2025141152');

-- Aluno 2: Miguel Costa
INSERT INTO pessoa (pes_nome, pes_apelido, pes_email, pes_pass, pes_foto)
VALUES ('Miguel', 'Costa', 'miguelcosta@gmail.com', '123', 'uploads/default.png');

INSERT INTO aluno (alu_pes_id, alu_n_cartao, alu_n_estudante)
VALUES (LAST_INSERT_ID(), 'E3F53106', '2025659087');

-- Aluno 3: Ana Silva
INSERT INTO pessoa (pes_nome, pes_apelido, pes_email, pes_pass, pes_foto)
VALUES ('Ana', 'Silva', 'anasilva@gmail.com', '123', 'uploads/default.png');

INSERT INTO aluno (alu_pes_id, alu_n_cartao, alu_n_estudante)
VALUES (LAST_INSERT_ID(), 'A1B2C3D4', '2025789456');

-- Aluno 4: Pedro Santos
INSERT INTO pessoa (pes_nome, pes_apelido, pes_email, pes_pass, pes_foto)
VALUES ('Pedro', 'Santos', 'pedrosantos@gmail.com', '123', 'uploads/default.png');

INSERT INTO aluno (alu_pes_id, alu_n_cartao, alu_n_estudante)
VALUES (LAST_INSERT_ID(), 'F5G6H7I8', '2025321654');

-- Aluno 5: Mariana Ferreira
INSERT INTO pessoa (pes_nome, pes_apelido, pes_email, pes_pass, pes_foto)
VALUES ('Mariana', 'Ferreira', 'marianaferreira@gmail.com', '123', 'uploads/default.png');

INSERT INTO aluno (alu_pes_id, alu_n_cartao, alu_n_estudante)
VALUES (LAST_INSERT_ID(), 'J9K0L1M2', '2025852963');

-- =========================
-- CONFIGURAÇÃO REFEIÇÕES
-- =========================

-- Tipos de senha
INSERT INTO tipo_senha (tps_descricao) VALUES
('Almoço'),
('Jantar');

-- Estados do prato
INSERT INTO estados_prato (est_pra_descricao) VALUES
('Ativo'), 
('Desativado');

-- Pratos
INSERT INTO prato (pra_nome, pra_tipo, pra_estado) VALUES
('Frango Assado com Batatas', 'Carne', 1),
('Bacalhau à Brás', 'Peixe', 1),
('Lasanha vegetariana', 'Vegetariano', 1),
('Bife de Porco com Arroz', 'Carne', 1),
('Pescada Cozida', 'Peixe', 1),
('Omelete de legumes', 'Vegetariano', 1),
('Empadão de Carne', 'Carne', 1),
('Filetes de Pescada', 'Peixe', 1);

-- Extras
INSERT INTO extras (ext_nome) VALUES
('Pão'),
('Sopa');

-- Estados
INSERT INTO estado (est_descricao) VALUES
('A'),   -- senha agendada
('U'),   -- senha utilizada
('PA'),  -- senha por agendar
('R'),   -- senha reembolsada
('C'),   -- chat criado
('CEC'), -- chat em curso
('F');   -- chat fechado


-- =========================
-- MENUS DEZEMBRO 2025
-- =========================

-- Semana 1: 01-05 Dezembro (seg a sex)
INSERT INTO menu_dia (mnd_data) VALUES 
('2025-12-01'), ('2025-12-02'), ('2025-12-03'), ('2025-12-04'), ('2025-12-05');

-- Menu 01/12 - Segunda
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (1, 1), (1, 2), (1, 3);
-- Menu 02/12 - Terça
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (2, 4), (2, 5), (2, 6);
-- Menu 03/12 - Quarta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (3, 7), (3, 8), (3, 3);
-- Menu 04/12 - Quinta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (4, 1), (4, 2), (4, 6);
-- Menu 05/12 - Sexta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (5, 4), (5, 5), (5, 3);

-- Semana 2: 09-12 Dezembro (ter a sex)
INSERT INTO menu_dia (mnd_data) VALUES 
('2025-12-09'), ('2025-12-10'), ('2025-12-11'), ('2025-12-12');

-- Menu 09/12 - Terça
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (6, 7), (6, 8), (6, 6);
-- Menu 10/12 - Quarta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (7, 1), (7, 5), (7, 3);
-- Menu 11/12 - Quinta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (8, 4), (8, 2), (8, 6);
-- Menu 12/12 - Sexta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (9, 7), (9, 8), (9, 3);

-- Semana 3: 15-19 Dezembro (seg a sex)
INSERT INTO menu_dia (mnd_data) VALUES 
('2025-12-15'), ('2025-12-16'), ('2025-12-17'), ('2025-12-18'), ('2025-12-19');

-- Menu 15/12 - Segunda
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (10, 1), (10, 2), (10, 3);
-- Menu 16/12 - Terça
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (11, 4), (11, 5), (11, 6);
-- Menu 17/12 - Quarta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (12, 7), (12, 8), (12, 3);
-- Menu 18/12 - Quinta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (13, 1), (13, 2), (13, 6);
-- Menu 19/12 - Sexta
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES (14, 4), (14, 5), (14, 3);

-- =========================
-- HISTÓRICO NOVEMBRO 2025
-- =========================

-- Dias de Novembro
INSERT INTO menu_dia (mnd_data) VALUES 
('2025-11-03'), ('2025-11-04'), ('2025-11-05'), ('2025-11-06'), ('2025-11-07'),
('2025-11-10'), ('2025-11-11'), ('2025-11-12'), ('2025-11-13'), ('2025-11-14'),
('2025-11-17'), ('2025-11-18'), ('2025-11-19'), ('2025-11-20'), ('2025-11-21'),
('2025-11-24'), ('2025-11-25'), ('2025-11-26'), ('2025-11-27'), ('2025-11-28');

-- Menus Novembro
INSERT INTO menu_dia_prato (mdp_mnd_id, mdp_pra_id) VALUES 
(15, 1), (15, 2), (16, 4), (16, 5), (17, 7), (17, 8), (18, 1), (18, 5), (19, 4), (19, 2),
(20, 7), (20, 8), (21, 1), (21, 2), (22, 4), (22, 5), (23, 7), (23, 8), (24, 1), (24, 2),
(25, 4), (25, 5), (26, 7), (26, 8), (27, 1), (27, 2), (28, 4), (28, 5), (29, 7), (29, 8),
(30, 1), (30, 2), (31, 4), (31, 5), (32, 7), (32, 8), (33, 1), (33, 2), (34, 4), (34, 5);

-- =========================
-- SENHAS NOVEMBRO - João Alves (pes_id=2)
-- =========================

-- 03/11 - Almoço UTILIZADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(15, 1, 2, 2, '2025-11-03 08:30:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-03 08:30:00'), (2, @sen_id, '2025-11-03 12:15:00');

-- 04/11 - Jantar UTILIZADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(17, 2, 2, 2, '2025-11-04 14:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-04 14:00:00'), (2, @sen_id, '2025-11-04 19:30:00');

-- 05/11 - Almoço REEMBOLSADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data, sen_reembolsada) VALUES
(17, 1, 2, 4, '2025-11-05 09:00:00', TRUE);
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-05 09:00:00'), (4, @sen_id, '2025-11-05 10:30:00');

-- 10/11 - Almoço e Jantar UTILIZADAS
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(20, 1, 2, 2, '2025-11-10 08:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-10 08:00:00'), (2, @sen_id, '2025-11-10 12:45:00');

INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(21, 2, 2, 2, '2025-11-10 15:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-10 15:00:00'), (2, @sen_id, '2025-11-10 19:15:00');

-- 18/11 - Almoço POR AGENDAR
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(26, 1, 2, 3, '2025-11-18 09:30:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-18 09:30:00'), (3, @sen_id, '2025-11-18 11:00:00');

-- =========================
-- SENHAS NOVEMBRO - Miguel Costa (pes_id=3)
-- =========================

-- 06/11 - Almoço e Jantar UTILIZADAS
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(18, 1, 3, 2, '2025-11-06 08:15:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-06 08:15:00'), (2, @sen_id, '2025-11-06 13:00:00');

INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(19, 2, 3, 2, '2025-11-06 16:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-06 16:00:00'), (2, @sen_id, '2025-11-06 19:45:00');

-- 12/11 - Jantar REEMBOLSADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data, sen_reembolsada) VALUES
(23, 2, 3, 4, '2025-11-12 14:30:00', TRUE);
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-12 14:30:00'), (4, @sen_id, '2025-11-12 16:00:00');

-- 20/11 - Almoço POR AGENDAR
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(28, 1, 3, 3, '2025-11-20 10:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-20 10:00:00'), (3, @sen_id, '2025-11-20 11:30:00');

-- 25/11 - Jantar POR AGENDAR
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(31, 2, 3, 3, '2025-11-25 15:30:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-25 15:30:00'), (3, @sen_id, '2025-11-25 17:00:00');

-- =========================
-- SENHAS NOVEMBRO - Ana Silva (pes_id=4)
-- =========================

-- 11/11 - Almoço UTILIZADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(21, 1, 4, 2, '2025-11-11 09:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-11 09:00:00'), (2, @sen_id, '2025-11-11 12:30:00');

-- 17/11 - Jantar REEMBOLSADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data, sen_reembolsada) VALUES
(26, 2, 4, 4, '2025-11-17 14:00:00', TRUE);
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-17 14:00:00'), (4, @sen_id, '2025-11-17 15:30:00');

-- 24/11 - Almoço UTILIZADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(30, 1, 4, 2, '2025-11-24 08:30:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-24 08:30:00'), (2, @sen_id, '2025-11-24 13:00:00');

-- =========================
-- SENHAS NOVEMBRO - Pedro Santos (pes_id=5)
-- =========================

-- 13/11 - Almoço e Jantar UTILIZADAS
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(23, 1, 5, 2, '2025-11-13 08:45:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-13 08:45:00'), (2, @sen_id, '2025-11-13 12:20:00');

INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(24, 2, 5, 2, '2025-11-13 15:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-13 15:00:00'), (2, @sen_id, '2025-11-13 19:10:00');

-- 26/11 - Almoço REEMBOLSADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data, sen_reembolsada) VALUES
(32, 1, 5, 4, '2025-11-26 09:15:00', TRUE);
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-26 09:15:00'), (4, @sen_id, '2025-11-26 10:45:00');

-- =========================
-- SENHAS NOVEMBRO - Mariana Ferreira (pes_id=6)
-- =========================

-- 14/11 - Almoço UTILIZADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(24, 1, 6, 2, '2025-11-14 08:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-14 08:00:00'), (2, @sen_id, '2025-11-14 12:50:00');

-- 19/11 - Jantar UTILIZADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(28, 2, 6, 2, '2025-11-19 16:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-19 16:00:00'), (2, @sen_id, '2025-11-19 19:30:00');

-- 27/11 - Almoço REEMBOLSADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data, sen_reembolsada) VALUES
(33, 1, 6, 4, '2025-11-27 09:30:00', TRUE);
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-11-27 09:30:00'), (4, @sen_id, '2025-11-27 11:00:00');

-- =========================
-- SENHAS DEZEMBRO - João Alves (pes_id=2)
-- =========================

-- 02/12 - Almoço AGENDADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(4, 1, 2, 1, '2025-12-01 10:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-12-01 10:00:00');

-- 03/12 - Jantar AGENDADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(9, 2, 2, 1, '2025-12-02 15:30:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-12-02 15:30:00');

-- 10/12 - Almoço AGENDADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(19, 1, 2, 1, '2025-12-09 09:15:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-12-09 09:15:00');

-- 16/12 - Jantar AGENDADA
INSERT INTO senha (sen_mdp_id, sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(34, 2, 2, 1, '2025-12-15 14:00:00');
SET @sen_id = LAST_INSERT_ID();
INSERT INTO senha_extra (sex_sen_id, sex_ext_id) VALUES (@sen_id, 1), (@sen_id, 2);
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2025-12-15 14:00:00');

-- 18/12 - Almoço POR AGENDAR antiga
-- Primeiro esteve agendada, depois passou para por agendar
INSERT INTO senha (sen_tps_id, sen_pes_id, sen_est_atual_id, sen_data) VALUES
(1, 2, 1, '2024-12-17 10:30:00');
SET @sen_id = LAST_INSERT_ID();

-- Expirou, agora está por agendar
INSERT INTO estado_senha (ess_est_id, ess_sen_id, ess_data) VALUES
(1, @sen_id, '2024-12-17 10:30:00'), (3, @sen_id, '2024-12-18 00:00:00');

-- Atualizar estado atual da senha
UPDATE senha SET sen_est_atual_id = 3 WHERE sen_id = @sen_id;

-- =========================
-- CHATS SUPORTE - João Alves
-- =========================

-- Chat 1: FECHADO - Reembolso ainda não recebido (sobre senha de 05/11)
INSERT INTO chat_suporte (csp_pes_id, csp_est_atual_id, csp_assunto) VALUES
(2, 6, 'Reembolso não recebido');
SET @chat1_id = LAST_INSERT_ID();

INSERT INTO mensagem (msg_csp_id, msg_pes_id, msg_texto, msg_data) VALUES
(@chat1_id, 2, 'Olá, pedi reembolso de uma senha no dia 5 de novembro mas ainda não recebi o dinheiro.', '2025-11-07 10:30:00');

INSERT INTO mensagem (msg_csp_id, msg_pes_id, msg_texto, msg_data) VALUES
(@chat1_id, 1, 'Bom dia João. Já verificámos a situação e o reembolso foi processado. Deverá receber o valor nos próximos 2-3 dias úteis.', '2025-11-07 14:15:00');

INSERT INTO mensagem (msg_csp_id, msg_pes_id, msg_texto, msg_data) VALUES
(@chat1_id, 2, 'Perfeito, obrigado pela ajuda!', '2025-11-07 14:20:00');

INSERT INTO chat_suporte_estado (cse_est_id, cse_csp_id, cse_data) VALUES
(4, @chat1_id, '2025-11-07 10:30:00'),
(5, @chat1_id, '2025-11-07 14:15:00'),
(6, @chat1_id, '2025-11-07 14:25:00');

-- Chat 2: EM CURSO - Senha comprada não aparece no calendário
INSERT INTO chat_suporte (csp_pes_id, csp_est_atual_id, csp_assunto) VALUES
(2, 5, 'Senha não aparece no calendário');
SET @chat2_id = LAST_INSERT_ID();

INSERT INTO mensagem (msg_csp_id, msg_pes_id, msg_texto, msg_data) VALUES
(@chat2_id, 2, 'Boa tarde, comprei uma senha para o dia 18 de novembro mas ela não aparece no meu calendário. Podem verificar?', '2025-11-18 16:45:00');

INSERT INTO chat_suporte_estado (cse_est_id, cse_csp_id, cse_data) VALUES
(4, @chat2_id, '2025-11-18 16:45:00'),
(5, @chat2_id, '2025-11-18 16:45:00');

-- ========================================
-- FAQs
-- ========================================

INSERT INTO faq (faq_titulo, faq_conteudo) VALUES
('O que é o IPSREF?', 
'O IPSREF é o sistema online de compra e gestão de senhas para o refeitório do IPS. Permite aos alunos adquirir senhas de forma digital.'),

('Como se compra uma senha?', 
'Aceda à página principal, onde encontrará um calendário interativo. Selecione o dia pretendido e preencha o formulário com as informações relativas à senha.'),

('Como se utiliza a senha no refeitório?', 
'No refeitório, aproxime o cartão de estudante do leitor. O sistema verificará automaticamente se possui senhas agendadas e, após confirmação na aplicação, a senha será validada.'),

('É possível reagendar uma senha já adquirida?', 
'Sim. Pode reagendar senhas que se encontrem dentro do prazo de validade (48 horas) e que ainda não tenham sido utilizadas nem reembolsadas. Para tal, aceda ao calendário e selecione a opção de reagendamento.'),

('Como funciona o reembolso de senhas?', 
'Pode solicitar o reembolso de uma senha através do calendário na página principal. O prazo máximo para reembolso é de 48 horas após a data de marcação. Senhas já utilizadas não são passíveis de reembolso.'),

('O que fazer em caso de perda da palavra-passe?', 
'Na página de login, selecione a opção “Esqueci-me da palavra-passe”. Siga as instruções que serão enviadas para o endereço de email registado, de modo a recuperar o acesso à sua conta.'),

('Como consultar o histórico de compras?', 
'Aceda à página “Histórico” através da barra lateral. Poderá consultar todas as senhas anteriores, incluindo as adquiridas, utilizadas e reembolsadas, bem como algumas estatísticas.'),

('Como configurar as notificações?', 
'Na área de perfil, pode definir as preferências de notificação. Escolha os tipos de alertas que pretende receber (por exemplo, senhas prestes a expirar ou prazos de reembolso) e a antecedência com que deverão ser enviados.'),

('É possível alterar o endereço de email?', 
'Sim. Na página de perfil, pode atualizar o seu endereço de email. Esta informação é essencial para o recebimento de notificações e alertas do sistema.'),

('Quantas senhas podem ser marcadas por dia?', 
'Pode marcar até duas senhas por dia, escolhendo entre almoço e jantar. Cada senha permite personalizar o tipo de refeição, o prato e os extras.'),

('O que são os extras disponíveis?', 
'Os extras são complementos à refeição principal que podem ser adicionados à senha, tais como pão e sopa. Pode selecionar os extras desejados durante o processo de compra da senha.'),

('O que acontece se uma senha expirar?', 
'O sistema envia notificações automáticas quando uma senha está prestes a expirar. Senhas expiradas não podem ser utilizadas nem reembolsadas. Recomenda-se que esteja atento às notificações para evitar a perda das senhas.'),

('Como funciona o suporte?', 
'Existem duas formas de apoio: a página de FAQ (Perguntas Frequentes), onde se encontram respostas às dúvidas mais comuns, e a página de Suporte, onde pode iniciar um chat para questões mais específicas. Para criar um chat, dirija-se à página de Suporte, escreva a mensagem no campo indicado e clique em Submeter. Em seguida, na mesma página, aceda ao botão “Chats”; o primeiro chat apresentado será o que acabou de criar. A partir daí, pode clicar nesse chat e conversar diretamente com a equipa de suporte.');